/**
 * Модуль настроек теста
 */

function renderSettingsTab(container, currentTest) {
    // Получаем текущие настройки
    let testSettings = {};
    try {
        testSettings = currentTest.settings ? JSON.parse(currentTest.settings) : {};
    } catch (e) {
        console.error('Ошибка парсинга настроек:', e);
    }
    
    // Формируем разметку
    container.innerHTML = `
        <h2>Настройки теста "${escapeHtml(currentTest.name)}"</h2>
        
        <div class="ptb-form-group" style="margin-bottom: 25px; padding: 20px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e0e0e0;">
            <h3 style="margin: 0 0 15px 0; font-size: 18px;">Правила формирования результата</h3>
            
            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div class="ptb-rule-option" data-rule="single" style="flex: 1; min-width: 250px; padding: 15px; border: 2px solid ${testSettings.resultRule === 'single' ? '#007cba' : '#e0e0e0'}; border-radius: 8px; cursor: pointer; transition: all 0.2s;">
                    <div style="font-weight: 600; font-size: 16px; margin-bottom: 10px; color: ${testSettings.resultRule === 'single' ? '#007cba' : '#333'};">По одной ключевой категории</div>
                    <p style="margin: 0; color: #666; line-height: 1.6; font-size: 14px;">Результат определяется по категории с наибольшим количеством баллов</p>
                </div>
                
                <div class="ptb-rule-option" data-rule="dual" style="flex: 1; min-width: 250px; padding: 15px; border: 2px solid ${testSettings.resultRule === 'dual' ? '#007cba' : '#e0e0e0'}; border-radius: 8px; cursor: pointer; transition: all 0.2s;">
                    <div style="font-weight: 600; font-size: 16px; margin-bottom: 10px; color: ${testSettings.resultRule === 'dual' ? '#007cba' : '#333'};">По двум ключевым категориям</div>
                    <p style="margin: 0; color: #666; line-height: 1.6; font-size: 14px;">Результат формируется на основе двух категорий с наибольшим количеством баллов</p>
                </div>
            </div>
            
            <p style="margin-top: 15px; font-size: 13px; color: #666; padding-top: 15px; border-top: 1px solid #eee;">
                <strong>💡 Совет:</strong> Для RIASEC тестов рекомендуется использовать "По двум ключевым категориям"
            </p>
        </div>
        
        <div class="ptb-form-group" style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;">
            <h4 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">Режим выбора ответа</h4>
            
            <label style="display: block; margin: 8px 0; padding: 12px; background: #f8f9fa; border-radius: 6px; border: 2px solid ${testSettings.answerMode === 'button' || !testSettings.answerMode ? '#007cba' : '#e0e0e0'}; cursor: pointer;">
                <input type="radio" name="answer-mode" value="button" ${testSettings.answerMode === 'button' || !testSettings.answerMode ? 'checked' : ''} style="margin-right: 8px;">
                <span style="font-weight: 500;">С кнопкой "Далее" (стандартный режим)</span>
                <p style="margin: 4px 0 0 24px; color: #666; font-size: 14px; line-height: 1.5;">Пользователь выбирает ответ и нажимает кнопку для перехода к следующему вопросу</p>
            </label>
            
            <label style="display: block; margin: 8px 0; padding: 12px; background: #f8f9fa; border-radius: 6px; border: 2px solid ${testSettings.answerMode === 'instant' ? '#007cba' : '#e0e0e0'}; cursor: pointer;">
                <input type="radio" name="answer-mode" value="instant" ${testSettings.answerMode === 'instant' ? 'checked' : ''} style="margin-right: 8px;">
                <span style="font-weight: 500;">Мгновенный переход (без кнопки)</span>
                <p style="margin: 4px 0 0 24px; color: #666; font-size: 14px; line-height: 1.5;">Пользователь выбирает ответ и автоматически переходит к следующему вопросу</p>
            </label>
        </div>
        
        <div class="ptb-form-group">
            <label><input type="checkbox" id="show-progress" ${testSettings.showProgress ? 'checked' : ''}> Показывать прогресс-бар</label>
        </div>
        
        <div class="ptb-form-group">
            <label><input type="checkbox" id="shuffle-questions" ${testSettings.shuffleQuestions ? 'checked' : ''}> Перемешивать вопросы</label>
        </div>
        
        <div class="ptb-form-group">
            <label><input type="checkbox" id="allow-retake" ${testSettings.allowRetake !== false ? 'checked' : ''}> Разрешить повторное прохождение</label>
        </div>
        
        <div class="ptb-form-group" style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;">
            <h4 style="margin: 0 0 10px 0; font-size: 16px; color: #333;">Настройки отображения</h4>
            
            <label style="display: block; margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                <input type="checkbox" id="show-answer-categories" ${testSettings.showAnswerCategories ? 'checked' : ''}>
                <span style="margin-left: 8px;">Показывать категории ответов при прохождении теста</span>
            </label>
            
            <label style="display: block; margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                <input type="checkbox" id="show-answer-weights" ${testSettings.showAnswerWeights ? 'checked' : ''}>
                <span style="margin-left: 8px;">Показывать веса категорий ответов при прохождении теста</span>
            </label>
            
            <label style="display: block; margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                <input type="checkbox" id="show-recommendations" ${testSettings.showRecommendations !== false ? 'checked' : ''}>
                <span style="margin-left: 8px;">Показывать рекомендации в результатах</span>
            </label>
            
            <label style="display: block; margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 4px;">
                <input type="checkbox" id="show-result-categories" ${testSettings.showResultCategories !== false ? 'checked' : ''}>
                <span style="margin-left: 8px;">Показывать категории в результатах</span>
            </label>
        </div>
        
        <div class="ptb-form-group" style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e0e0e0;">
            <h3 style="margin: 0 0 15px 0; font-size: 18px;">Типы рекомендаций</h3>
            <p style="margin: 0 0 15px 0; color: #666; line-height: 1.6;">
                Здесь вы можете управлять типами рекомендаций, которые будут доступны при создании профилей результатов. 
                Эти типы были заданы при создании первого профиля для этого теста.
            </p>
            
            <div id="recommendation-types-container" style="display: flex; flex-direction: column; gap: 12px; margin-top: 15px;">
                ${testSettings.recommendation_types?.length > 0 ? 
                    testSettings.recommendation_types.map((type, index) => `
                        <div class="recommendation-type-item" style="display: flex; align-items: center; gap: 10px; padding: 8px; background: white; border-radius: 6px; border: 1px solid #e0e0e0;">
                            <input type="text" class="rec-type-input" value="${escapeHtml(type)}" placeholder="Название типа рекомендации" style="flex: 1; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;">
                            <button type="button" class="button button-link delete-rec-type-btn" data-index="${index}" style="color: #dc2626; padding: 0; height: auto;">
                                <span class="dashicons dashicons-trash"></span>
                            </button>
                        </div>
                    `).join('') : 
                    '<p style="color: #666; font-style: italic; margin: 0;">Типы рекомендаций ещё не заданы. Они будут созданы автоматически при создании первого профиля результата.</p>'
                }
            </div>
            
            ${testSettings.recommendation_types?.length > 0 ? `
                <button id="add-rec-type-btn" class="button button-secondary" style="margin-top: 15px; padding: 8px 16px;">
                    <span class="dashicons dashicons-plus"></span>
                    Добавить тип рекомендации
                </button>
                <p style="margin: 8px 0 0 0; font-size: 13px; color: #666;">Максимум 20 типов. Порядок важен — он будет сохранён при создании профилей.</p>
            ` : ''}
        </div>
        
        <button id="save-settings-btn" class="button button-primary ptb-primary" style="margin-top: 20px;">Сохранить настройки</button>
        
        <h3 style="margin: 40px 0 15px 0; padding-top: 20px; border-top: 2px solid #eee;">📋 Шорткод для вставки на страницу</h3>
        <div style="background: #f8f9fa; padding: 15px; border-radius: 6px; border: 1px solid #e0e0e0;">
            <p style="margin: 0 0 10px 0; color: #666;">Скопируйте этот шорткод и вставьте на любую страницу или запись:</p>
            <div style="display: flex; gap: 10px; align-items: center;">
                <input type="text" id="shortcode-input" value="[personality_test id=&quot;${currentTest.id}&quot;]" readonly style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace;">
                <button id="copy-shortcode-btn" class="button" style="white-space: nowrap;">Копировать</button>
            </div>
            <p style="margin: 10px 0 0 0; font-size: 13px; color: #666;">
                <strong>Пример использования:</strong> Вставьте шорткод в редактор страницы или записи
            </p>
        </div>
    `;
    
    // 🎯 ОБРАБОТЧИК ВЫБОРА ПРАВИЛА
    document.querySelectorAll('.ptb-rule-option').forEach(option => {
        option.addEventListener('click', () => {
            const newRule = option.dataset.rule;
            
            // Обновляем внешний вид
            document.querySelectorAll('.ptb-rule-option').forEach(opt => {
                opt.style.borderColor = '#e0e0e0';
                opt.querySelector('div:first-child').style.color = '#333';
            });
            option.style.borderColor = '#007cba';
            option.querySelector('div:first-child').style.color = '#007cba';
            
            // Обновляем настройки
            testSettings.resultRule = newRule;
        });
    });
    
    // 🎯 ОБРАБОТЧИК ВЫБОРА РЕЖИМА ОТВЕТА
    document.querySelectorAll('input[name="answer-mode"]').forEach(radio => {
        radio.addEventListener('change', () => {
            // Обновляем внешний вид
            document.querySelectorAll('label[style*="border: 2px solid"]').forEach(label => {
                label.style.borderColor = '#e0e0e0';
            });
            radio.closest('label').style.borderColor = '#007cba';
        });
    });
    
    // 🎯 ОБРАБОТЧИК ДОБАВЛЕНИЯ ТИПА РЕКОМЕНДАЦИИ
    document.getElementById('add-rec-type-btn')?.addEventListener('click', () => {
        const container = document.getElementById('recommendation-types-container');
        const currentTypes = testSettings.recommendation_types || [];
        
        if (currentTypes.length >= 20) {
            alert('Достигнут лимит в 20 типов рекомендаций.');
            return;
        }
        
        const newIndex = currentTypes.length;
        const newItem = document.createElement('div');
        newItem.className = 'recommendation-type-item';
        newItem.style.cssText = 'display: flex; align-items: center; gap: 10px; padding: 8px; background: white; border-radius: 6px; border: 1px solid #e0e0e0;';
        newItem.innerHTML = `
            <input type="text" class="rec-type-input" placeholder="Название типа рекомендации" value="" style="flex: 1; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;">
            <button type="button" class="button button-link delete-rec-type-btn" data-index="${newIndex}" style="color: #dc2626; padding: 0; height: auto;">
                <span class="dashicons dashicons-trash"></span>
            </button>
        `;
        
        container.appendChild(newItem);
        
        // Обработчик удаления для нового элемента
        newItem.querySelector('.delete-rec-type-btn').addEventListener('click', (e) => {
            const index = e.currentTarget.dataset.index;
            if (confirm('Удалить этот тип рекомендаций?\n⚠️ Это необратимо и применится ко всем профилям этого теста.')) {
                newItem.remove();
            }
        });
    });
    
    // 🎯 ОБРАБОТЧИК УДАЛЕНИЯ СУЩЕСТВУЮЩИХ ТИПОВ
    document.querySelectorAll('.delete-rec-type-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const index = e.currentTarget.dataset.index;
            if (confirm('Удалить этот тип рекомендаций?\n⚠️ Это необратимо и применится ко всем профилям этого теста.')) {
                const item = e.currentTarget.closest('.recommendation-type-item');
                item.remove();
            }
        });
    });
    
    // 🎯 КОПИРОВАНИЕ ШОРТКОДА
    document.getElementById('copy-shortcode-btn').addEventListener('click', () => {
        const input = document.getElementById('shortcode-input');
        input.select();
        input.setSelectionRange(0, 99999); // Для мобильных устройств
        
        try {
            document.execCommand('copy');
            const btn = document.getElementById('copy-shortcode-btn');
            const originalText = btn.textContent;
            btn.textContent = '✅ Скопировано!';
            setTimeout(() => {
                btn.textContent = originalText;
            }, 2000);
        } catch (err) {
            alert('Не удалось скопировать шорткод. Скопируйте его вручную.');
        }
    });
    
    // 🎯 СОХРАНЕНИЕ НАСТРОЕК
    document.getElementById('save-settings-btn').addEventListener('click', () => {
        // Собираем настройки
        const newSettings = {
            resultRule: testSettings.resultRule || 'dual',
            answerMode: document.querySelector('input[name="answer-mode"]:checked')?.value || 'button',
            showProgress: document.getElementById('show-progress').checked,
            shuffleQuestions: document.getElementById('shuffle-questions').checked,
            allowRetake: document.getElementById('allow-retake').checked,
            showAnswerCategories: document.getElementById('show-answer-categories').checked,
            showAnswerWeights: document.getElementById('show-answer-weights').checked,
            showRecommendations: document.getElementById('show-recommendations').checked,
            showResultCategories: document.getElementById('show-result-categories').checked
        };
        
        // Собираем типы рекомендаций
        const recTypeInputs = document.querySelectorAll('.rec-type-input');
        const recommendationTypes = Array.from(recTypeInputs)
            .map(input => input.value.trim())
            .filter(value => value !== '');
        
        if (recommendationTypes.length > 0) {
            newSettings.recommendation_types = recommendationTypes;
        }
        
        console.log('Сохраняем настройки:', newSettings);
        
        // Сохраняем в базу
        fetch(ptbAdminSettings.apiUrl + '/tests/' + currentTest.id, {
            method: 'PUT',
            headers: {
                'X-WP-Nonce': ptbAdminSettings.nonce,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                settings: JSON.stringify(newSettings)
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Настройки сохранены!');
                // Обновляем текущий тест
                currentTest.settings = JSON.stringify(newSettings);
                // Перезагружаем тест
                window.ptb.selectTest(currentTest.id);
            } else {
                alert('Ошибка сохранения настроек');
            }
        })
        .catch(error => {
            console.error('Ошибка сохранения настроек:', error);
            alert('Ошибка сохранения настроек: ' + error.message);
        });
    });
}

/**
 * Вспомогательная функция для экранирования HTML
 */
function escapeHtml(text) {
    if (typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}