/**
 * Модуль управления категориями теста
 */

/**
 * Рендеринг вкладки категорий
 */
function renderCategoriesTab(container, currentTest) {
    let html = `
        <div class="ptb-categories-container">
            <h3>Категории теста "${escapeHtml(currentTest.name)}"</h3>
            
            <div class="ptb-category-form">
                <h4>Добавить новую категорию</h4>
                <div class="form-row">
                    <div class="form-group">
                        <label for="new-category-code">Код категории *</label>
                        <input type="text" id="new-category-code" class="form-input" placeholder="I" maxlength="10">
                        <p class="form-hint">Короткий код (макс. 10 символов), например: I, R, A, S, E, C</p>
                    </div>
                    <div class="form-group">
                        <label for="new-category-name">Название категории *</label>
                        <input type="text" id="new-category-name" class="form-input" placeholder="Исследовательский">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="new-category-color">Цвет категории</label>
                        <div class="color-selector">
                            <div class="color-preview" style="background-color: #3b82f6"></div>
                            <div class="color-palette">
                                <div class="color-option selected" data-color="#3b82f6" style="background: #3b82f6;"></div>
                                <div class="color-option" data-color="#10b981" style="background: #10b981;"></div>
                                <div class="color-option" data-color="#f59e0b" style="background: #f59e0b;"></div>
                                <div class="color-option" data-color="#ef4444" style="background: #ef4444;"></div>
                                <div class="color-option" data-color="#8b5cf6" style="background: #8b5cf6;"></div>
                                <div class="color-option" data-color="#ec4899" style="background: #ec4899;"></div>
                                <div class="color-option" data-color="#0ea5e9" style="background: #0ea5e9;"></div>
                                <div class="color-option" data-color="#14b8a6" style="background: #14b8a6;"></div>
                                <div class="color-option" data-color="#f97316" style="background: #f97316;"></div>
                                <div class="color-option" data-color="#dc2626" style="background: #dc2626;"></div>
                                <div class="color-option" data-color="#7c3aed" style="background: #7c3aed;"></div>
                                <div class="color-option" data-color="#db2777" style="background: #db2777;"></div>
                            </div>
                            <button type="button" class="button button-secondary toggle-custom-color-btn" style="margin-top: 12px; width: 100%;">
                                <span class="dashicons dashicons-admin-customizer"></span>
                                Выбрать свой цвет
                            </button>
                            <input type="color" class="color-input" id="new-category-color" value="#3b82f6" style="display: none; margin-top: 12px; width: 100%; height: 40px; border-radius: 6px; border: 1px solid #d1d5db;">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="new-category-description">Описание (необязательно)</label>
                        <textarea id="new-category-description" class="form-textarea category-description-textarea" placeholder="Описание категории..."></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <button id="add-category-btn" class="button button-primary">
                        <span class="dashicons dashicons-plus"></span>
                        Добавить категорию
                    </button>
                </div>
            </div>
            
            ${currentTest.categories?.length > 0 ? `
                <div class="ptb-categories-list">
                    <h4>Существующие категории (${currentTest.categories.length})</h4>
                    <div class="categories-grid">
                        ${currentTest.categories.map(cat => renderCategoryCard(cat, currentTest.id)).join('')}
                    </div>
                </div>
            ` : `
                <div class="ptb-empty-state">
                    <p>Нет категорий. Добавьте первую категорию выше.</p>
                </div>
            `}
        </div>
    `;
    
    container.innerHTML = html;
    
    // Инициализируем кастомный селектор цвета ПОСЛЕ рендеринга
    setTimeout(() => {
        initColorSelector();
    }, 0);
    
    // Регистрируем обработчики
    registerCategoryHandlers(currentTest);
}

/**
 * Рендеринг карточки категории
 */
function renderCategoryCard(category, testId) {
    return `
        <div class="ptb-category-card" data-id="${category.id}" style="--category-color: ${category.color};">
            <div class="category-header">
                <div class="category-color-badge" style="background-color: ${category.color};"></div>
                <div class="category-meta">
                    <span class="category-meta-badge">
                        <span class="dashicons dashicons-admin-generic"></span>
                        ID: ${category.id}
                    </span>
                    <span class="category-meta-badge">
                        <span class="dashicons dashicons-editor-code"></span>
                        ${category.code}
                    </span>
                </div>
            </div>
            <div class="category-body">
                <h5 class="category-name">${escapeHtml(category.name)}</h5>
                ${category.description ? `<p class="category-description">${escapeHtml(category.description)}</p>` : ''}
            </div>
            <div class="category-footer">
                <div class="category-actions">
                    <button class="button button-secondary edit-category-btn" data-id="${category.id}">
                        <span class="dashicons dashicons-edit"></span>
                        Редактировать
                    </button>
                    <button class="button button-danger delete-category-btn" data-id="${category.id}">
                        <span class="dashicons dashicons-trash"></span>
                        Удалить
                    </button>
                </div>
            </div>
        </div>
    `;
}

/**
 * Инициализация кастомного селектора цвета
 */
function initColorSelector() {
    // Обработчик выбора цвета из палитры
    document.querySelectorAll('.color-option').forEach(option => {
        option.addEventListener('click', function() {
            const color = this.getAttribute('data-color');
            const colorInput = this.closest('.color-selector').querySelector('.color-input');
            const colorPreview = this.closest('.color-selector').querySelector('.color-preview');
            
            colorInput.value = color;
            colorPreview.style.backgroundColor = color;
            
            // Снимаем выделение со всех цветов в этой палитре
            this.closest('.color-palette').querySelectorAll('.color-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            this.classList.add('selected');
        });
    });
    
    // Обработчик для кнопки "Свой цвет" — показываем/скрываем нативный селектор
    document.querySelectorAll('.toggle-custom-color-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const colorSelector = this.closest('.color-selector');
            const colorInput = colorSelector.querySelector('.color-input');
            const isHidden = colorInput.style.display === 'none' || colorInput.style.display === '';
            
            // Переключаем видимость
            colorInput.style.display = isHidden ? 'block' : 'none';
            
            // Меняем текст кнопки
            const icon = this.querySelector('.dashicons');
            if (isHidden) {
                this.innerHTML = '<span class="dashicons dashicons-hidden"></span> Скрыть выбор цвета';
            } else {
                this.innerHTML = '<span class="dashicons dashicons-admin-customizer"></span> Выбрать свой цвет';
            }
            
            // Если показываем — фокусируем на инпуте
            if (isHidden) {
                setTimeout(() => {
                    colorInput.click(); // Открываем нативный селектор
                }, 100);
            }
        });
    });
    
    // Обработчик для выбора цвета через нативный селектор
    document.querySelectorAll('.color-input').forEach(input => {
        input.addEventListener('input', function() {
            const color = this.value;
            const preview = this.closest('.color-selector').querySelector('.color-preview');
            const options = this.closest('.color-selector').querySelectorAll('.color-option');
            
            if (preview) {
                preview.style.backgroundColor = color;
            }
            
            // Снимаем выделение со всех цветов палитры
            options.forEach(opt => opt.classList.remove('selected'));
            
            // Выделяем цвет в палитре, если он совпадает
            const matchingOption = Array.from(options).find(opt => 
                opt.getAttribute('data-color').toLowerCase() === color.toLowerCase()
            );
            if (matchingOption) {
                matchingOption.classList.add('selected');
            }
        });
    });
}

/**
 * Регистрация обработчиков событий
 */
function registerCategoryHandlers(currentTest) {
    // Добавление категории
    document.getElementById('add-category-btn')?.addEventListener('click', () => {
        addCategory(currentTest);
    });
    
    // Редактирование категории
    document.querySelectorAll('.edit-category-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const categoryId = e.currentTarget.dataset.id;
            editCategory(categoryId, currentTest);
        });
    });
    
    // Удаление категории
    document.querySelectorAll('.delete-category-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const categoryId = e.currentTarget.dataset.id;
            deleteCategory(categoryId, currentTest);
        });
    });
}

/**
 * Добавление новой категории
 */
function addCategory(currentTest) {
    const code = document.getElementById('new-category-code').value.trim();
    const name = document.getElementById('new-category-name').value.trim();
    const color = document.getElementById('new-category-color').value;
    const description = document.getElementById('new-category-description').value.trim();
    
    // Валидация
    if (!code) return alert('Введите код категории');
    if (code.length > 10) return alert('Код категории не должен превышать 10 символов');
    if (!name) return alert('Введите название категории');
    
    // Проверка на дубликат кода
    const existingCategory = currentTest.categories?.find(cat => cat.code.toLowerCase() === code.toLowerCase());
    if (existingCategory) {
        return alert(`Категория с кодом "${code}" уже существует. Используйте другой код.`);
    }
    
    fetch(ptbAdminSettings.apiUrl + '/categories', {
        method: 'POST',
        headers: { 
            'X-WP-Nonce': ptbAdminSettings.nonce, 
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify({ 
            test_id: currentTest.id, 
            code, 
            name, 
            color, 
            description,
            weight: 1, 
            sort_order: currentTest.categories?.length || 0 
        })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            alert('Категория добавлена успешно!');
            window.ptb.selectTest(currentTest.id);
        } else {
            alert('Ошибка добавления: ' + (d.message || 'Неизвестная ошибка'));
        }
    })
    .catch(e => {
        console.error('Ошибка добавления категории:', e);
        alert('Ошибка: ' + e.message);
    });
}

/**
 * Редактирование категории
 */
function editCategory(categoryId, currentTest) {
    const category = currentTest.categories.find(cat => cat.id == categoryId);
    if (!category) return;
    
    // Создаём модальное окно для редактирования
    const modal = document.createElement('div');
    modal.className = 'ptb-modal-overlay';
    modal.innerHTML = `
        <div class="ptb-modal">
            <div class="modal-header">
                <h3>Редактировать категорию</h3>
                <button class="modal-close-btn" id="close-edit-modal">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit-category-code">Код категории *</label>
                        <input type="text" id="edit-category-code" class="form-input" value="${escapeHtml(category.code)}" maxlength="10">
                    </div>
                    <div class="form-group">
                        <label for="edit-category-name">Название категории *</label>
                        <input type="text" id="edit-category-name" class="form-input" value="${escapeHtml(category.name)}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit-category-color">Цвет категории</label>
                        <div class="color-selector">
                            <div class="color-preview" style="background-color: ${category.color}"></div>
                            <div class="color-palette">
                                <div class="color-option ${category.color === '#3b82f6' ? 'selected' : ''}" data-color="#3b82f6" style="background: #3b82f6;"></div>
                                <div class="color-option ${category.color === '#10b981' ? 'selected' : ''}" data-color="#10b981" style="background: #10b981;"></div>
                                <div class="color-option ${category.color === '#f59e0b' ? 'selected' : ''}" data-color="#f59e0b" style="background: #f59e0b;"></div>
                                <div class="color-option ${category.color === '#ef4444' ? 'selected' : ''}" data-color="#ef4444" style="background: #ef4444;"></div>
                                <div class="color-option ${category.color === '#8b5cf6' ? 'selected' : ''}" data-color="#8b5cf6" style="background: #8b5cf6;"></div>
                                <div class="color-option ${category.color === '#ec4899' ? 'selected' : ''}" data-color="#ec4899" style="background: #ec4899;"></div>
                                <div class="color-option ${category.color === '#0ea5e9' ? 'selected' : ''}" data-color="#0ea5e9" style="background: #0ea5e9;"></div>
                                <div class="color-option ${category.color === '#14b8a6' ? 'selected' : ''}" data-color="#14b8a6" style="background: #14b8a6;"></div>
                                <div class="color-option ${category.color === '#f97316' ? 'selected' : ''}" data-color="#f97316" style="background: #f97316;"></div>
                                <div class="color-option ${category.color === '#dc2626' ? 'selected' : ''}" data-color="#dc2626" style="background: #dc2626;"></div>
                                <div class="color-option ${category.color === '#7c3aed' ? 'selected' : ''}" data-color="#7c3aed" style="background: #7c3aed;"></div>
                                <div class="color-option ${category.color === '#db2777' ? 'selected' : ''}" data-color="#db2777" style="background: #db2777;"></div>
                            </div>
                            <button type="button" class="button button-secondary toggle-custom-color-btn" style="margin-top: 12px; width: 100%;">
                                <span class="dashicons dashicons-admin-customizer"></span>
                                Выбрать свой цвет
                            </button>
                            <input type="color" class="color-input" id="edit-category-color" value="${category.color}" style="display: none; margin-top: 12px; width: 100%; height: 40px; border-radius: 6px; border: 1px solid #d1d5db;">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="edit-category-description">Описание</label>
                        <textarea id="edit-category-description" class="form-textarea category-description-textarea">${escapeHtml(category.description || '')}</textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="button button-secondary" id="cancel-edit-btn">Отмена</button>
                <button class="button button-primary" id="save-category-btn" data-id="${categoryId}">Сохранить изменения</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Инициализируем кастомный селектор цвета для модального окна
    setTimeout(() => {
        initColorSelector();
    }, 0);
    
    // Регистрируем обработчики модального окна
    document.getElementById('close-edit-modal').addEventListener('click', () => {
        modal.remove();
    });
    
    document.getElementById('cancel-edit-btn').addEventListener('click', () => {
        modal.remove();
    });
    
    document.getElementById('save-category-btn').addEventListener('click', () => {
        const code = document.getElementById('edit-category-code').value.trim();
        const name = document.getElementById('edit-category-name').value.trim();
        const color = document.getElementById('edit-category-color').value;
        const description = document.getElementById('edit-category-description').value.trim();
        
        // Валидация
        if (!code) return alert('Введите код категории');
        if (code.length > 10) return alert('Код категории не должен превышать 10 символов');
        if (!name) return alert('Введите название категории');
        
        // Проверка на дубликат кода (исключая текущую категорию)
        const existingCategory = currentTest.categories?.find(cat => 
            cat.id != categoryId && cat.code.toLowerCase() === code.toLowerCase()
        );
        if (existingCategory) {
            return alert(`Категория с кодом "${code}" уже существует. Используйте другой код.`);
        }
        
        fetch(ptbAdminSettings.apiUrl + '/categories/' + categoryId, {
            method: 'PUT',
            headers: { 
                'X-WP-Nonce': ptbAdminSettings.nonce, 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify({ 
                code, 
                name, 
                color, 
                description,
                weight: category.weight || 1,
                sort_order: category.sort_order || 0
            })
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                alert('Категория обновлена успешно!');
                modal.remove();
                window.ptb.selectTest(currentTest.id);
            } else {
                alert('Ошибка обновления: ' + (d.message || 'Неизвестная ошибка'));
            }
        })
        .catch(e => {
            console.error('Ошибка обновления категории:', e);
            alert('Ошибка: ' + e.message);
        });
    });
}

/**
 * Удаление категории
 */
function deleteCategory(categoryId, currentTest) {
    if (!confirm('Вы уверены, что хотите удалить эту категорию?\nВсе связанные данные будут удалены.')) {
        return;
    }
    
    fetch(ptbAdminSettings.apiUrl + '/categories/' + categoryId, {
        method: 'DELETE',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce }
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            alert('Категория удалена успешно!');
            window.ptb.selectTest(currentTest.id);
        } else {
            alert('Ошибка удаления: ' + (d.message || 'Неизвестная ошибка'));
        }
    })
    .catch(e => {
        console.error('Ошибка удаления категории:', e);
        alert('Ошибка: ' + e.message);
    });
}

/**
 * Вспомогательная функция для экранирования HTML
 */
function escapeHtml(text) {
    if (typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}