/**
 * Модуль обзорной страницы личностных тестов — с быстрым сохранением
 */

(function($) {
    'use strict';
    
    window.ptb = window.ptb || {};
    
    // Текущий модальный тип
    let currentModalType = null;
    
    /**
     * Рендеринг обзорной страницы
     */
    window.ptb.renderOverviewTab = function(container, currentTest) {
        // Получаем статистику
        const stats = calculateTestStats(currentTest);
        
        // Формируем разметку
        const html = `
            <div class="overview-page">
                <div class="overview-header">
                    <div class="test-title-section">
                        <h2>
                            <span class="test-title-editable" id="test-title-text">${escapeHtml(currentTest.name)}</span>
                            <span class="dashicons dashicons-edit" id="edit-title-btn" style="font-size: 20px; cursor: pointer;"></span>
                        </h2>
                        ${currentTest.description ? `
                            <p class="test-description-editable" id="test-description-text">
                                ${escapeHtml(currentTest.description)}
                                <span class="dashicons dashicons-edit" id="edit-description-btn" style="font-size: 16px; margin-left: 8px; cursor: pointer; vertical-align: middle;"></span>
                            </p>
                        ` : `
                            <p class="test-description-editable" id="test-description-text" style="color: #9ca3af; font-style: italic;">
                                Нет описания
                                <span class="dashicons dashicons-edit" id="edit-description-btn" style="font-size: 16px; margin-left: 8px; cursor: pointer; vertical-align: middle;"></span>
                            </p>
                        `}
                    </div>
                    <div class="test-status-controls">
                        <span class="test-status-badge test-status-${currentTest.status || 'draft'}">
                            ${currentTest.status === 'published' ? 'Опубликован' : 'Черновик'}
                        </span>
                        <button id="toggle-status-btn" class="status-toggle-btn ${currentTest.status === 'published' ? 'published' : 'draft'}">
                            ${currentTest.status === 'published' ? 'В черновик' : 'Опубликовать'}
                        </button>
                    </div>
                </div>
                
                <div class="test-stats-grid">
                    ${renderCategoriesCard(stats.categories)}
                    ${renderQuestionsCard(stats.questions)}
                    ${renderResultsCard(stats.results, currentTest)}
                </div>
                
                <div class="quick-actions-section">
                    <h3>
                        <span class="dashicons dashicons-lightbulb"></span>
                        Быстрые действия
                    </h3>
                    <div class="quick-actions-grid">
                        ${renderQuickAction('add-category', 'dashicons-plus', 'Добавить категорию')}
                        ${renderQuickAction('add-question', 'dashicons-plus', 'Добавить вопрос')}
                        ${renderQuickAction('add-result', 'dashicons-plus', 'Настроить результаты')}
                        ${renderQuickAction('preview', 'dashicons-visibility', 'Предпросмотр')}
                    </div>
                </div>
                
                <div class="shortcode-section">
                    <h3>
                        <span class="dashicons dashicons-editor-code"></span>
                        Шорткод для вставки
                    </h3>
                    <div class="shortcode-container">
                        <input type="text" id="shortcode-input" class="shortcode-input" value="[personality_test id=&quot;${currentTest.id}&quot;]" readonly>
                        <button id="copy-shortcode-btn" class="copy-shortcode-btn">
                            <span class="dashicons dashicons-clipboard"></span>
                            Копировать
                        </button>
                    </div>
                </div>
                
                ${renderRecentActivity(currentTest)}
                
                ${stats.tips.length > 0 ? `
                    <div class="tips-section">
                        <h3>
                            <span class="dashicons dashicons-info"></span>
                            Советы
                        </h3>
                        <div class="tips-list">
                            ${stats.tips.map(tip => renderTip(tip)).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
            
            <!-- Модальное окно для редактирования -->
            <div id="edit-modal" class="modal">
                <div class="modal-content">
                    <h3 id="modal-title">Редактировать</h3>
                    <form id="edit-form">
                        <div class="modal-form-group">
                            <label for="edit-field-value">Значение:</label>
                            <input type="text" id="edit-field-value" class="regular-text">
                        </div>
                        <div class="modal-actions">
                            <button type="button" id="cancel-edit-btn" class="modal-btn modal-btn-secondary">Отмена</button>
                            <button type="submit" class="modal-btn modal-btn-primary">
                                Сохранить
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Модальное окно для редактирования цели -->
            <div id="edit-target-modal" class="modal">
                <div class="modal-content">
                    <h3 id="modal-title-target">Редактировать цель</h3>
                    <form id="edit-target-form">
                        <div class="modal-form-group">
                            <label for="target-value">Целевое значение:</label>
                            <input type="number" id="target-value" min="1" value="10">
                        </div>
                        <div class="modal-actions">
                            <button type="button" id="cancel-edit-target-btn" class="modal-btn modal-btn-secondary">Отмена</button>
                            <button type="submit" class="modal-btn modal-btn-primary">
                                Сохранить
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Модальное окно для редактирования отображения типов профилей -->
            <div id="edit-profile-types-modal" class="modal">
                <div class="modal-content">
                    <h3>Отображение типов профилей</h3>
                    <form id="edit-profile-types-form">
                        <div class="modal-form-group">
                            <label>
                                <input type="checkbox" id="show-single-profiles" ${currentTest.settings?.showSingleProfiles === true ? 'checked' : ''}>
                                Профили по 1 категории
                            </label>
                        </div>
                        <div class="modal-form-group">
                            <label>
                                <input type="checkbox" id="show-dual-profiles" ${currentTest.settings?.showDualProfiles === true ? 'checked' : ''}>
                                Профили по 2 категориям
                            </label>
                        </div>
                        <div class="modal-form-group disabled">
                            <label>
                                <input type="checkbox" id="show-range-profiles" disabled>
                                Профили по диапазону (временно недоступно)
                            </label>
                            <p class="description" style="margin-top: 4px; color: #9ca3af; font-size: 13px;">
                                Эта функция будет доступна в будущих версиях
                            </p>
                        </div>
                        <div class="modal-actions">
                            <button type="button" id="cancel-edit-profile-types-btn" class="modal-btn modal-btn-secondary">Отмена</button>
                            <button type="submit" class="modal-btn modal-btn-primary">
                                Сохранить
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        container.innerHTML = html;
        
        // Инициализация обработчиков
        initOverviewHandlers(currentTest);
    };
    
    /**
     * Расчёт статистики теста
     */
    function calculateTestStats(currentTest) {
        const categoriesCount = currentTest.categories?.length || 0;
        const questionsCount = currentTest.questions?.length || 0;
        const results = currentTest.results || [];
        
        // Получаем целевые значения из настроек теста (или дефолтные)
        const settings = currentTest.settings ? currentTest.settings : {};
        const targetCategories = settings.target_categories || 6;
        const targetQuestions = settings.target_questions || 45;
        
        // Расчёт прогресса
        const categoriesProgress = Math.min(100, Math.round((categoriesCount / targetCategories) * 100));
        const questionsProgress = Math.min(100, Math.round((questionsCount / targetQuestions) * 100));
        
        // === ДИНАМИЧЕСКИЙ РАСЧЁТ ПРОФИЛЕЙ РЕЗУЛЬТАТОВ ===
        const profilesStats = calculateProfilesStats(results, categoriesCount, settings);
        
        // Советы
        const tips = [];
        if (categoriesCount < targetCategories) {
            tips.push({
                title: 'Добавьте категории',
                text: `Создайте ещё ${targetCategories - categoriesCount} категорий для полноценного теста`
            });
        }
        if (questionsCount < targetQuestions) {
            tips.push({
                title: 'Добавьте вопросы',
                text: `Добавьте ещё ${targetQuestions - questionsCount} вопросов для повышения точности`
            });
        }
        if (profilesStats.totalCreated === 0 && profilesStats.totalTarget > 0) {
            tips.push({
                title: 'Настройте результаты',
                text: 'Создайте профили результатов, чтобы тест показывал итоги прохождения'
            });
        }
        
        return {
            categories: { 
                count: categoriesCount, 
                progress: categoriesProgress, 
                target: targetCategories,
                info: 'Категории определяют оси измерения в тесте. Для личностного теста обычно нужно 4-8 категорий.'
            },
            questions: { 
                count: questionsCount, 
                progress: questionsProgress, 
                target: targetQuestions,
                info: 'Вопросы собирают данные от проходящего. Рекомендуется 40-50 вопросов для точных результатов.'
            },
            results: profilesStats,
            tips: tips
        };
    }
    
    /**
     * ДИНАМИЧЕСКИЙ РАСЧЁТ ПРОФИЛЕЙ РЕЗУЛЬТАТОВ
     * ВАЖНО: по умолчанию все типы СКРЫТЫ (только если явно включены = true)
     */
    function calculateProfilesStats(results, categoriesCount, settings) {
        // Разделяем результаты по типам
        const singleProfiles = results.filter(r => r.rule_type === 'single');
        const dualProfiles = results.filter(r => r.rule_type === 'dual');
        const rangeProfiles = results.filter(r => r.rule_type === 'range');
        
        // Проверяем, какие типы отображать (ТОЛЬКО если явно включены)
        const showSingle = settings?.showSingleProfiles === true;
        const showDual = settings?.showDualProfiles === true;
        const showRange = false;
        
        // === РАСЧЁТ НЕОБХОДИМЫХ ПРОФИЛЕЙ ===
        
        // 1. Профили по 1 категории: нужно = количество категорий
        const targetSingle = categoriesCount;
        const createdSingle = singleProfiles.length;
        const progressSingle = targetSingle > 0 ? Math.min(100, Math.round((createdSingle / targetSingle) * 100)) : 0;
        
        // 2. Профили по 2 категориям: нужно = комбинации из 2 по количеству категорий
        const targetDual = categoriesCount >= 2 ? Math.floor(categoriesCount * (categoriesCount - 1) / 2) : 0;
        const createdDual = dualProfiles.length;
        const progressDual = targetDual > 0 ? Math.min(100, Math.round((createdDual / targetDual) * 100)) : 0;
        
        // 3. Профили по диапазону: ВСЕГДА СКРЫТЫ
        const targetRange = 0;
        const createdRange = 0;
        const progressRange = 0;
        
        // Общий прогресс — учитываем только отображаемые типы
        let totalTarget = 0;
        let totalCreated = 0;
        
        if (showSingle) {
            totalTarget += targetSingle;
            totalCreated += createdSingle;
        }
        if (showDual) {
            totalTarget += targetDual;
            totalCreated += createdDual;
        }
        
        const totalProgress = totalTarget > 0 ? Math.min(100, Math.round((totalCreated / totalTarget) * 100)) : 0;
        
        return {
            single: {
                created: createdSingle,
                target: targetSingle,
                progress: progressSingle,
                show: showSingle,
                info: `Профили для каждой отдельной категории. Например: "Вы — Хоббит", "Вы — Эльф".`
            },
            dual: {
                created: createdDual,
                target: targetDual,
                progress: progressDual,
                show: showDual,
                info: `Профили для комбинаций 2 категорий. Например: "Эльф + Человек", "Гном + Волшебник".`
            },
            range: {
                created: createdRange,
                target: targetRange,
                progress: progressRange,
                show: showRange,
                info: `Профили по диапазонам баллов. Например: "0-20 баллов", "21-40 баллов", и т.д.`
            },
            totalCreated: totalCreated,
            totalTarget: totalTarget,
            totalProgress: totalProgress,
            anyShown: showSingle || showDual
        };
    }
    
    /**
     * Рендеринг карточки вопросов
     */
    function renderQuestionsCard(data) {
        return `
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-title-wrapper">
                        <h4 class="stat-card-title">Вопросы</h4>
                        <div class="tooltip">
                            <span class="stat-card-info-icon">
                                <span class="dashicons dashicons-info"></span>
                            </span>
                            <span class="tooltip-text">${escapeHtml(data.info)}</span>
                        </div>
                    </div>
                    <span class="stat-card-edit-icon" data-type="questions">
                        <span class="dashicons dashicons-edit"></span>
                    </span>
                </div>
                <div class="stat-card-count">
                    <div class="stat-card-number">${data.count}</div>
                    <div class="stat-card-subtitle">из ${data.target}</div>
                </div>
                <div class="progress-section">
                    <div class="progress-label">
                        <span>Прогресс</span>
                        <span>${data.progress}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${data.progress}%;"></div>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Рендеринг карточки категорий
     */
    function renderCategoriesCard(data) {
        return `
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-title-wrapper">
                        <h4 class="stat-card-title">Категории</h4>
                        <div class="tooltip">
                            <span class="stat-card-info-icon">
                                <span class="dashicons dashicons-info"></span>
                            </span>
                            <span class="tooltip-text">${escapeHtml(data.info)}</span>
                        </div>
                    </div>
                    <span class="stat-card-edit-icon" data-type="categories">
                        <span class="dashicons dashicons-edit"></span>
                    </span>
                </div>
                <div class="stat-card-count">
                    <div class="stat-card-number">${data.count}</div>
                    <div class="stat-card-subtitle">из ${data.target}</div>
                </div>
                <div class="progress-section">
                    <div class="progress-label">
                        <span>Прогресс</span>
                        <span>${data.progress}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${data.progress}%;"></div>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Рендеринг карточки результатов (С ВОЗМОЖНОСТЬЮ СКРЫТИЯ ТИПОВ)
     */
    function renderResultsCard(data, currentTest) {
        // Если ни один тип не отображается — показываем кнопку
        if (!data.anyShown) {
            return `
                <div class="stat-card">
                    <div class="stat-card-header">
                        <div class="stat-card-title-wrapper">
                            <h4 class="stat-card-title">Профили результатов</h4>
                            <div class="tooltip">
                                <span class="stat-card-info-icon">
                                    <span class="dashicons dashicons-info"></span>
                                </span>
                                <span class="tooltip-text">Профили результатов определяют, какой текст показывать при разных комбинациях баллов. Выберите типы профилей для отслеживания.</span>
                            </div>
                        </div>
                        <span class="stat-card-edit-icon" data-type="profile-types">
                            <span class="dashicons dashicons-edit"></span>
                        </span>
                    </div>
                    <div class="stat-card-count">
                        <div class="stat-card-number">—</div>
                        <div class="stat-card-subtitle">Профиль не выбран</div>
                    </div>
                    <div class="add-tracking-section">
                        <button id="add-tracking-btn" class="add-tracking-btn">
                            <span class="dashicons dashicons-plus"></span>
                            Добавить отслеживание профилей
                        </button>
                    </div>
                </div>
            `;
        }
        
        // Если есть отображаемые типы — показываем прогресс
        return `
            <div class="stat-card">
                <div class="stat-card-header">
                    <div class="stat-card-title-wrapper">
                        <h4 class="stat-card-title">Профили результатов</h4>
                        <div class="tooltip">
                            <span class="stat-card-info-icon">
                                <span class="dashicons dashicons-info"></span>
                            </span>
                            <span class="tooltip-text">Профили результатов определяют, какой текст показывать при разных комбинациях баллов. Выберите типы профилей для отслеживания.</span>
                        </div>
                    </div>
                    <span class="stat-card-edit-icon" data-type="profile-types">
                        <span class="dashicons dashicons-edit"></span>
                    </span>
                </div>
                <div class="stat-card-count">
                    <div class="stat-card-number">${data.totalCreated || 0}</div>
                    <div class="stat-card-subtitle">из ${data.totalTarget || 0}</div>
                </div>
                <div class="progress-section">
                    <div class="progress-label">
                        <span>Прогресс</span>
                        <span>${data.totalProgress}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${data.totalProgress}%;"></div>
                    </div>
                </div>
                
                <!-- Профили по 1 категории -->
                ${data.single.show && data.single.target > 0 ? `
                    <div class="profile-type-section">
                        <div class="profile-type-label">По 1 категории</div>
                        <div class="stat-card-subtitle">${data.single.created} из ${data.single.target}</div>
                        <div class="progress-section">
                            <div class="progress-label">
                                <span>Прогресс</span>
                                <span>${data.single.progress}%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${data.single.progress}%;"></div>
                            </div>
                        </div>
                    </div>
                ` : ''}
                
                <!-- Профили по 2 категориям -->
                ${data.dual.show && data.dual.target > 0 ? `
                    <div class="profile-type-section">
                        <div class="profile-type-label">По 2 категориям</div>
                        <div class="stat-card-subtitle">${data.dual.created} из ${data.dual.target}</div>
                        <div class="progress-section">
                            <div class="progress-label">
                                <span>Прогресс</span>
                                <span>${data.dual.progress}%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${data.dual.progress}%;"></div>
                            </div>
                        </div>
                    </div>
                ` : ''}
                
                ${data.totalCreated === 0 ? `
                    <div class="progress-section">
                        <div style="color: #ef4444; font-size: 14px; margin-top: 8px;">
                            Нет профилей результатов
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    /**
     * Рендеринг последних изменений
     */
    function renderRecentActivity(currentTest) {
        // Получаем последние 5 изменений (заглушка - в реальности нужно получать из БД)
        const recentChanges = [
            { type: 'question', title: 'Добавлен вопрос #1', time: '2 минуты назад' },
            { type: 'category', title: 'Создана категория "Эльфы"', time: '10 минут назад' },
            { type: 'question', title: 'Обновлён вопрос #5', time: '30 минут назад' },
            { type: 'result', title: 'Настроен профиль "Хоббит"', time: '1 час назад' },
            { type: 'settings', title: 'Обновлены настройки теста', time: '2 часа назад' }
        ];
        
        return `
            <div class="recent-activity-section">
                <h3>
                    <span class="dashicons dashicons-update"></span>
                    Последние изменения
                </h3>
                <div class="activity-list">
                    ${recentChanges.map(change => `
                        <div class="activity-item">
                            <div class="activity-icon">
                                <span class="dashicons dashicons-${change.type === 'question' ? 'editor-ul' : change.type === 'category' ? 'category' : change.type === 'result' ? 'awards' : 'admin-settings'}"></span>
                            </div>
                            <div class="activity-content">
                                <div class="activity-title">${escapeHtml(change.title)}</div>
                                <div class="activity-meta">${escapeHtml(change.time)}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    /**
     * Рендеринг быстрого действия
     */
    function renderQuickAction(action, icon, text) {
        return `
            <button class="quick-action-btn" data-action="${action}">
                <span class="dashicons ${icon}"></span>
                ${text}
            </button>
        `;
    }
    
    /**
     * Рендеринг совета
     */
    function renderTip(tip) {
        return `
            <div class="tip-item">
                <strong>💡 ${escapeHtml(tip.title)}</strong>
                <p>${escapeHtml(tip.text)}</p>
            </div>
        `;
    }
    
    /**
     * Инициализация обработчиков
     */
    function initOverviewHandlers(currentTest) {
        // Копирование шорткода
        document.getElementById('copy-shortcode-btn')?.addEventListener('click', function() {
            const input = document.getElementById('shortcode-input');
            input.select();
            input.setSelectionRange(0, 99999);
            
            try {
                document.execCommand('copy');
                
                const originalText = this.innerHTML;
                this.innerHTML = '<span class="dashicons dashicons-yes"></span> Скопировано!';
                
                setTimeout(() => {
                    this.innerHTML = originalText;
                }, 2000);
            } catch (err) {
                alert('Не удалось скопировать шорткод');
            }
        });
        
        // Обработка быстрых действий
        document.querySelectorAll('.quick-action-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const action = this.dataset.action;
                
                switch(action) {
                    case 'add-category':
                        switchToTab('categories');
                        break;
                    case 'add-question':
                        switchToTab('questions');
                        break;
                    case 'add-result':
                        switchToTab('results-single');
                        break;
                    case 'preview':
                        alert('Предпросмотр будет доступен в следующей версии');
                        break;
                }
            });
        });
        
        // Редактирование заголовка
        document.getElementById('edit-title-btn')?.addEventListener('click', function(e) {
            e.stopPropagation();
            showEditModal('title', currentTest.name, function(newValue) {
                updateTestField(currentTest.id, 'name', newValue)
                    .then(() => {
                        currentTest.name = newValue;
                        window.ptb.renderOverviewTab(document.getElementById('tab-content'), currentTest);
                        alert('Название успешно обновлено!');
                    })
                    .catch(error => {
                        console.error('Ошибка сохранения:', error);
                        alert('Не удалось сохранить изменения');
                    });
            });
        });
        
        // Редактирование описания
        document.getElementById('edit-description-btn')?.addEventListener('click', function(e) {
            e.stopPropagation();
            showEditModal('description', currentTest.description || '', function(newValue) {
                updateTestField(currentTest.id, 'description', newValue)
                    .then(() => {
                        currentTest.description = newValue;
                        window.ptb.renderOverviewTab(document.getElementById('tab-content'), currentTest);
                        alert('Описание успешно обновлено!');
                    })
                    .catch(error => {
                        console.error('Ошибка сохранения:', error);
                        alert('Не удалось сохранить изменения');
                    });
            });
        });
        
        // Обработка переключения статуса
        document.getElementById('toggle-status-btn')?.addEventListener('click', function() {
            const newStatus = currentTest.status === 'published' ? 'draft' : 'published';
            const statusText = newStatus === 'published' ? 'Опубликован' : 'Черновик';
            const buttonText = newStatus === 'published' ? 'В черновик' : 'Опубликовать';
            
            // Обновляем статус через API
            updateTestField(currentTest.id, 'status', newStatus)
                .then(() => {
                    // Обновляем текущий тест
                    currentTest.status = newStatus;
                    
                    // Обновляем бейдж и кнопку
                    const badge = document.querySelector('.test-status-badge');
                    const button = document.getElementById('toggle-status-btn');
                    
                    badge.className = `test-status-badge test-status-${newStatus}`;
                    badge.textContent = statusText;
                    button.textContent = buttonText;
                    
                    // Показываем уведомление
                    alert(`Тест ${statusText.toLowerCase()}!`);
                })
                .catch(error => {
                    console.error('Ошибка переключения статуса:', error);
                    alert('Не удалось изменить статус теста');
                });
        });
        
        // Обработка редактирования целей — МГНОВЕННОЕ СОХРАНЕНИЕ БЕЗ ПЕРЕРЕНДЕРИНГА
        document.querySelectorAll('.stat-card-edit-icon').forEach(icon => {
            icon.addEventListener('click', function() {
                const type = this.dataset.type;
                currentModalType = type;
                
                if (type === 'profile-types') {
                    // Открываем модальное окно для редактирования типов профилей
                    const modal = document.getElementById('edit-profile-types-modal');
                    modal.classList.add('active');
                    
                    // УДАЛЯЕМ СТАРЫЙ ОБРАБОТЧИК ПЕРЕД ДОБАВЛЕНИЕМ НОВОГО
                    const form = document.getElementById('edit-profile-types-form');
                    form.onsubmit = null;
                    
                    // Обработчик отмены
                    document.getElementById('cancel-edit-profile-types-btn').onclick = function() {
                        modal.classList.remove('active');
                    };
                    
                    // Обработчик закрытия по клику вне окна
                    modal.onclick = function(e) {
                        if (e.target === modal) {
                            modal.classList.remove('active');
                        }
                    };
                    
                    // Обработчик отправки формы — С ПЕРЕРЕНДЕРИНГОМ (нужен для изменения структуры карточки)
                    form.onsubmit = function(e) {
                        e.preventDefault();
                        
                        const saveBtn = form.querySelector('.modal-btn-primary');
                        const originalText = saveBtn.innerHTML;
                        
                        // Меняем текст кнопки
                        saveBtn.disabled = true;
                        saveBtn.innerHTML = 'Сохранение...';
                        
                        const showSingle = document.getElementById('show-single-profiles').checked;
                        const showDual = document.getElementById('show-dual-profiles').checked;
                        const showRange = false;
                        
                        let newSettings = {
                            ...currentTest.settings,
                            showSingleProfiles: showSingle,
                            showDualProfiles: showDual,
                            showRangeProfiles: showRange
                        };
                        
                        updateTestField(currentTest.id, 'settings', newSettings)
                            .then(response => {
                                if (response.success) {
                                    currentTest.settings = newSettings;
                                    
                                    // ПЕРЕРЕНДЕРИНГ ТОЛЬКО ДЛЯ ПРОФИЛЕЙ (нужен для изменения структуры карточки)
                                    const container = document.getElementById('tab-content');
                                    if (container) {
                                        window.ptb.renderOverviewTab(container, currentTest);
                                    }
                                    
                                    modal.classList.remove('active');
                                    alert('Настройки отображения профилей обновлены!');
                                } else {
                                    throw new Error(response.message || 'Ошибка сохранения');
                                }
                            })
                            .catch(error => {
                                console.error('Ошибка сохранения:', error);
                                alert('Не удалось сохранить настройки: ' + error.message);
                            })
                            .finally(() => {
                                // Восстанавливаем кнопку
                                saveBtn.disabled = false;
                                saveBtn.innerHTML = originalText;
                            });
                    };
                    
                    return;
                }
                
                // Обработка редактирования других целей (категории, вопросы) — МГНОВЕННОЕ СОХРАНЕНИЕ БЕЗ ПЕРЕРЕНДЕРИНГА
                const modal = document.getElementById('edit-target-modal');
                const form = document.getElementById('edit-target-form');
                const targetInput = document.getElementById('target-value');
                const modalTitle = document.getElementById('modal-title-target');
                
                // УДАЛЯЕМ СТАРЫЕ ОБРАБОТЧИКИ
                form.onsubmit = null;
                document.getElementById('cancel-edit-target-btn').onclick = null;
                
                // Устанавливаем заголовок и текущее значение
                if (type === 'categories') {
                    modalTitle.textContent = 'Редактировать цель: Категории';
                    targetInput.value = currentTest.settings?.target_categories || 6;
                } else if (type === 'questions') {
                    modalTitle.textContent = 'Редактировать цель: Вопросы';
                    targetInput.value = currentTest.settings?.target_questions || 45;
                }
                
                // Показываем модальное окно
                modal.classList.add('active');
                
                // Обработчик отмены
                document.getElementById('cancel-edit-target-btn').onclick = function() {
                    modal.classList.remove('active');
                };
                
                // Обработчик закрытия по клику вне окна
                modal.onclick = function(e) {
                    if (e.target === modal) {
                        modal.classList.remove('active');
                    }
                };
                
                // Обработчик отправки формы — МГНОВЕННОЕ СОХРАНЕНИЕ БЕЗ ПЕРЕРЕНДЕРИНГА
                form.onsubmit = function(e) {
                    e.preventDefault();
                    
                    const saveBtn = form.querySelector('.modal-btn-primary');
                    const originalText = saveBtn.innerHTML;
                    
                    // Меняем текст кнопки на "Сохранение..."
                    saveBtn.disabled = true;
                    saveBtn.innerHTML = 'Сохранение...';
                    
                    const newValue = parseInt(targetInput.value);
                    
                    if (newValue < 1) {
                        alert('Целевое значение должно быть больше 0');
                        // Восстанавливаем кнопку
                        saveBtn.disabled = false;
                        saveBtn.innerHTML = originalText;
                        return;
                    }
                    
                    // Сохраняем ВСЕ настройки
                    let settings = currentTest.settings ? { ...currentTest.settings } : {};
                    
                    if (type === 'categories') {
                        settings.target_categories = newValue;
                    } else if (type === 'questions') {
                        settings.target_questions = newValue;
                    }
                    
                    // МГНОВЕННОЕ СОХРАНЕНИЕ БЕЗ ПЕРЕРЕНДЕРИНГА
                    updateTestField(currentTest.id, 'settings', settings)
                        .then(() => {
                            // Обновляем только текущий объект — БЕЗ ПЕРЕРЕНДЕРИНГА!
                            currentTest.settings = settings;
                            
                            // Закрываем модалку
                            modal.classList.remove('active');
                            
                            // Показываем уведомление
                            alert('Цель успешно обновлена!');
                        })
                        .catch(error => {
                            console.error('Ошибка сохранения:', error);
                            alert('Не удалось сохранить изменения');
                        })
                        .finally(() => {
                            // Восстанавливаем кнопку
                            saveBtn.disabled = false;
                            saveBtn.innerHTML = originalText;
                        });
                };
            });
        });
        
        // Обработка кнопки "Добавить отслеживание профилей" — С ПЕРЕРЕНДЕРИНГОМ
        document.getElementById('add-tracking-btn')?.addEventListener('click', function() {
            const modal = document.getElementById('edit-profile-types-modal');
            modal.classList.add('active');
            
            // УДАЛЯЕМ СТАРЫЙ ОБРАБОТЧИК ПЕРЕД ДОБАВЛЕНИЕМ НОВОГО
            const form = document.getElementById('edit-profile-types-form');
            form.onsubmit = null;
            
            // Обработчик отмены
            document.getElementById('cancel-edit-profile-types-btn').onclick = function() {
                modal.classList.remove('active');
            };
            
            // Обработчик закрытия по клику вне окна
            modal.onclick = function(e) {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            };
            
            // Обработчик отправки формы — С ПЕРЕРЕНДЕРИНГОМ
            form.onsubmit = function(e) {
                e.preventDefault();
                
                const saveBtn = form.querySelector('.modal-btn-primary');
                const originalText = saveBtn.innerHTML;
                
                // Меняем текст кнопки
                saveBtn.disabled = true;
                saveBtn.innerHTML = 'Сохранение...';
                
                const showSingle = document.getElementById('show-single-profiles').checked;
                const showDual = document.getElementById('show-dual-profiles').checked;
                const showRange = false;
                
                let newSettings = {
                    ...currentTest.settings,
                    showSingleProfiles: showSingle,
                    showDualProfiles: showDual,
                    showRangeProfiles: showRange
                };
                
                updateTestField(currentTest.id, 'settings', newSettings)
                    .then(response => {
                        if (response.success) {
                            currentTest.settings = newSettings;
                            
                            // ПЕРЕРЕНДЕРИНГ ДЛЯ ИЗМЕНЕНИЯ СТРУКТУРЫ КАРТОЧКИ
                            const container = document.getElementById('tab-content');
                            if (container) {
                                window.ptb.renderOverviewTab(container, currentTest);
                            }
                            
                            modal.classList.remove('active');
                            alert('Настройки отображения профилей обновлены!');
                        } else {
                            throw new Error(response.message || 'Ошибка сохранения');
                        }
                    })
                    .catch(error => {
                        console.error('Ошибка сохранения:', error);
                        alert('Не удалось сохранить настройки: ' + error.message);
                    })
                    .finally(() => {
                        // Восстанавливаем кнопку
                        saveBtn.disabled = false;
                        saveBtn.innerHTML = originalText;
                    });
            };
        });
        
        // Закрытие модальных окон по клику вне
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            });
        });
    }
    
    /**
     * Показать модальное окно редактирования
     */
    function showEditModal(fieldType, currentValue, onSaveCallback) {
        const modal = document.getElementById('edit-modal');
        const form = document.getElementById('edit-form');
        const input = document.getElementById('edit-field-value');
        const title = document.getElementById('modal-title');
        
        // Устанавливаем заголовок и текущее значение
        if (fieldType === 'title') {
            title.textContent = 'Редактировать название';
            input.value = currentValue;
        } else if (fieldType === 'description') {
            title.textContent = 'Редактировать описание';
            input.value = currentValue;
            // Заменяем инпут на текстареа для описания
            const textarea = document.createElement('textarea');
            textarea.id = 'edit-field-value';
            textarea.className = 'regular-text';
            textarea.value = currentValue;
            textarea.style.minHeight = '100px';
            input.parentNode.replaceChild(textarea, input);
        }
        
        // Показываем модальное окно
        modal.classList.add('active');
        
        // Обработчик отмены
        document.getElementById('cancel-edit-btn').onclick = function() {
            modal.classList.remove('active');
        };
        
        // Обработчик отправки формы
        form.onsubmit = function(e) {
            e.preventDefault();
            
            const newValue = document.getElementById('edit-field-value').value.trim();
            
            if (!newValue) {
                alert('Поле не может быть пустым');
                return;
            }
            
            // Вызываем колбэк для сохранения
            onSaveCallback(newValue);
            
            // Закрываем модалку
            modal.classList.remove('active');
        };
    }
    
    /**
     * Обновление поля теста через API
     */
    function updateTestField(testId, field, value) {
        return fetch(ptbAdminSettings.apiUrl + `/tests/${testId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': ptbAdminSettings.nonce
            },
            body: JSON.stringify({
                [field]: value
            })
        }).then(response => {
            if (!response.ok) {
                throw new Error('Ошибка сети: ' + response.status);
            }
            return response.json();
        }).catch(error => {
            console.error('Ошибка запроса:', error);
            throw error;
        });
    }
    
    /**
     * Переключение на вкладку
     */
    function switchToTab(tabName) {
        document.querySelectorAll('.ptb-editor-tabs button').forEach(btn => {
            if (btn.dataset.tab === tabName) {
                document.querySelectorAll('.ptb-editor-tabs button').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                window.ptb.activeTab = tabName;
                window.ptb.renderTabContent(tabName);
            }
        });
    }
    
    /**
     * Экранирование HTML
     */
    function escapeHtml(text) {
        if (typeof text !== 'string') return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
})(jQuery);