/**
 * Функции-шаблоны для рендеринга вопросов
 */

// Вспомогательная функция экранирования HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Форма добавления нового вопроса
function renderAddQuestionForm() {
    return `
    <div class="question-card">
        <div class="question-number-badge">+</div>
        <div class="question-content">
            <div class="form-group">
                <label class="form-label">Текст вопроса *</label>
                <textarea class="form-textarea regular-text" placeholder="Введите текст вопроса..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Изображение к вопросу</label>
                <div class="image-preview">
                    <button type="button" class="button button-secondary upload-button">
                        <span class="dashicons dashicons-upload"></span> Загрузить изображение
                    </button>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Варианты ответов</label>
                <div class="answer-list">
                    <div class="answer-item">
                        <div class="answer-inputs">
                            <div class="answer-text">
                                <input type="text" class="form-input regular-text" placeholder="Текст ответа" value="Вариант 1">
                            </div>
                            <div class="answer-categories-list">
                                <div class="answer-category-item">
                                    <select class="form-select answer-category" name="category_id">
                                        <option value="">Выбрать категорию...</option>
                                    </select>
                                    <input type="number" class="form-input answer-weight" name="weight" value="1" min="1" max="10" placeholder="Вес">
                                    <button type="button" class="remove-category-btn">
                                        <span class="dashicons dashicons-no"></span>
                                    </button>
                                </div>
                            </div>
                            <button type="button" class="add-category-btn">
                                <span class="dashicons dashicons-plus"></span> Добавить категорию
                            </button>
                        </div>
                        <button type="button" class="remove-answer-btn">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </div>
                </div>
                <button type="button" class="button button-secondary" id="add-answer-option-btn">
                    <span class="dashicons dashicons-plus"></span> Добавить вариант
                </button>
            </div>
            <div class="form-actions">
                <button type="button" class="button button-primary" id="create-question-btn">Создать вопрос</button>
            </div>
        </div>
    </div>
    `;
}

// Список существующих вопросов
function renderQuestionsList(questions, categories) {
    if (!questions || questions.length === 0) {
        return `
        <div class="ptb-empty-state">
            <p>Нет вопросов. Добавьте первый вопрос выше.</p>
        </div>
        `;
    }
    
    // Сортируем вопросы по sort_order
    const sortedQuestions = [...questions].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    
    let html = `
    <div class="questions-toolbar">
        <h3 class="questions-list-title">Существующие вопросы (${sortedQuestions.length})</h3>
        <div class="questions-actions">
            <button type="button" class="button button-secondary" id="sort-questions-btn">
                <span class="dashicons dashicons-sort"></span> Сортировать вопросы
            </button>
        </div>
    </div>
    <div class="questions-sortable-list" id="questions-sortable-list">
    `;
    
    sortedQuestions.forEach((q, index) => {
        html += renderQuestionItem(q, index, categories);
    });
    
    html += `</div>`;
    
    return html;
}

// Карточка вопроса
function renderQuestionItem(question, index, categories) {
    const answerCount = question.answers?.length || 0;
    
    // Получаем уникальные категории из ответов
    const uniqueCategories = [...new Set(question.answers?.flatMap(a => {
        try {
            const weights = JSON.parse(a.category_weights || '[]');
            return weights.map(w => w.category_id);
        } catch (e) {
            return a.category_id ? [a.category_id] : [];
        }
    }).filter(Boolean) || [])];
    
    const categoryNames = uniqueCategories.map(catId => {
        const cat = categories.find(c => c.id == catId);
        return cat ? cat.code : '';
    }).join(', ');
    
    return `
    <div class="question-card sortable-item" data-id="${question.id}" data-sort-order="${question.sort_order || index}">
        <div class="drag-handle-btn" data-question-id="${question.id}">
            <span class="dashicons dashicons-menu"></span>
        </div>
        <div class="question-number-badge">${index + 1}</div>
        <div class="question-content">
            <div class="question-header">
                <h4 class="question-title">${escapeHtml(question.question_text)}</h4>
                <div class="question-header-actions">
                    <div class="question-stats">
                        <span class="stat-badge">
                            <span class="dashicons dashicons-yes"></span> ${answerCount} ответ${answerCount === 1 ? '' : answerCount < 5 ? 'а' : 'ов'}
                        </span>
                        ${categoryNames ? `
                        <span class="stat-badge stat-categories">
                            <span class="dashicons dashicons-tag"></span> ${categoryNames}
                        </span>
                        ` : ''}
                    </div>
                    <button type="button" class="button button-secondary toggle-question-btn" data-question-id="${question.id}">
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                </div>
            </div>
            <div class="question-body">
                <div class="form-group">
                    <label class="form-label">Текст вопроса</label>
                    <p class="question-text-preview">
                        ${escapeHtml(question.question_text)}
                    </p>
                </div>
                <div class="form-group">
                    <label class="form-label">Варианты ответов</label>
                    <div class="answer-list">
                        ${question.answers?.map(answer => {
                            // Парсим категории из ответа
                            let categoryWeights = [];
                            try {
                                categoryWeights = JSON.parse(answer.category_weights || '[]');
                            } catch (e) {
                                categoryWeights = answer.category_id ? [{category_id: answer.category_id, weight: answer.points}] : [];
                            }
                            
                            return `
                            <div class="answer-item">
                                <div class="answer-inputs">
                                    <div class="answer-text">
                                        <input type="text" class="form-input regular-text" value="${escapeHtml(answer.answer_text)}" readonly>
                                    </div>
                                    <div class="answer-categories-list">
                                        ${categoryWeights.length > 0 ? categoryWeights.map(cw => {
                                            const category = categories.find(c => c.id == cw.category_id);
                                            return `
                                            <div class="answer-category-item">
                                                <span class="category-display">${category ? category.code : '—'}</span>
                                                <span class="weight-display">Вес: ${cw.weight}</span>
                                            </div>
                                            `;
                                        }).join('') : `
                                        <div class="answer-category-item">
                                            <span class="category-display">—</span>
                                            <span class="weight-display">Вес: 0</span>
                                        </div>
                                        `}
                                    </div>
                                </div>
                                <button type="button" class="remove-answer-btn" data-answer-id="${answer.id}">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                            `;
                        }).join('') || `
                        <div class="ptb-empty-state" style="padding: 15px 0; font-size: 0.9rem; color: #6b7280;">
                            Нет вариантов ответов
                        </div>
                        `}
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="button button-primary edit-question-btn" data-id="${question.id}">
                        <span class="dashicons dashicons-edit"></span> Редактировать вопрос и ответы
                    </button>
                    <button type="button" class="button button-secondary clone-question-btn" data-id="${question.id}">
                        <span class="dashicons dashicons-admin-page"></span> Клонировать
                    </button>
                    <button type="button" class="button ptb-danger delete-question-btn" data-id="${question.id}">Удалить</button>
                </div>
            </div>
        </div>
    </div>
    `;
}

// Форма редактирования вопроса и ответов (объединённая)
function renderEditQuestionAndAnswersForm(question, categories) {
    return `
    <div class="question-card">
        <div class="question-number-badge">✎</div>
        <div class="question-content">
            <div class="form-group">
                <label class="form-label">Текст вопроса *</label>
                <textarea class="form-textarea regular-text" id="edit-question-text">${escapeHtml(question.question_text)}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Варианты ответов</label>
                <div class="answer-sortable-list">
                    ${question.answers?.map((answer, idx) => {
                        // Парсим категории из ответа
                        let categoryWeights = [];
                        try {
                            categoryWeights = JSON.parse(answer.category_weights || '[]');
                        } catch (e) {
                            categoryWeights = answer.category_id ? [{category_id: answer.category_id, weight: answer.points}] : [];
                        }
                        
                        return `
                        <div class="answer-item sortable-item" data-id="${answer.id}" data-sort-order="${answer.sort_order || idx}">
                            <div class="answer-drag-handle">
                                <span class="dashicons dashicons-menu"></span>
                            </div>
                            <div class="answer-inputs">
                                <div class="answer-text">
                                    <input type="text" class="form-input regular-text" value="${escapeHtml(answer.answer_text)}">
                                </div>
                                <div class="answer-categories-list">
                                    ${categoryWeights.length > 0 ? categoryWeights.map((cw, i) => {
                                        return `
                                        <div class="answer-category-item">
                                            <select class="form-select answer-category" name="category_id">
                                                <option value="">Выбрать категорию...</option>
                                                ${categories.map(cat => `
                                                <option value="${cat.id}" ${cat.id == cw.category_id ? 'selected' : ''}>
                                                    ${cat.code} - ${cat.name}
                                                </option>
                                                `).join('')}
                                            </select>
                                            <input type="number" class="form-input answer-weight" name="weight" value="${cw.weight}" min="1" max="10" placeholder="Вес">
                                            <button type="button" class="remove-category-btn">
                                                <span class="dashicons dashicons-no"></span>
                                            </button>
                                        </div>
                                        `;
                                    }).join('') : `
                                    <div class="answer-category-item">
                                        <select class="form-select answer-category" name="category_id">
                                            <option value="">Выбрать категорию...</option>
                                            ${categories.map(cat => `
                                            <option value="${cat.id}">
                                                ${cat.code} - ${cat.name}
                                            </option>
                                            `).join('')}
                                        </select>
                                        <input type="number" class="form-input answer-weight" name="weight" value="1" min="1" max="10" placeholder="Вес">
                                        <button type="button" class="remove-category-btn">
                                            <span class="dashicons dashicons-no"></span>
                                        </button>
                                    </div>
                                    `}
                                </div>
                                <button type="button" class="add-category-btn">
                                    <span class="dashicons dashicons-plus"></span> Добавить категорию
                                </button>
                            </div>
                            <button type="button" class="remove-answer-btn" data-answer-id="${answer.id}">
                                <span class="dashicons dashicons-trash"></span>
                            </button>
                        </div>
                        `;
                    }).join('')}
                </div>
                <button type="button" class="button button-secondary" id="add-answer-option-btn" style="margin-top: 10px;">
                    <span class="dashicons dashicons-plus"></span> Добавить вариант
                </button>
            </div>
            <div class="form-actions">
                <button type="button" class="button button-primary save-question-and-answers-btn" data-id="${question.id}">Сохранить</button>
                <button type="button" class="button cancel-edit-btn">Отмена</button>
            </div>
        </div>
    </div>
    `;
}