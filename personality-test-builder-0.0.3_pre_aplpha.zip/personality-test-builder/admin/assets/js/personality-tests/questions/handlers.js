/**
 * Обработчики событий для вопросов
 */

// Глобальные переменные для сортировки
let dragItem = null;
let dragOverItem = null;
let isDragging = false;
let placeholder = null;

// ==================== СВОРАЧИВАНИЕ/РАЗВОРАЧИВАНИЕ ВОПРОСОВ ====================

// Переключение состояния вопроса (свёрнут/развёрнут)
function handleToggleQuestion() {
    const questionId = this.dataset.questionId;
    const questionCard = document.querySelector(`.question-card[data-id="${questionId}"]`);
    
    if (!questionCard) return;
    
    const isCollapsed = questionCard.classList.toggle('collapsed');
    const toggleBtn = questionCard.querySelector('.toggle-question-btn .dashicons');
    
    if (isCollapsed) {
        toggleBtn.classList.remove('dashicons-arrow-down-alt2');
        toggleBtn.classList.add('dashicons-arrow-up-alt2');
    } else {
        toggleBtn.classList.remove('dashicons-arrow-up-alt2');
        toggleBtn.classList.add('dashicons-arrow-down-alt2');
    }
}

// ==================== DRAG & DROP СОРТИРОВКА ВОПРОСОВ ====================

// Создание плейсхолдера для визуальной индикации
function createPlaceholder() {
    const placeholderEl = document.createElement('div');
    placeholderEl.className = 'drag-placeholder';
    placeholderEl.style.height = '4px';
    placeholderEl.style.backgroundColor = '#3b82f6';
    placeholderEl.style.borderRadius = '2px';
    placeholderEl.style.margin = '8px 0';
    placeholderEl.style.opacity = '0.8';
    placeholderEl.style.transition = 'all 0.2s ease';
    return placeholderEl;
}

// Инициализация сортировки вопросов
function initQuestionSort() {
    const sortableList = document.getElementById('questions-sortable-list');
    if (!sortableList) return;
    
    sortableList.addEventListener('mousedown', handleDragStart);
}

// Начало перетаскивания (только при клике на кнопку)
function handleDragStart(e) {
    const dragBtn = e.target.closest('.drag-handle-btn');
    if (!dragBtn) return;
    
    const questionId = dragBtn.dataset.questionId;
    const item = document.querySelector(`.question-card[data-id="${questionId}"]`);
    if (!item) return;
    
    isDragging = true;
    dragItem = item;
    
    const rect = dragItem.getBoundingClientRect();
    
    dragItem.dataset.offsetX = e.clientX - rect.left;
    dragItem.dataset.offsetY = e.clientY - rect.top;
    
    dragItem.style.position = 'fixed';
    dragItem.style.zIndex = '1000';
    dragItem.style.boxShadow = '0 12px 32px rgba(59, 130, 246, 0.3)';
    dragItem.style.opacity = '0.95';
    dragItem.style.width = rect.width + 'px';
    dragItem.style.left = (e.clientX - parseInt(dragItem.dataset.offsetX)) + 'px';
    dragItem.style.top = (e.clientY - parseInt(dragItem.dataset.offsetY)) + 'px';
    dragItem.style.transition = 'none';
    
    placeholder = createPlaceholder();
    dragItem.parentNode.insertBefore(placeholder, dragItem);
    
    document.addEventListener('mousemove', moveDragItem);
    document.addEventListener('mouseup', stopDragging);
    
    e.preventDefault();
    e.stopPropagation();
}

// Перемещение элемента
function moveDragItem(e) {
    if (!isDragging || !dragItem) return;
    
    const x = e.clientX - parseInt(dragItem.dataset.offsetX);
    const y = e.clientY - parseInt(dragItem.dataset.offsetY);
    
    dragItem.style.left = x + 'px';
    dragItem.style.top = y + 'px';
    
    const elements = document.querySelectorAll('.sortable-item:not(.dragging)');
    let targetElement = null;
    
    for (let el of elements) {
        const rect = el.getBoundingClientRect();
        if (e.clientY < rect.bottom && e.clientY > rect.top && el !== dragItem) {
            targetElement = el;
            break;
        }
    }
    
    if (targetElement && targetElement !== dragOverItem) {
        dragOverItem = targetElement;
        
        if (placeholder && placeholder.parentNode) {
            placeholder.parentNode.removeChild(placeholder);
        }
        
        const rect = targetElement.getBoundingClientRect();
        const mouseY = e.clientY;
        const targetMid = rect.top + rect.height / 2;
        
        if (mouseY < targetMid) {
            targetElement.parentNode.insertBefore(placeholder, targetElement);
        } else {
            targetElement.parentNode.insertBefore(placeholder, targetElement.nextSibling);
        }
        
        targetElement.classList.add('drag-target');
        
        elements.forEach(el => {
            if (el !== targetElement && el !== dragItem) {
                el.classList.remove('drag-target');
            }
        });
    }
}

// Завершение перетаскивания
function stopDragging() {
    if (!isDragging || !dragItem) return;
    
    isDragging = false;
    
    document.querySelectorAll('.drag-target').forEach(el => {
        el.classList.remove('drag-target');
    });
    
    if (placeholder && placeholder.parentNode) {
        const parent = placeholder.parentNode;
        const nextSibling = placeholder.nextSibling;
        
        parent.removeChild(placeholder);
        
        if (nextSibling) {
            parent.insertBefore(dragItem, nextSibling);
        } else {
            parent.appendChild(dragItem);
        }
        
        dragItem.style.transition = 'all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1)';
        dragItem.style.position = '';
        dragItem.style.left = '';
        dragItem.style.top = '';
        dragItem.style.width = '';
        dragItem.style.zIndex = '';
        dragItem.style.boxShadow = '';
        dragItem.style.opacity = '';
    }
    
    placeholder = null;
    
    updateQuestionsOrder();
    
    dragItem = null;
    dragOverItem = null;
    
    document.removeEventListener('mousemove', moveDragItem);
    document.removeEventListener('mouseup', stopDragging);
}

// Обновление порядка вопросов в базе данных
function updateQuestionsOrder() {
    const sortableItems = document.querySelectorAll('.questions-sortable-list .sortable-item');
    const updates = [];
    
    sortableItems.forEach((item, index) => {
        const questionId = item.dataset.id;
        const newSortOrder = index;
        const oldSortOrder = parseInt(item.dataset.sortOrder);
        
        if (newSortOrder !== oldSortOrder) {
            updates.push({
                id: questionId,
                sort_order: newSortOrder
            });
            
            item.dataset.sortOrder = newSortOrder;
        }
    });
    
    if (updates.length === 0) return;
    
    const promises = updates.map(update => 
        fetch(ptbAdminSettings.apiUrl + '/questions/' + update.id, {
            method: 'PUT',
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify({ sort_order: update.sort_order })
        })
    );
    
    Promise.all(promises)
        .then(() => {
            updateQuestionNumbers();
        })
        .catch(e => {
            console.error('Ошибка обновления порядка:', e);
            alert('Ошибка обновления порядка вопросов');
        });
}

// Обновление нумерации вопросов на фронтенде
function updateQuestionNumbers() {
    const sortableItems = document.querySelectorAll('.questions-sortable-list .sortable-item');
    sortableItems.forEach((item, index) => {
        const badge = item.querySelector('.question-number-badge');
        if (badge) {
            badge.textContent = index + 1;
        }
    });
}

// ==================== DRAG & DROP СОРТИРОВКА ОТВЕТОВ ====================

// Создание плейсхолдера для ответов
function createAnswerPlaceholder() {
    const placeholderEl = document.createElement('div');
    placeholderEl.className = 'drag-placeholder';
    placeholderEl.style.height = '3px';
    placeholderEl.style.backgroundColor = '#3b82f6';
    placeholderEl.style.borderRadius = '2px';
    placeholderEl.style.margin = '6px 0';
    placeholderEl.style.opacity = '0.8';
    placeholderEl.style.transition = 'all 0.2s ease';
    return placeholderEl;
}

// Инициализация сортировки ответов
function initAnswerSort(container) {
    const sortableList = container || document.querySelector('.answer-sortable-list');
    if (!sortableList) return;
    
    sortableList.addEventListener('mousedown', handleAnswerDragStart);
}

// Начало перетаскивания ответа
function handleAnswerDragStart(e) {
    const dragBtn = e.target.closest('.answer-drag-handle');
    if (!dragBtn) return;
    
    const item = dragBtn.closest('.sortable-item');
    if (!item) return;
    
    isDragging = true;
    dragItem = item;
    
    const rect = dragItem.getBoundingClientRect();
    
    dragItem.dataset.offsetX = e.clientX - rect.left;
    dragItem.dataset.offsetY = e.clientY - rect.top;
    
    dragItem.style.position = 'fixed';
    dragItem.style.zIndex = '1000';
    dragItem.style.boxShadow = '0 8px 24px rgba(59, 130, 246, 0.2)';
    dragItem.style.opacity = '0.9';
    dragItem.style.width = rect.width + 'px';
    dragItem.style.left = (e.clientX - parseInt(dragItem.dataset.offsetX)) + 'px';
    dragItem.style.top = (e.clientY - parseInt(dragItem.dataset.offsetY)) + 'px';
    dragItem.style.transition = 'none';
    
    placeholder = createAnswerPlaceholder();
    dragItem.parentNode.insertBefore(placeholder, dragItem);
    
    document.addEventListener('mousemove', moveAnswerDragItem);
    document.addEventListener('mouseup', stopAnswerDragging);
    
    e.preventDefault();
    e.stopPropagation();
}

// Перемещение элемента ответа
function moveAnswerDragItem(e) {
    if (!isDragging || !dragItem) return;
    
    const x = e.clientX - parseInt(dragItem.dataset.offsetX);
    const y = e.clientY - parseInt(dragItem.dataset.offsetY);
    
    dragItem.style.left = x + 'px';
    dragItem.style.top = y + 'px';
    
    const elements = document.querySelectorAll('.answer-sortable-list .sortable-item:not(.dragging)');
    let targetElement = null;
    
    for (let el of elements) {
        const rect = el.getBoundingClientRect();
        if (e.clientY < rect.bottom && e.clientY > rect.top && el !== dragItem) {
            targetElement = el;
            break;
        }
    }
    
    if (targetElement && targetElement !== dragOverItem) {
        dragOverItem = targetElement;
        
        if (placeholder && placeholder.parentNode) {
            placeholder.parentNode.removeChild(placeholder);
        }
        
        const rect = targetElement.getBoundingClientRect();
        const mouseY = e.clientY;
        const targetMid = rect.top + rect.height / 2;
        
        if (mouseY < targetMid) {
            targetElement.parentNode.insertBefore(placeholder, targetElement);
        } else {
            targetElement.parentNode.insertBefore(placeholder, targetElement.nextSibling);
        }
        
        targetElement.classList.add('drag-target');
        
        elements.forEach(el => {
            if (el !== targetElement && el !== dragItem) {
                el.classList.remove('drag-target');
            }
        });
    }
}

// Завершение перетаскивания ответа
function stopAnswerDragging() {
    if (!isDragging || !dragItem) return;
    
    isDragging = false;
    
    document.querySelectorAll('.drag-target').forEach(el => {
        el.classList.remove('drag-target');
    });
    
    if (placeholder && placeholder.parentNode) {
        const parent = placeholder.parentNode;
        const nextSibling = placeholder.nextSibling;
        
        parent.removeChild(placeholder);
        
        if (nextSibling) {
            parent.insertBefore(dragItem, nextSibling);
        } else {
            parent.appendChild(dragItem);
        }
        
        dragItem.style.transition = 'all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1)';
        dragItem.style.position = '';
        dragItem.style.left = '';
        dragItem.style.top = '';
        dragItem.style.width = '';
        dragItem.style.zIndex = '';
        dragItem.style.boxShadow = '';
        dragItem.style.opacity = '';
    }
    
    placeholder = null;
    
    updateAnswersOrder();
    
    dragItem = null;
    dragOverItem = null;
    
    document.removeEventListener('mousemove', moveAnswerDragItem);
    document.removeEventListener('mouseup', stopAnswerDragging);
}

// Обновление порядка ответов в базе данных
function updateAnswersOrder() {
    const questionId = document.querySelector('.question-card')?.dataset.id || 
                       document.querySelector('.question-number-badge')?.textContent;
    
    if (!questionId) return;
    
    const sortableItems = document.querySelectorAll('.answer-sortable-list .sortable-item');
    const updates = [];
    
    sortableItems.forEach((item, index) => {
        const answerId = item.dataset.id;
        const newSortOrder = index;
        const oldSortOrder = parseInt(item.dataset.sortOrder);
        
        if (newSortOrder !== oldSortOrder) {
            updates.push({
                id: answerId,
                sort_order: newSortOrder
            });
            
            item.dataset.sortOrder = newSortOrder;
        }
    });
    
    if (updates.length === 0) return;
    
    const promises = updates.map(update => 
        fetch(ptbAdminSettings.apiUrl + '/answers/' + update.id, {
            method: 'PUT',
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify({ sort_order: update.sort_order })
        })
    );
    
    Promise.all(promises)
        .then(() => {
            console.log('Порядок ответов обновлён');
        })
        .catch(e => {
            console.error('Ошибка обновления порядка ответов:', e);
            alert('Ошибка обновления порядка ответов');
        });
}

// ==================== ОБРАБОТЧИКИ КАТЕГОРИЙ ОТВЕТОВ ====================

// Добавление категории к ответу
function handleAddCategory() {
    const answerItem = this.closest('.answer-item');
    const categoriesList = answerItem.querySelector('.answer-categories-list');
    
    const newCategory = document.createElement('div');
    newCategory.className = 'answer-category-item';
    newCategory.innerHTML = `
    <select class="form-select answer-category" name="category_id">
        <option value="">Выбрать категорию...</option>
        ${window.ptb.currentTest.categories.map(cat => `
        <option value="${cat.id}">${cat.code} - ${cat.name}</option>
        `).join('')}
    </select>
    <input type="number" class="form-input answer-weight" name="weight" value="1" min="1" max="10" placeholder="Вес">
    <button type="button" class="remove-category-btn">
        <span class="dashicons dashicons-no"></span>
    </button>
    `;
    
    categoriesList.appendChild(newCategory);
    
    newCategory.querySelector('.remove-category-btn').addEventListener('click', handleRemoveCategory);
}

// Удаление категории из ответа
function handleRemoveCategory() {
    const categoryItem = this.closest('.answer-category-item');
    const categoriesList = this.closest('.answer-categories-list');
    
    if (categoriesList.querySelectorAll('.answer-category-item').length > 1) {
        categoryItem.remove();
    } else {
        alert('Нужна хотя бы одна категория для ответа');
    }
}

// ==================== ОСНОВНЫЕ ОБРАБОТЧИКИ ====================

// Добавление варианта ответа (при создании вопроса)
// Добавление варианта ответа (при создании вопроса) - ИСПРАВЛЕНО: заполнение категорий
function handleAddAnswerOption() {
    const answerList = document.querySelector('.answer-list, .answer-sortable-list');
    const answerCount = answerList.querySelectorAll('.answer-item').length + 1;
    
    const newAnswer = document.createElement('div');
    newAnswer.className = 'answer-item answer-enter';
    newAnswer.innerHTML = `
    <div class="answer-inputs">
        <div class="answer-text">
            <input type="text" class="form-input regular-text" placeholder="Текст ответа" value="Вариант ${answerCount}">
        </div>
        <div class="answer-categories-list">
            <div class="answer-category-item">
                <select class="form-select answer-category" name="category_id">
                    <option value="">Выбрать категорию...</option>
                </select>
                <input type="number" class="form-input answer-weight" name="weight" value="1" min="1" max="10" placeholder="Вес">
                <button type="button" class="remove-category-btn">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>
        </div>
        <button type="button" class="add-category-btn">
            <span class="dashicons dashicons-plus"></span> Добавить категорию
        </button>
    </div>
    <button type="button" class="remove-answer-btn">
        <span class="dashicons dashicons-trash"></span>
    </button>
    `;
    
    answerList.appendChild(newAnswer);
    
    // Заполняем категории СРАЗУ при создании ответа
    const newSelect = newAnswer.querySelector('.answer-category');
    if (window.ptb && window.ptb.currentTest && window.ptb.currentTest.categories) {
        window.ptb.currentTest.categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id;
            option.textContent = `${cat.code} - ${cat.name}`;
            newSelect.appendChild(option);
        });
    }
    
    // Добавляем обработчики для новых кнопок
    newAnswer.querySelector('.add-category-btn')?.addEventListener('click', handleAddCategory);
    newAnswer.querySelectorAll('.remove-category-btn').forEach(btn => {
        btn.addEventListener('click', handleRemoveCategory);
    });
    
    setTimeout(() => newAnswer.classList.remove('answer-enter'), 300);
}

// Удаление варианта ответа (локального, при создании вопроса)
function handleDeleteAnswerOption() {
    const answerItem = this.closest('.answer-item');
    if (answerItem) {
        answerItem.classList.add('answer-exit');
        setTimeout(() => answerItem.remove(), 300);
    }
}

// Клонирование вопроса
function handleCloneQuestion() {
    const questionId = this.dataset.id;
    const question = window.ptb.currentTest.questions.find(q => q.id == questionId);
    if (!question) return;
    
    if (!confirm('Создать копию этого вопроса?')) return;
    
    fetch(ptbAdminSettings.apiUrl + '/questions', {
        method: 'POST',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            test_id: window.ptb.currentTest.id,
            question_text: question.question_text + ' (копия)',
            question_type: question.question_type,
            weight: question.weight,
            sort_order: (window.ptb.currentTest.questions?.length || 0)
        })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            const answerPromises = question.answers.map(answer => {
                let categoryWeights = [];
                try {
                    categoryWeights = JSON.parse(answer.category_weights || '[]');
                } catch (e) {
                    categoryWeights = answer.category_id ? [{category_id: answer.category_id, weight: answer.points}] : [];
                }
                
                return fetch(ptbAdminSettings.apiUrl + '/answers', {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        question_id: d.id,
                        answer_text: answer.answer_text,
                        category_weights: JSON.stringify(categoryWeights),
                        sort_order: answer.sort_order
                    })
                });
            });
            
            Promise.all(answerPromises)
                .then(() => window.ptb.selectTest(window.ptb.currentTest.id))
                .catch(e => {
                    console.error('Ошибка клонирования ответов:', e);
                    alert('Ошибка клонирования ответов');
                });
        } else {
            alert('Ошибка клонирования вопроса');
        }
    })
    .catch(e => {
        console.error('Ошибка:', e);
        alert('Ошибка: ' + e.message);
    });
}

// Создание нового вопроса - ИСПРАВЛЕНО: используем глобальный объект window.ptb
// Создание нового вопроса - ИСПРАВЛЕНО: поиск только в .answer-list и проверка элементов
function handleCreateQuestion() {
    const questionText = document.querySelector('.form-textarea').value.trim();
    if (!questionText) return alert('Введите текст вопроса');
    
    // КРИТИЧЕСКИ ВАЖНО: получаем testId из глобального объекта
    if (!window.ptb || !window.ptb.currentTest || !window.ptb.currentTest.id) {
        console.error('handleCreateQuestion: testId не определен в window.ptb.currentTest');
        console.error('window.ptb:', window.ptb);
        return alert('Ошибка: не удалось определить ID теста. Попробуйте обновить страницу.');
    }
    
    const testId = window.ptb.currentTest.id;
    
    // ИЩЕМ ТОЛЬКО В КОНТЕЙНЕРЕ ФОРМЫ СОЗДАНИЯ ВОПРОСА
    const answerList = document.querySelector('.answer-list');
    if (!answerList) {
        console.error('Контейнер .answer-list не найден!');
        return alert('Ошибка: не найден контейнер ответов. Попробуйте обновить страницу.');
    }
    
    // ФИЛЬТРУЕМ ТОЛЬКО ВИДИМЫЕ ОТВЕТЫ (без .answer-exit)
    const answers = Array.from(answerList.querySelectorAll('.answer-item:not(.answer-exit)')).map(item => {
        // Собираем категории с проверкой на существование элементов
        const categoryWeights = Array.from(item.querySelectorAll('.answer-category-item')).map(catItem => {
            const categorySelect = catItem.querySelector('.answer-category');
            const weightInput = catItem.querySelector('.answer-weight');
            
            // ПРОВЕРКА НА СУЩЕСТВОВАНИЕ ЭЛЕМЕНТОВ
            if (!categorySelect || !weightInput) {
                console.warn('Элементы категории не найдены в:', catItem);
                return null;
            }
            
            return {
                category_id: categorySelect.value,
                weight: parseInt(weightInput.value) || 1
            };
        }).filter(cw => cw && cw.category_id && cw.category_id !== ''); // ФИЛЬТРУЕМ НЕВАЛИДНЫЕ
        
        return {
            text: item.querySelector('.answer-text input')?.value.trim() || '',
            categoryWeights: categoryWeights
        };
    }).filter(a => a.text && a.categoryWeights.length > 0); // ФИЛЬТРУЕМ ПУСТЫЕ
    
    if (answers.length === 0) return alert('Добавьте хотя бы один вариант ответа');
    if (answers.some(a => a.categoryWeights.length === 0)) return alert('Выберите категорию для каждого ответа');
    
    // СОЗДАЕМ ВОПРОС СНАЧАЛА
    fetch(ptbAdminSettings.apiUrl + '/questions', {
        method: 'POST',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            test_id: testId,
            question_text: questionText,
            question_type: 'single',
            weight: 1,
            sort_order: window.ptb.currentTest.questions?.length || 0
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => { throw new Error(err.message || 'Ошибка сервера'); });
        }
        return response.json();
    })
    .then(data => {
        if (!data.success || !data.id) {
            throw new Error(data.message || 'Не удалось создать вопрос');
        }
        
        // Создаем ответы
        const questionId = data.id;
        const answerPromises = answers.map(answer => 
            fetch(ptbAdminSettings.apiUrl + '/answers', {
                method: 'POST',
                headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    question_id: questionId,
                    answer_text: answer.text,
                    category_weights: JSON.stringify(answer.categoryWeights),
                    sort_order: 0
                })
            })
        );
        
        return Promise.all(answerPromises).then(() => questionId);
    })
    .then(() => {
        // Перезагружаем тест
        window.ptb.selectTest(testId);
    })
    .catch(e => {
        console.error('Ошибка создания вопроса:', e);
        alert('Ошибка создания вопроса: ' + e.message);
    });
}

// Отмена создания вопроса
function handleCancelQuestion() {
    window.ptb.renderTabContent('questions');
}

// Редактирование вопроса и ответов (объединённая функция)
function handleEditQuestion() {
    const questionId = this.dataset.id;
    const question = window.ptb.currentTest.questions.find(q => q.id == questionId);
    if (!question) return;
    
    document.getElementById('tab-content').innerHTML = renderEditQuestionAndAnswersForm(question, window.ptb.currentTest.categories);
    
    initAnswerSort(document.querySelector('.answer-sortable-list'));
    
    document.querySelectorAll('.add-category-btn').forEach(btn => {
        btn.addEventListener('click', handleAddCategory);
    });
    
    document.querySelectorAll('.remove-category-btn').forEach(btn => {
        btn.addEventListener('click', handleRemoveCategory);
    });
    
    document.getElementById('add-answer-option-btn')?.addEventListener('click', handleAddAnswerOption);
    
    const answersContainer = document.querySelector('.answer-sortable-list');
    if (answersContainer) {
        answersContainer.addEventListener('click', function(e) {
            const btn = e.target.closest('.remove-answer-btn');
            if (!btn) return;
            
            e.stopPropagation();
            if (btn.dataset.answerId) {
                handleDeleteAnswer.call(btn);
            } else {
                handleDeleteAnswerOption.call(btn);
            }
        });
    }
    
    document.querySelector('.save-question-and-answers-btn')?.addEventListener('click', function() {
        const questionId = this.dataset.id;
        const questionText = document.getElementById('edit-question-text').value.trim();
        
        if (!questionText) return alert('Введите текст вопроса');
        
        fetch(ptbAdminSettings.apiUrl + '/questions/' + questionId, {
            method: 'PUT',
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify({ question_text: questionText })
        })
        .then(r => r.json())
        .then(d => {
            if (!d.success) {
                alert('Ошибка сохранения вопроса');
                return;
            }
            
            const answers = Array.from(document.querySelectorAll('.answer-item')).map(item => {
                const answerId = item.querySelector('.remove-answer-btn').dataset.answerId;
                
                const categoryWeights = Array.from(item.querySelectorAll('.answer-category-item')).map(catItem => ({
                    category_id: catItem.querySelector('.answer-category').value,
                    weight: parseInt(catItem.querySelector('.answer-weight').value) || 1
                })).filter(cw => cw.category_id && cw.category_id !== '');
                
                return {
                    id: answerId,
                    text: item.querySelector('.answer-text input').value.trim(),
                    categoryWeights: categoryWeights
                };
            }).filter(a => a.text && a.categoryWeights.length > 0);
            
            if (answers.length === 0) return alert('Добавьте хотя бы один вариант ответа');
            if (answers.some(a => a.categoryWeights.length === 0)) return alert('Выберите категорию для каждого ответа');
            
            const updatePromises = answers.map(answer => {
                if (answer.id) {
                    return fetch(ptbAdminSettings.apiUrl + '/answers/' + answer.id, {
                        method: 'PUT',
                        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            answer_text: answer.text,
                            category_weights: JSON.stringify(answer.categoryWeights)
                        })
                    });
                } else {
                    return fetch(ptbAdminSettings.apiUrl + '/answers', {
                        method: 'POST',
                        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            question_id: questionId,
                            answer_text: answer.text,
                            category_weights: JSON.stringify(answer.categoryWeights),
                            sort_order: 0
                        })
                    });
                }
            });
            
            Promise.all(updatePromises)
                .then(() => window.ptb.selectTest(window.ptb.currentTest.id))
                .catch(e => {
                    console.error('Ошибка:', e);
                    alert('Ошибка сохранения ответов: ' + e.message);
                });
        })
        .catch(e => {
            console.error('Ошибка:', e);
            alert('Ошибка: ' + e.message);
        });
    });
    
    document.querySelector('.cancel-edit-btn')?.addEventListener('click', () => {
        window.ptb.renderTabContent('questions');
    });
}

// Удаление вопроса
function handleDeleteQuestion() {
    if (!confirm('Удалить вопрос и все его ответы?')) return;
    
    fetch(ptbAdminSettings.apiUrl + '/questions/' + this.dataset.id, {
        method: 'DELETE',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce }
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            window.ptb.selectTest(window.ptb.currentTest.id);
        } else {
            alert('Ошибка удаления: ' + (d.message || 'Неизвестная ошибка'));
        }
    })
    .catch(e => {
        console.error('Ошибка:', e);
        alert('Ошибка: ' + e.message);
    });
}

// Удаление ответа (серверное)
function handleDeleteAnswer() {
    if (!confirm('Удалить ответ?')) return;
    
    fetch(ptbAdminSettings.apiUrl + '/answers/' + this.dataset.answerId, {
        method: 'DELETE',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce }
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            window.ptb.selectTest(window.ptb.currentTest.id);
        } else {
            alert('Ошибка удаления: ' + (d.message || 'Неизвестная ошибка'));
        }
    })
    .catch(e => {
        console.error('Ошибка:', e);
        alert('Ошибка: ' + e.message);
    });
}

// Инициализация обработчиков для формы создания вопроса - ИСПРАВЛЕНО: убраны параметры
function initQuestionFormHandlers(testId, categories) {
    // Заполняем категории
    document.querySelectorAll('.answer-category').forEach(select => {
        select.innerHTML = '<option value="">Выбрать категорию...</option>';
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.id;
            option.textContent = `${cat.code} - ${cat.name}`;
            select.appendChild(option);
        });
    });
    
    document.getElementById('add-answer-option-btn')?.addEventListener('click', handleAddAnswerOption);
    
    const answerList = document.querySelector('.answer-list');
    if (answerList) {
        answerList.addEventListener('click', function(e) {
            const btn = e.target.closest('.remove-answer-btn');
            if (!btn || btn.hasAttribute('data-answer-id')) return;
            
            e.stopPropagation();
            handleDeleteAnswerOption.call(btn);
        });
    }
    
    document.querySelectorAll('.add-category-btn').forEach(btn => {
        btn.addEventListener('click', handleAddCategory);
    });
    
    document.querySelectorAll('.remove-category-btn').forEach(btn => {
        btn.addEventListener('click', handleRemoveCategory);
    });
    
    // ИСПРАВЛЕНО: вызываем без параметров, они будут взяты из глобального объекта
    document.getElementById('create-question-btn')?.addEventListener('click', handleCreateQuestion);
}

// Регистрация обработчиков для существующих вопросов
function registerQuestionsHandlers(testId) {
    document.querySelectorAll('.edit-question-btn').forEach(btn => {
        btn.addEventListener('click', handleEditQuestion);
    });
    
    document.querySelectorAll('.delete-question-btn').forEach(btn => {
        btn.addEventListener('click', handleDeleteQuestion);
    });
    
    document.querySelectorAll('.clone-question-btn').forEach(btn => {
        btn.addEventListener('click', handleCloneQuestion);
    });
    
    document.querySelectorAll('.toggle-question-btn').forEach(btn => {
        btn.addEventListener('click', handleToggleQuestion);
    });
    
    document.querySelectorAll('.remove-answer-btn[data-answer-id]').forEach(btn => {
        btn.addEventListener('click', handleDeleteAnswer);
    });
    
    initQuestionSort();
}