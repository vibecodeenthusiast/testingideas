/**
 * Основная функция рендеринга вкладки вопросов
 */
function renderQuestionsTab(container, currentTest) {
    // Формируем разметку
    const html = `${renderAddQuestionForm()} ${renderQuestionsList(currentTest.questions, currentTest.categories)}`;
    container.innerHTML = html;
    
    // Инициализация обработчиков для формы создания вопроса
    initQuestionFormHandlers(currentTest.id, currentTest.categories);
    
    // Регистрация обработчиков для существующих вопросов
    registerQuestionsHandlers(currentTest.id);
}