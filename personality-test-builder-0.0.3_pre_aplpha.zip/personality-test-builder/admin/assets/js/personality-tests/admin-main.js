// ГЛОБАЛЬНЫЙ ОБЪЕКТ ДЛЯ ДОСТУПА ИЗ ДРУГИХ ФАЙЛОВ
window.ptb = {
    currentTest: null,
    tests: [],
    activeTab: 'overview', // ← ИЗМЕНЕНО: обзор первой
    
    /**
     * Выбор теста для редактирования
     */
    selectTest: function(testId) {
        fetch(ptbAdminSettings.apiUrl + '/tests/' + testId, {
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce }
        })
        .then(response => response.json())
        .then(test => {
            window.ptb.currentTest = test;
            
            // Устанавливаем активное правило из настроек теста
            try {
                const settings = test.settings ? JSON.parse(test.settings) : {};
                window.ptb.activeResultRule = settings.resultRule || null;
            } catch (e) {
                window.ptb.activeResultRule = null;
            }
            
            window.ptb.renderTestEditor();
            window.ptb.renderTestsList();
        })
        .catch(error => {
            alert('Ошибка загрузки теста: ' + error.message);
        });
    },

    /**
     * Рендеринг редактора теста
     */
    renderTestEditor: function() {
        const contentEl = document.getElementById('main-content');
        contentEl.innerHTML = `
            <h2>${escapeHtml(window.ptb.currentTest.name)}</h2>
            
            <div class="ptb-editor-tabs">
                <button class="active" data-tab="overview">Обзор</button>
                <button data-tab="categories">Категории</button>
                <button data-tab="questions">Вопросы</button>
                <button data-tab="results-single">Результаты (1 категория)</button>
                <button data-tab="results-dual">Результаты (2 категории)</button>
                <button data-tab="settings">Настройки</button>
            </div>
            
            <div id="tab-content" class="ptb-tab-content"></div>
        `;
        
        // Устанавливаем активную вкладку как "Обзор" по умолчанию
        window.ptb.activeTab = 'overview';
        
        document.querySelectorAll('.ptb-editor-tabs button').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.ptb-editor-tabs button').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                window.ptb.activeTab = btn.dataset.tab;
                window.ptb.renderTabContent(window.ptb.activeTab);
            });
        });
        
        window.ptb.renderTabContent(window.ptb.activeTab);
    },

    /**
     * Рендеринг контента вкладки
     */
    renderTabContent: function(tab) {
        const contentEl = document.getElementById('tab-content');
        
        if (tab === 'overview') {
            if (typeof window.ptb.renderOverviewTab === 'function') {
                window.ptb.renderOverviewTab(contentEl, window.ptb.currentTest);
            } else {
                contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля обзора...</div>';
            }
        } else if (tab === 'questions') {
            if (typeof renderQuestionsTab === 'function') renderQuestionsTab(contentEl, window.ptb.currentTest);
            else contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля вопросов...</div>';
        } else if (tab === 'categories') {
            if (typeof renderCategoriesTab === 'function') renderCategoriesTab(contentEl, window.ptb.currentTest);
            else contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля категорий...</div>';
        } else if (tab === 'results-single') {
            if (typeof renderResultsSingleTab === 'function') renderResultsSingleTab(contentEl, window.ptb.currentTest);
            else contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля результатов...</div>';
        } else if (tab === 'results-dual') {
            if (typeof renderResultsDualTab === 'function') renderResultsDualTab(contentEl, window.ptb.currentTest);
            else contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля результатов...</div>';
        } else if (tab === 'settings') {
            if (typeof renderSettingsTab === 'function') renderSettingsTab(contentEl, window.ptb.currentTest);
            else contentEl.innerHTML = '<div class="ptb-loading">Загрузка модуля настроек...</div>';
        }
    },

    /**
     * Рендеринг списка тестов в сайдбаре — ОБНОВЛЁННЫЙ СО СТАТИСТИКОЙ
     */
    renderTestsList: function() {
        const listEl = document.getElementById('tests-list');
        
        if (window.ptb.tests.length === 0) {
            listEl.innerHTML = `
                <div class="ptb-empty-state">
                    <p>Нет созданных тестов</p>
                    <p><button id="add-test-btn-2" class="button button-primary">Создать первый тест</button></p>
                </div>
            `;
            document.getElementById('add-test-btn-2').addEventListener('click', window.ptb.showCreateTestForm);
            return;
        }
        
        let html = '';
        window.ptb.tests.forEach(test => {
            // Вычисляем статистику теста
            const categoriesCount = test.categories_count || 0;
            const questionsCount = test.questions_count || 0;
            const targetCategories = test.target_categories || 6;
            const targetQuestions = test.target_questions || 45;
            
            // Вычисляем прогресс по категориям и вопросам
            const categoriesProgress = targetCategories > 0 ? Math.min(100, Math.round((categoriesCount / targetCategories) * 100)) : 0;
            const questionsProgress = targetQuestions > 0 ? Math.min(100, Math.round((questionsCount / targetQuestions) * 100)) : 0;
            
            // Общий прогресс = среднее арифметическое
            const overallProgress = Math.round((categoriesProgress + questionsProgress) / 2);
            
            html += `
                <div class="ptb-test-item ${window.ptb.currentTest && window.ptb.currentTest.id == test.id ? 'active' : ''}" data-id="${test.id}">
                    <div class="ptb-test-item-header">
                        <h3>${escapeHtml(test.name)}</h3>
                        <div class="ptb-test-item-actions">
                            <span class="ptb-test-item-duplicate dashicons dashicons-clipboard" title="Дублировать тест" data-id="${test.id}"></span>
                            <span class="ptb-test-item-delete dashicons dashicons-trash" title="Удалить тест" data-id="${test.id}"></span>
                        </div>
                    </div>
                    ${test.description ? `<p class="ptb-test-description">${escapeHtml(test.description)}</p>` : ''}
                    
                    <div class="ptb-test-stats">
                        <div class="ptb-test-stat">
                            <span class="stat-label">Категории:</span>
                            <span class="stat-value">${categoriesCount} из ${targetCategories}</span>
                        </div>
                        <div class="ptb-test-stat">
                            <span class="stat-label">Вопросы:</span>
                            <span class="stat-value">${questionsCount} из ${targetQuestions}</span>
                        </div>
                    </div>
                    
                    <div class="ptb-test-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${overallProgress}%;"></div>
                        </div>
                        <div class="progress-label">${overallProgress}% готово</div>
                    </div>
                </div>
            `;
        });
        
        listEl.innerHTML = html;
        
        // Обработчики для дублирования и удаления
        document.querySelectorAll('.ptb-test-item-duplicate').forEach(icon => {
            icon.addEventListener('click', (e) => {
                e.stopPropagation();
                const testId = parseInt(icon.dataset.id);
                window.ptb.duplicateTest(testId);
            });
        });
        
        document.querySelectorAll('.ptb-test-item-delete').forEach(icon => {
            icon.addEventListener('click', (e) => {
                e.stopPropagation();
                const testId = parseInt(icon.dataset.id);
                window.ptb.deleteTest(testId);
            });
        });
        
        // Обработчик выбора теста
        document.querySelectorAll('.ptb-test-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.closest('.ptb-test-item-actions')) {
                    window.ptb.selectTest(parseInt(item.dataset.id));
                }
            });
        });
    },

    /**
     * Дублирование теста
     */
    duplicateTest: function(testId) {
        if (!confirm('Создать копию теста?')) return;
        
        // Получаем данные теста
        fetch(ptbAdminSettings.apiUrl + '/tests/' + testId, {
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce }
        })
        .then(response => response.json())
        .then(originalTest => {
            // Создаём копию с пометкой "Копия"
            const duplicateData = {
                name: originalTest.name + ' (копия)',
                description: originalTest.description || '',
                type: 'personality',
                status: 'draft',
                settings: originalTest.settings ? JSON.parse(originalTest.settings) : {}
            };
            
            // Создаём новый тест
            fetch(ptbAdminSettings.apiUrl + '/tests', {
                method: 'POST',
                headers: { 
                    'X-WP-Nonce': ptbAdminSettings.nonce, 
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify(duplicateData)
            })
            .then(response => response.json())
            .then(newTest => {
                if (newTest.success) {
                    // TODO: Скопировать категории, вопросы и результаты
                    // Пока просто перезагружаем список тестов
                    window.ptb.loadTests();
                    alert('Тест успешно продублирован!');
                } else {
                    alert('Ошибка дублирования теста: ' + (newTest.message || 'Неизвестная ошибка'));
                }
            })
            .catch(error => {
                console.error('Ошибка дублирования:', error);
                alert('Ошибка дублирования теста: ' + error.message);
            });
        })
        .catch(error => {
            console.error('Ошибка получения теста:', error);
            alert('Не удалось загрузить данные теста для дублирования');
        });
    },

    /**
     * Показ формы создания теста
     */
    showCreateTestForm: function() {
        const contentEl = document.getElementById('main-content');
        contentEl.innerHTML = `
            <h2>Создать новый тест</h2>
            
            <div class="ptb-form-group">
                <label for="test-name">Название теста <span class="required">*</span></label>
                <input type="text" id="test-name" class="regular-text" placeholder="Введите название теста">
                <p class="description">Краткое и понятное название теста</p>
            </div>
            
            <div class="ptb-form-group">
                <label for="test-description">Описание (необязательно)</label>
                <textarea id="test-description" class="regular-text" rows="3" placeholder="Описание теста..."></textarea>
                <p class="description">Краткое описание того, что измеряет тест и для кого он предназначен</p>
            </div>
            
            <div class="ptb-form-group">
                <label>Статус теста <span class="required">*</span></label>
                <div class="radio-group">
                    <label>
                        <input type="radio" name="test-status" value="draft" checked>
                        <span class="status-badge status-draft">Черновик</span>
                        <p class="description">Тест не виден на сайте, доступен только в админке</p>
                    </label>
                    <label>
                        <input type="radio" name="test-status" value="published">
                        <span class="status-badge status-published">Опубликован</span>
                        <p class="description">Тест доступен для прохождения на сайте</p>
                    </label>
                </div>
            </div>
            
            <div class="ptb-form-actions">
                <button id="cancel-test-btn" class="button button-secondary">Отмена</button>
                <button id="save-test-btn" class="button button-primary ptb-primary">
                    <span class="dashicons dashicons-plus"></span>
                    Создать тест
                </button>
            </div>
        `;
        
        document.getElementById('save-test-btn').addEventListener('click', window.ptb.createTest);
        document.getElementById('cancel-test-btn').addEventListener('click', () => {
            if (window.ptb.currentTest) {
                window.ptb.selectTest(window.ptb.currentTest.id);
            } else {
                document.getElementById('main-content').innerHTML = `
                    <div class="ptb-empty-state">
                        <p>Выберите тест или создайте новый</p>
                    </div>
                `;
            }
        });
    },

    /**
     * Создание нового теста
     */
    createTest: function() {
        const name = document.getElementById('test-name').value.trim();
        const description = document.getElementById('test-description').value.trim();
        const status = document.querySelector('input[name="test-status"]:checked').value;
        
        if (!name) {
            alert('Введите название теста');
            return;
        }
        
        // Формируем базовые настройки теста
        const settings = {
            resultRule: 'single',
            showProgress: true,
            shuffleQuestions: false,
            allowRetake: true,
            target_categories: 6,
            target_questions: 45
        };
        
        fetch(ptbAdminSettings.apiUrl + '/tests', {
            method: 'POST',
            headers: { 
                'X-WP-Nonce': ptbAdminSettings.nonce, 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify({
                name: name,
                description: description,
                type: 'personality',
                status: status,
                settings: settings
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.ptb.loadTests();
                window.ptb.selectTest(data.id);
            } else {
                alert('Ошибка создания теста: ' + (data.message || 'Неизвестная ошибка'));
            }
        })
        .catch(error => {
            console.error('Ошибка создания теста:', error);
            alert('Ошибка: ' + error.message);
        });
    },

    /**
     * Загрузка списка тестов — ОБНОВЛЁННЫЙ: ЗАПРАШИВАЕМ СТАТИСТИКУ
     */
    loadTests: function() {
        fetch(ptbAdminSettings.apiUrl + '/tests?include_stats=1', { 
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce } 
        })
        .then(response => response.json())
        .then(data => {
            window.ptb.tests = data;
            window.ptb.renderTestsList();
        })
        .catch(error => {
            console.error('Ошибка загрузки тестов:', error);
            document.getElementById('tests-list').innerHTML = `
                <div class="ptb-error">
                    <p>Ошибка загрузки тестов</p>
                </div>
            `;
        });
    },

    /**
     * Удаление теста
     */
    deleteTest: function(testId) {
        if (!confirm('Удалить тест? Все данные будут потеряны.')) return;
        
        fetch(ptbAdminSettings.apiUrl + '/tests/' + testId, {  
            method: 'DELETE', 
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce } 
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                window.ptb.currentTest = null;
                window.ptb.loadTests();
                document.getElementById('main-content').innerHTML = `
                    <div class="ptb-empty-state">
                        <p>Тест удалён. Выберите другой тест или создайте новый.</p>
                    </div>
                `;
            } else {
                alert('Ошибка удаления теста');
            }
        })
        .catch(e => alert('Ошибка: ' + e.message));
    },

    /**
     * Вспомогательная функция для экранирования HTML
     */
    escapeHtml: function(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
};

/**
 * ОСНОВНАЯ ФУНКЦИЯ РЕНДЕРИНГА (ВНЕ ОБЪЕКТА)
 */
function renderUI() {
    const container = document.getElementById('ptb-admin-app');
    if (!container) return;
    
    container.innerHTML = `
        <div class="ptb-admin-container">
            <div class="ptb-sidebar">
                <div class="ptb-sidebar-header">
                    <h2>Тесты</h2>
                    <button id="add-test-btn" class="button button-primary">
                        <span class="dashicons dashicons-plus"></span>
                        Новый тест
                    </button>
                </div>
                <div id="tests-list" class="ptb-tests-list ptb-loading">
                    <div class="ptb-spinner"></div>
                    <p>Загрузка тестов...</p>
                </div>
            </div>
            
            <div class="ptb-main-content" id="main-content">
                <div class="ptb-empty-state">
                    <p>Выберите тест или создайте новый</p>
                </div>
            </div>
        </div>
    `;

    document.getElementById('add-test-btn').addEventListener('click', window.ptb.showCreateTestForm);
}

/**
 * Инициализация
 */
document.addEventListener('DOMContentLoaded', function() {
    renderUI();
    window.ptb.loadTests();
});

/**
 * Вспомогательная функция для экранирования HTML
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}