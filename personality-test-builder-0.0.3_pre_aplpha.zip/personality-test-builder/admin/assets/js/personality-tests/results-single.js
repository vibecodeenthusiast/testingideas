/**
 * Модуль управления результатами по одной категории
 */

function renderResultsSingleTab(container, currentTest) {
    console.log('renderResultsSingleTab вызвана');
    
    // Парсим настройки теста (могут приходить как строка или объект)
    let testSettings = currentTest.settings;
    if (typeof testSettings === 'string') {
        try {
            testSettings = JSON.parse(testSettings);
        } catch (e) {
            console.error('Ошибка парсинга настроек:', e);
            testSettings = {};
        }
    }
    
    if (!currentTest.categories || currentTest.categories.length === 0) {
        container.innerHTML = `
            <div class="ptb-empty-state">
                <div class="empty-state-icon">⚠️</div>
                <h3>Нет категорий</h3>
                <p>Сначала добавьте категории на вкладке "Категории"</p>
                <button id="go-to-categories-btn" class="button button-primary">
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                    Перейти к категориям
                </button>
            </div>
        `;
        document.getElementById('go-to-categories-btn').addEventListener('click', () => {
            document.querySelectorAll('.ptb-editor-tabs button[data-tab="categories"]').forEach(b => {
                document.querySelectorAll('.ptb-editor-tabs button').forEach(x => x.classList.remove('active'));
                b.classList.add('active');
                window.ptb.renderTabContent('categories');
            });
        });
        return;
    }
    
    // Фильтруем профили для одной категории
    const filteredResults = currentTest.results?.filter(r => r.rule_type === 'single') || [];
    const allCategories = currentTest.categories.map(c => c.code);
    const existingCategories = filteredResults.map(r => r.category_combination);
    const missingCategories = allCategories.filter(c => !existingCategories.includes(c));
    
    // Проверяем, есть ли предопределённые типы рекомендаций в настройках теста
    const hasRecommendationTypes = testSettings?.recommendation_types?.length > 0;
    const recommendationTypes = testSettings?.recommendation_types || [];
    
    // Формируем разметку для рекомендаций
    let recommendationsHtml = `
        <div class="recommendations-section">
            <h5 class="section-subtitle">
                Рекомендации
                ${!hasRecommendationTypes ? `
                    <button type="button" id="add-recommendation-btn" class="button button-secondary add-rec-btn" style="margin-left: 10px; padding: 4px 12px; height: auto;">
                        <span class="dashicons dashicons-plus"></span>
                        Добавить рекомендацию
                    </button>
                ` : ''}
            </h5>
    `;
    
    if (hasRecommendationTypes) {
        // Режим: предопределённые типы из настроек теста
        recommendationsHtml += `
            <p class="recommendations-info">Типы рекомендаций заданы в настройках теста. Просто заполните содержимое для каждого типа.</p>
            <div id="recommendations-container" class="recommendations-container">
                ${recommendationTypes.map((type, index) => `
                    <div class="recommendation-field predefined" data-index="${index}">
                        <div class="recommendation-header predefined">
                            <span class="rec-type-title">${escapeHtml(type)}</span>
                        </div>
                        <textarea class="rec-content-textarea" rows="3" placeholder="Каждая рекомендация с новой строки"></textarea>
                        <p class="form-hint">Каждая рекомендация с новой строки</p>
                    </div>
                `).join('')}
            </div>
        `;
    } else {
        // Режим: гибкие рекомендации (пользователь сам задаёт типы)
        recommendationsHtml += `
            <div id="recommendations-container" class="recommendations-container">
                <!-- Рекомендации будут добавляться сюда динамически -->
            </div>
            <p class="recommendations-limit-hint">Максимум 20 рекомендаций</p>
        `;
    }
    
    recommendationsHtml += `</div>`;
    
    // Формируем разметку
    container.innerHTML = `
        <div class="ptb-results-container">
            <div class="results-header">
                <h3>Результаты по одной категории</h3>
                <p class="results-description">Результат определяется по категории с наибольшим количеством баллов</p>
            </div>
            
            ${missingCategories.length > 0 ? `
                <div class="missing-categories-alert">
                    <div class="alert-icon">ℹ️</div>
                    <div class="alert-content">
                        <strong>Недостающие категории (${missingCategories.length}):</strong>
                        <div class="missing-categories-list">${missingCategories.join(', ')}</div>
                        <p class="alert-hint">Создайте профили для этих категорий, чтобы покрыть все возможные результаты теста.</p>
                    </div>
                </div>
            ` : ''}
            
            <div class="results-section">
                <h4 class="section-title">Добавить новый профиль</h4>
                <div class="category-selection">
                    <label class="selection-label">Выберите категорию для профиля</label>
                    <div class="categories-grid">
                        ${currentTest.categories.map(cat => `
                            <label class="category-select-card">
                                <input type="radio" name="single-category" class="result-category-radio" value="${cat.code}" data-id="${cat.id}">
                                <div class="category-select-content">
                                    <div class="category-select-badge" style="background-color: ${cat.color};"></div>
                                    <div class="category-select-info">
                                        <div class="category-select-name">${cat.name}</div>
                                        <div class="category-select-code">${cat.code}</div>
                                    </div>
                                </div>
                            </label>
                        `).join('')}
                    </div>
                </div>
                
                <div id="profile-form" class="profile-form" style="display: none;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="new-result-name">Название профиля *</label>
                            <input type="text" id="new-result-name" class="form-input" placeholder="Аналитический тип">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="new-result-description">Описание профиля</label>
                            <textarea id="new-result-description" class="form-textarea" rows="3" placeholder="Подробное описание результата..."></textarea>
                        </div>
                    </div>
                    
                    ${recommendationsHtml}
                    
                    <div class="form-actions">
                        <button id="add-result-btn" class="button button-primary">
                            <span class="dashicons dashicons-plus"></span>
                            Сохранить профиль
                        </button>
                    </div>
                </div>
            </div>
            
            ${filteredResults.length > 0 ? `
                <div class="results-section">
                    <h4 class="section-title">Существующие профили (${filteredResults.length})</h4>
                    <div class="profiles-grid">
                        ${filteredResults.map(res => {
                            const cat = currentTest.categories.find(c => c.code === res.category_combination);
                            return renderProfileCard(res, cat);
                        }).join('')}
                    </div>
                </div>
            ` : `
                <div class="ptb-empty-state">
                    <div class="empty-state-icon">📋</div>
                    <h3>Нет профилей</h3>
                    <p>Добавьте первый профиль выше, чтобы начать</p>
                </div>
            `}
        </div>
    `;
    
    // Обработчики радиокнопок
    const radios = document.querySelectorAll('.result-category-radio');
    const profileForm = document.getElementById('profile-form');
    
    radios.forEach(radio => {
        radio.addEventListener('change', () => {
            profileForm.style.display = 'block';
            profileForm.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    });
    
    // Инициализация контейнера рекомендаций (если типы ещё не заданы)
    if (!hasRecommendationTypes) {
        initRecommendationsContainer();
    }
    
    // Добавление результата
    document.getElementById('add-result-btn')?.addEventListener('click', () => {
        const selectedRadio = document.querySelector('.result-category-radio:checked');
        if (!selectedRadio) return alert('Выберите категорию');
        
        const category = selectedRadio.value;
        const name = document.getElementById('new-result-name').value.trim();
        if (!name) return alert('Введите название профиля');
        
        // Собираем все рекомендации
        const recommendations = collectRecommendations(currentTest);
        
        // Если это первый профиль и типы ещё не заданы — сохраняем типы в настройках
        let settingsUpdate = null;
        if (!hasRecommendationTypes && recommendations.length > 0) {
            const newTypes = recommendations.map(rec => rec.title);
            settingsUpdate = {
                ...testSettings,
                recommendation_types: newTypes
            };
        }
        
        const data = {
            test_id: currentTest.id,
            rule_type: 'single',
            category_combination: category,
            result_name: name,
            result_description: document.getElementById('new-result-description').value.trim(),
            custom_recommendations: recommendations
        };
        
        // Сначала обновляем настройки (если нужно), потом создаём профиль
        const savePromise = settingsUpdate 
            ? fetch(ptbAdminSettings.apiUrl + '/tests/' + currentTest.id, {
                method: 'PUT',
                headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    settings: JSON.stringify(settingsUpdate) // ← ВАЖНО: двойной stringify
                })
            })
            : Promise.resolve();
        
        savePromise.then(() => {
            return fetch(ptbAdminSettings.apiUrl + '/results', {
                method: 'POST',
                headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                radios.forEach(r => r.checked = false);
                ['new-result-name', 'new-result-description'].forEach(id => document.getElementById(id).value = '');
                document.getElementById('recommendations-container').innerHTML = '';
                profileForm.style.display = 'none';
                window.ptb.selectTest(currentTest.id);
                
                if (settingsUpdate) {
                    alert('Профиль создан! Типы рекомендаций сохранены в настройках теста.');
                }
            } else {
                alert('Ошибка добавления профиля');
            }
        })
        .catch(e => alert('Ошибка: ' + e.message));
    });
    
    // Удаление и редактирование
    document.querySelectorAll('.delete-result-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (confirm('Удалить профиль?')) {
                fetch(ptbAdminSettings.apiUrl + '/results/' + btn.dataset.id, { method: 'DELETE', headers: { 'X-WP-Nonce': ptbAdminSettings.nonce } })
                .then(r => r.json())
                .then(d => d.success ? window.ptb.selectTest(currentTest.id) : alert('Ошибка удаления'))
                .catch(e => alert('Ошибка: ' + e.message));
            }
        });
    });
    
    document.querySelectorAll('.edit-result-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const res = currentTest.results.find(r => r.id == btn.dataset.id);
            if (!res) return;
            
            showEditModal(res, currentTest);
        });
    });
}

/**
 * Инициализация контейнера рекомендаций
 */
function initRecommendationsContainer() {
    const container = document.getElementById('recommendations-container');
    const addButton = document.getElementById('add-recommendation-btn');
    
    if (!container || !addButton) return;
    
    // Добавление новой рекомендации
    addButton.addEventListener('click', () => {
        const currentCount = container.children.length;
        
        if (currentCount >= 20) {
            alert('Достигнут лимит в 20 рекомендаций. Удалите одну из существующих, чтобы добавить новую.');
            return;
        }
        
        addRecommendationField(container, { id: Date.now(), title: '', content: '' });
    });
}

/**
 * Добавление поля рекомендации
 */
function addRecommendationField(container, recommendation) {
    const recId = recommendation.id || Date.now();
    const html = `
        <div class="recommendation-field" data-id="${recId}">
            <div class="recommendation-header">
                <input type="text" class="rec-title-input" placeholder="Название рекомендации" value="${recommendation.title || ''}">
                <button type="button" class="button button-link delete-rec-btn" style="color: #dc2626; padding: 0; height: auto;">
                    <span class="dashicons dashicons-trash"></span>
                </button>
            </div>
            <textarea class="rec-content-textarea" rows="3" placeholder="Каждая рекомендация с новой строки">${recommendation.content || ''}</textarea>
            <p class="form-hint">Каждая рекомендация с новой строки</p>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', html);
    
    // Обработчик удаления
    const field = container.lastElementChild;
    field.querySelector('.delete-rec-btn').addEventListener('click', () => {
        field.remove();
    });
}

/**
 * Сбор всех рекомендаций
 */
function collectRecommendations(currentTest) {
    const container = document.getElementById('recommendations-container');
    const recommendations = [];
    
    // Парсим настройки теста
    let testSettings = currentTest.settings;
    if (typeof testSettings === 'string') {
        try {
            testSettings = JSON.parse(testSettings);
        } catch (e) {
            console.error('Ошибка парсинга настроек:', e);
            testSettings = {};
        }
    }
    
    // Проверяем, есть ли предопределённые типы
    const hasRecommendationTypes = testSettings?.recommendation_types?.length > 0;
    const recommendationTypes = testSettings?.recommendation_types || [];
    
    if (hasRecommendationTypes) {
        // Собираем данные для предопределённых типов
        container.querySelectorAll('.recommendation-field').forEach((field, index) => {
            const content = field.querySelector('.rec-content-textarea').value.trim();
            const typeTitle = recommendationTypes[index] || `Тип ${index + 1}`;
            
            if (content) {
                recommendations.push({
                    id: index,
                    title: typeTitle,
                    content: content.split('\n').filter(x => x.trim())
                });
            }
        });
    } else {
        // Собираем данные для гибких рекомендаций
        container.querySelectorAll('.recommendation-field').forEach(field => {
            const title = field.querySelector('.rec-title-input').value.trim();
            const content = field.querySelector('.rec-content-textarea').value.trim();
            
            if (title || content) {
                recommendations.push({
                    id: field.dataset.id || Date.now(),
                    title: title,
                    content: content.split('\n').filter(x => x.trim())
                });
            }
        });
    }
    
    return recommendations;
}

/**
 * Рендеринг карточки профиля
 */
/**
 * Рендеринг карточки профиля
 */
function renderProfileCard(result, category) {
    // Парсим настройки теста
    let testSettings = window.ptb.currentTest.settings;
    if (typeof testSettings === 'string') {
        try {
            testSettings = JSON.parse(testSettings);
        } catch (e) {
            console.error('Ошибка парсинга настроек:', e);
            testSettings = {};
        }
    }
    
    // Получаем все рекомендации из профиля
    const profileRecommendations = result.custom_recommendations || [];
    
    // Получаем типы рекомендаций из настроек теста
    const recommendationTypes = testSettings?.recommendation_types || [];
    
    // Цвет для тени при наведении
    const categoryColor = category ? category.color : '#6b7280';
    
    return `
        <div class="profile-card" data-id="${result.id}" style="--category-color: ${categoryColor};">
            <div class="profile-header">
                <div class="profile-category-info">
                    ${category ? `
                        <div class="profile-category-badge" style="background-color: ${categoryColor};"></div>
                        <div class="profile-category-details">
                            <div class="profile-category-name">${category.name}</div>
                            <div class="profile-category-code">${category.code}</div>
                        </div>
                    ` : `
                        <div class="profile-category-badge" style="background-color: #6b7280;"></div>
                        <div class="profile-category-details">
                            <div class="profile-category-name">Неизвестная категория</div>
                        </div>
                    `}
                </div>
                <div class="profile-meta">
                    <span class="meta-item">
                        <span class="dashicons dashicons-admin-generic"></span>
                        ID: ${result.id}
                    </span>
                </div>
            </div>
            
            ${recommendationTypes.length > 0 ? `
                <div class="recommendations-summary">
                    ${recommendationTypes.map(type => {
                        const isFilled = profileRecommendations.some(rec => rec.title === type && rec.content?.length > 0);
                        return `
                            <span class="rec-badge ${isFilled ? 'filled' : 'empty'}">
                                <span class="dashicons ${isFilled ? 'dashicons-yes' : 'dashicons-no'}"></span>
                                ${escapeHtml(type)}
                            </span>
                        `;
                    }).join('')}
                </div>
            ` : `
                <div class="recommendations-empty">
                    <span class="dashicons dashicons-info"></span>
                    Нет рекомендаций
                </div>
            `}
            
            <div class="profile-footer">
                <div class="profile-actions">
                    <button class="button button-secondary edit-result-btn" data-id="${result.id}">
                        <span class="dashicons dashicons-edit"></span>
                        Редактировать
                    </button>
                    <button class="button button-danger delete-result-btn" data-id="${result.id}">
                        <span class="dashicons dashicons-trash"></span>
                        Удалить
                    </button>
                </div>
            </div>
        </div>
    `;
}

/**
 * Показ модального окна редактирования
 */
function showEditModal(result, currentTest) {
    const category = currentTest.categories.find(c => c.code === result.category_combination);
    
    // Парсим настройки теста
    let testSettings = currentTest.settings;
    if (typeof testSettings === 'string') {
        try {
            testSettings = JSON.parse(testSettings);
        } catch (e) {
            console.error('Ошибка парсинга настроек:', e);
            testSettings = {};
        }
    }
    
    // Проверяем, есть ли предопределённые типы в настройках теста
    const hasRecommendationTypes = testSettings?.recommendation_types?.length > 0;
    const recommendationTypes = testSettings?.recommendation_types || [];
    
    const modal = document.createElement('div');
    modal.className = 'ptb-modal-overlay';
    modal.innerHTML = `
        <div class="ptb-modal">
            <div class="modal-header">
                <h3>Редактировать профиль результата</h3>
                <button class="modal-close-btn" id="close-edit-modal">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit-result-name">Название профиля *</label>
                        <input type="text" id="edit-result-name" class="form-input" value="${escapeHtml(result.result_name)}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit-result-description">Описание профиля</label>
                        <textarea id="edit-result-description" class="form-textarea" rows="3">${escapeHtml(result.result_description || '')}</textarea>
                    </div>
                </div>
                
                <div class="recommendations-section">
                    <h5 class="section-subtitle">Рекомендации</h5>
                    <div id="edit-recommendations-container" class="recommendations-container">
                        ${hasRecommendationTypes ? 
                            recommendationTypes.map((type, index) => {
                                // Ищем рекомендацию по точному совпадению названия
                                const rec = (result.custom_recommendations || []).find(r => r.title === type);
                                return `
                                    <div class="recommendation-field predefined" data-index="${index}">
                                        <div class="recommendation-header predefined">
                                            <span class="rec-type-title">${escapeHtml(type)}</span>
                                        </div>
                                        <textarea class="rec-content-textarea" rows="3" placeholder="Каждая рекомендация с новой строки">${rec?.content?.join('\n') || ''}</textarea>
                                        <p class="form-hint">Каждая рекомендация с новой строки</p>
                                    </div>
                                `;
                            }).join('') : 
                            (result.custom_recommendations || []).map((rec, index) => `
                                <div class="recommendation-field" data-id="${rec.id || index}">
                                    <div class="recommendation-header">
                                        <input type="text" class="rec-title-input" placeholder="Название рекомендации" value="${escapeHtml(rec.title || '')}">
                                        <button type="button" class="button button-link delete-rec-btn" style="color: #dc2626; padding: 0; height: auto;">
                                            <span class="dashicons dashicons-trash"></span>
                                        </button>
                                    </div>
                                    <textarea class="rec-content-textarea" rows="3" placeholder="Каждая рекомендация с новой строки">${rec.content?.join('\n') || ''}</textarea>
                                    <p class="form-hint">Каждая рекомендация с новой строки</p>
                                </div>
                            `).join('')
                        }
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="button button-secondary" id="cancel-edit-btn">Отмена</button>
                <button class="button button-primary" id="save-result-btn" data-id="${result.id}">Сохранить изменения</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Инициализация контейнера рекомендаций в модальном окне (если типы не заданы)
    if (!hasRecommendationTypes) {
        const editContainer = document.getElementById('edit-recommendations-container');
        editContainer.querySelectorAll('.delete-rec-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                btn.closest('.recommendation-field').remove();
            });
        });
    }
    
    // Обработчики модального окна
    document.getElementById('close-edit-modal').addEventListener('click', () => {
        modal.remove();
    });
    
    document.getElementById('cancel-edit-btn').addEventListener('click', () => {
        modal.remove();
    });
    
    document.getElementById('save-result-btn').addEventListener('click', () => {
        const name = document.getElementById('edit-result-name').value.trim();
        if (!name) return alert('Введите название профиля');
        
        // Собираем все рекомендации
        const recommendations = collectRecommendationsFromContainer(
            document.getElementById('edit-recommendations-container'), 
            currentTest
        );
        
        const updateData = {
            category_combination: result.category_combination,
            result_name: name,
            result_description: document.getElementById('edit-result-description').value.trim(),
            custom_recommendations: recommendations
        };
        
        fetch(ptbAdminSettings.apiUrl + '/results/' + result.id, {
            method: 'PUT',
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                modal.remove();
                window.ptb.selectTest(currentTest.id);
            } else {
                alert('Ошибка сохранения');
            }
        })
        .catch(e => alert('Ошибка: ' + e.message));
    });
}

/**
 * Сбор рекомендаций из контейнера
 */
function collectRecommendationsFromContainer(container, currentTest) {
    const recommendations = [];
    
    // Парсим настройки теста
    let testSettings = currentTest.settings;
    if (typeof testSettings === 'string') {
        try {
            testSettings = JSON.parse(testSettings);
        } catch (e) {
            console.error('Ошибка парсинга настроек:', e);
            testSettings = {};
        }
    }
    
    // Проверяем, есть ли предопределённые типы
    const hasRecommendationTypes = testSettings?.recommendation_types?.length > 0;
    const recommendationTypes = testSettings?.recommendation_types || [];
    
    if (hasRecommendationTypes) {
        // Собираем данные для предопределённых типов
        container.querySelectorAll('.recommendation-field').forEach((field, index) => {
            const content = field.querySelector('.rec-content-textarea').value.trim();
            const typeTitle = recommendationTypes[index] || `Тип ${index + 1}`;
            
            if (content) {
                recommendations.push({
                    id: index,
                    title: typeTitle,
                    content: content.split('\n').filter(x => x.trim())
                });
            }
        });
    } else {
        // Собираем данные для гибких рекомендаций
        container.querySelectorAll('.recommendation-field').forEach(field => {
            const title = field.querySelector('.rec-title-input').value.trim();
            const content = field.querySelector('.rec-content-textarea').value.trim();
            
            if (title || content) {
                recommendations.push({
                    id: field.dataset.id || Date.now(),
                    title: title,
                    content: content.split('\n').filter(x => x.trim())
                });
            }
        });
    }
    
    return recommendations;
}

/**
 * Вспомогательная функция для экранирования HTML
 */
function escapeHtml(text) {
    if (typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}