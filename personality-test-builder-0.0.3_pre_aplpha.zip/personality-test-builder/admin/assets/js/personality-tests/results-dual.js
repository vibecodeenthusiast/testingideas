function renderResultsDualTab(container, currentTest) {
    console.log('renderResultsDualTab вызвана');
    
    if (!currentTest.categories || currentTest.categories.length === 0) {
        container.innerHTML = `
            <div class="ptb-empty-state">
                <p style="font-size: 18px; margin-bottom: 20px;">⚠️ Нет категорий</p>
                <p>Сначала добавьте категории на вкладке "Категории"</p>
                <button id="go-to-categories-btn" class="button button-primary ptb-primary" style="margin-top: 20px;">Перейти к категориям</button>
            </div>
        `;
        document.getElementById('go-to-categories-btn').addEventListener('click', () => {
            document.querySelectorAll('.ptb-editor-tabs button[data-tab="categories"]').forEach(b => {
                document.querySelectorAll('.ptb-editor-tabs button').forEach(x => x.classList.remove('active'));
                b.classList.add('active');
                window.ptb.renderTabContent('categories');
            });
        });
        return;
    }
    
    // Фильтруем профили для двух категорий
    const filteredResults = currentTest.results?.filter(r => r.rule_type === 'dual') || [];
    const allCombinations = generateCombinations(currentTest.categories, 'dual');
    const existingCombinations = filteredResults.map(r => r.category_combination);
    const missingCombinations = allCombinations.filter(c => !existingCombinations.includes(c));
    
    // Формируем разметку
    container.innerHTML = `
        <div class="ptb-form-group" style="margin-bottom: 25px; padding: 20px; background: #f8f9fa; border-radius: 8px; border: 1px solid #e0e0e0;">
            <h3 style="margin: 0 0 15px 0; font-size: 18px;">По двум ключевым категориям</h3>
            <p style="margin: 0; color: #666; line-height: 1.6;">Результат формируется на основе двух категорий с наибольшим количеством баллов</p>
        </div>
        
        ${missingCombinations.length > 0 ? `
            <div style="margin: 20px 0; padding: 15px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; color: #856404;">
                <strong>ℹ️ Недостающие комбинации (${missingCombinations.length}):</strong><br>
                ${missingCombinations.join(', ')}
                <p style="margin: 8px 0 0 0; font-size: 13px;">Создайте профили для этих комбинаций, чтобы покрыть все возможные результаты теста.</p>
            </div>
        ` : ''}
        
        <h3 style="margin: 20px 0 15px 0;">Добавить профиль результата</h3>
        
        <div class="ptb-form-group">
            <label>Выберите 2 категории</label>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; margin-top: 10px;">
                ${currentTest.categories.map(cat => `
                    <label style="display: flex; align-items: center; gap: 12px; padding: 15px; background: #f9f9f9; border: 2px solid #e0e0e0; border-radius: 8px; cursor: pointer;">
                        <input type="checkbox" class="result-category-checkbox" value="${cat.code}" data-id="${cat.id}" style="width: 22px; height: 22px;">
                        <span style="display: inline-block; width: 28px; height: 28px; background-color: ${cat.color}; border-radius: 50%; border: 2px solid white;"></span>
                        <div><strong>${cat.code}</strong><div style="font-size: 13px; color: #666;">${cat.name}</div></div>
                    </label>
                `).join('')}
            </div>
            <p id="category-hint" style="margin-top: 10px; font-size: 13px; color: #666;">Выберите ровно 2 категории</p>
        </div>
        
        <div id="profile-form" style="display: none;">
            <div class="ptb-form-group"><label>Название профиля *</label><input type="text" id="new-result-name" class="regular-text"></div>
            <div class="ptb-form-group"><label>Описание</label><textarea id="new-result-description" class="regular-text" rows="3"></textarea></div>
            
            <h4 style="margin: 25px 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #eee;">Рекомендации</h4>
            <div class="ptb-form-group"><label>Образование</label><textarea id="new-result-education" class="regular-text" rows="3"></textarea></div>
            <div class="ptb-form-group"><label>Карьерные пути</label><textarea id="new-result-career" class="regular-text" rows="3"></textarea></div>
            <div class="ptb-form-group"><label>Сферы для души</label><textarea id="new-result-soul" class="regular-text" rows="3"></textarea></div>
            <div class="ptb-form-group"><label>Как усилить сильные стороны</label><textarea id="new-result-strengthen" class="regular-text" rows="2"></textarea></div>
            <div class="ptb-form-group"><label>Области для развития</label><textarea id="new-result-develop" class="regular-text" rows="2"></textarea></div>
            
            <button id="add-result-btn" class="button button-primary ptb-primary" style="margin-top: 20px;">Сохранить профиль</button>
            <button id="clear-categories-btn" class="button" style="margin-top: 20px; margin-left: 10px;">Сбросить</button>
        </div>
        
        ${filteredResults.length > 0 ? `
            <h3 style="margin: 40px 0 15px 0; padding-top: 20px; border-top: 2px solid #eee;">Существующие профили (${filteredResults.length})</h3>
            ${filteredResults.map(res => {
                const cats = res.category_combination.split(',').map(code => {
                    const c = currentTest.categories.find(x => x.code === code.trim());
                    return c ? `<span style="display:inline-block;width:20px;height:20px;background:${c.color};border-radius:50%;margin-right:6px;"></span>${c.code}` : code;
                }).join(', ');
                return `
                    <div class="ptb-result-item" style="padding:20px;background:#f9f9f9;border:1px solid #e0e0e0;border-radius:8px;margin-bottom:15px;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;">
                            <div>
                                <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">${cats}</div>
                                <div style="font-size:18px;font-weight:600;">${res.result_name}</div>
                            </div>
                            <div style="display:flex;gap:10px;">
                                <button class="button edit-result-btn" data-id="${res.id}" style="height:36px;padding:0 15px;">Редактировать</button>
                                <button class="button ptb-danger delete-result-btn" data-id="${res.id}" style="height:36px;padding:0 15px;">Удалить</button>
                            </div>
                        </div>
                        ${res.result_description ? `<p style="margin:10px 0 0 0;color:#555;">${window.ptb.escapeHtml(res.result_description)}</p>` : ''}
                    </div>
                `;
            }).join('')}
        ` : `<div class="ptb-empty-state" style="margin-top:40px;"><p>Нет профилей для этого правила. Добавьте первый профиль выше.</p></div>`}
    `;
    
    // Обработчики чекбоксов
    const checkboxes = document.querySelectorAll('.result-category-checkbox');
    const profileForm = document.getElementById('profile-form');
    const categoryHint = document.getElementById('category-hint');
    
    function updateCategorySelection() {
        const selected = document.querySelectorAll('.result-category-checkbox:checked');
        const max = 2;
        
        checkboxes.forEach(cb => {
            const label = cb.closest('label');
            label.style.opacity = (selected.length >= max && !cb.checked) ? '0.5' : '1';
            label.style.pointerEvents = (selected.length >= max && !cb.checked) ? 'none' : 'auto';
        });
        
        profileForm.style.display = selected.length === max ? 'block' : 'none';
        categoryHint.innerHTML = selected.length === max ? 
            `<em style="color:#28a745;">✅ Выбрано 2 категории. Заполните профиль ниже.</em>` : 
            'Выберите ровно 2 категории';
    }
    
    checkboxes.forEach(cb => cb.addEventListener('change', updateCategorySelection));
    document.getElementById('clear-categories-btn')?.addEventListener('click', () => {
        checkboxes.forEach(cb => cb.checked = false);
        updateCategorySelection();
    });
    
    updateCategorySelection();
    
    // Добавление результата
    document.getElementById('add-result-btn')?.addEventListener('click', () => {
        const selected = Array.from(document.querySelectorAll('.result-category-checkbox:checked')).map(cb => cb.value);
        if (selected.length !== 2) return alert('Выберите ровно 2 категории');
        
        const combination = selected.sort().join(',');
        const name = document.getElementById('new-result-name').value.trim();
        if (!name) return alert('Введите название профиля');
        
        const data = {
            test_id: currentTest.id,
            rule_type: 'dual',
            category_combination: combination,
            result_name: name,
            result_description: document.getElementById('new-result-description').value.trim(),
            education_recommendations: document.getElementById('new-result-education').value.trim().split('\n').filter(x => x.trim()),
            career_recommendations: document.getElementById('new-result-career').value.trim().split('\n').filter(x => x.trim()),
            soul_areas: document.getElementById('new-result-soul').value.trim().split('\n').filter(x => x.trim()),
            strengthen_tips: document.getElementById('new-result-strengthen').value.trim().split('\n').filter(x => x.trim()),
            develop_tips: document.getElementById('new-result-develop').value.trim().split('\n').filter(x => x.trim())
        };
        
        fetch(ptbAdminSettings.apiUrl + '/results', {
            method: 'POST',
            headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) {
                checkboxes.forEach(cb => cb.checked = false);
                ['new-result-name', 'new-result-description', 'new-result-education', 'new-result-career', 'new-result-soul', 'new-result-strengthen', 'new-result-develop'].forEach(id => document.getElementById(id).value = '');
                profileForm.style.display = 'none';
                window.ptb.selectTest(currentTest.id);
            } else {
                alert('Ошибка добавления профиля');
            }
        })
        .catch(e => alert('Ошибка: ' + e.message));
    });
    
    // Удаление и редактирование
    document.querySelectorAll('.delete-result-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (confirm('Удалить профиль?')) {
                fetch(ptbAdminSettings.apiUrl + '/results/' + btn.dataset.id, { method: 'DELETE', headers: { 'X-WP-Nonce': ptbAdminSettings.nonce } })
                .then(r => r.json())
                .then(d => d.success ? window.ptb.selectTest(currentTest.id) : alert('Ошибка удаления'))
                .catch(e => alert('Ошибка: ' + e.message));
            }
        });
    });
    
    document.querySelectorAll('.edit-result-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const res = currentTest.results.find(r => r.id == btn.dataset.id);
            if (!res) return;
            
            const editForm = `
                <h3>Редактировать профиль результата</h3>
                <div class="ptb-form-group"><label>Название профиля *</label><input type="text" id="edit-result-name" class="regular-text" value="${window.ptb.escapeHtml(res.result_name)}"></div>
                <div class="ptb-form-group"><label>Описание</label><textarea id="edit-result-description" class="regular-text" rows="3">${window.ptb.escapeHtml(res.result_description)}</textarea></div>
                
                <h4 style="margin: 25px 0 15px 0; padding-bottom: 10px; border-bottom: 2px solid #eee;">Рекомендации</h4>
                <div class="ptb-form-group"><label>Образование</label><textarea id="edit-result-education" class="regular-text" rows="3">${res.education_recommendations?.join('\n') || ''}</textarea></div>
                <div class="ptb-form-group"><label>Карьерные пути</label><textarea id="edit-result-career" class="regular-text" rows="3">${res.career_recommendations?.join('\n') || ''}</textarea></div>
                <div class="ptb-form-group"><label>Сферы для души</label><textarea id="edit-result-soul" class="regular-text" rows="3">${res.soul_areas?.join('\n') || ''}</textarea></div>
                <div class="ptb-form-group"><label>Как усилить сильные стороны</label><textarea id="edit-result-strengthen" class="regular-text" rows="2">${res.strengthen_tips?.join('\n') || ''}</textarea></div>
                <div class="ptb-form-group"><label>Области для развития</label><textarea id="edit-result-develop" class="regular-text" rows="2">${res.develop_tips?.join('\n') || ''}</textarea></div>
                
                <button id="save-result-btn" class="button button-primary ptb-primary" style="margin-top: 20px;">Сохранить изменения</button>
                <button id="cancel-edit-btn" class="button" style="margin-top: 20px; margin-left: 10px;">Отмена</button>
            `;
            
            document.getElementById('tab-content').innerHTML = editForm;
            
           document.getElementById('save-result-btn').addEventListener('click', () => {
    const name = document.getElementById('edit-result-name').value.trim();
    if (!name) return alert('Введите название профиля');
    
    // 🎯 ИСПРАВЛЕНО: Собираем все поля для обновления
    const updateData = {
        category_combination: res.category_combination,
        result_name: name,
        result_description: document.getElementById('edit-result-description').value.trim(),
        education_recommendations: document.getElementById('edit-result-education').value.trim().split('\n').filter(x => x.trim()),
        career_recommendations: document.getElementById('edit-result-career').value.trim().split('\n').filter(x => x.trim()),
        soul_areas: document.getElementById('edit-result-soul').value.trim().split('\n').filter(x => x.trim()),
        strengthen_tips: document.getElementById('edit-result-strengthen').value.trim().split('\n').filter(x => x.trim()),
        develop_tips: document.getElementById('edit-result-develop').value.trim().split('\n').filter(x => x.trim())
    };
    
    fetch(ptbAdminSettings.apiUrl + '/results/' + res.id, {
        method: 'PUT',
        headers: { 'X-WP-Nonce': ptbAdminSettings.nonce, 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData)
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            window.ptb.selectTest(currentTest.id);
        } else {
            alert('Ошибка сохранения');
        }
    })
    .catch(e => alert('Ошибка: ' + e.message));
});
            
            document.getElementById('cancel-edit-btn').addEventListener('click', () => window.ptb.renderTabContent('results-dual'));
        });
    });
}

function generateCombinations(categories, rule) {
    const codes = categories.map(c => c.code).sort();
    if (rule === 'single') return codes;
    const combos = [];
    for (let i = 0; i < codes.length; i++) {
        for (let j = i + 1; j < codes.length; j++) {
            combos.push(codes[i] + ',' + codes[j]);
        }
    }
    return combos;
}