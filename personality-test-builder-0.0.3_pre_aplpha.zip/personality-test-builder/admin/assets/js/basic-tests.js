/**
 * Скрипты для базовых тестов
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        console.log('Basic Tests module loaded');
    });
    
})(jQuery);