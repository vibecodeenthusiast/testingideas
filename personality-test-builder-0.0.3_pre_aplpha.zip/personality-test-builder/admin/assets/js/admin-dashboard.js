/**
 * Скрипты для дашборда PTB
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Загружаем статистику
        loadDashboardStats();
    });
    
    /**
 * Загрузка статистики
 */
function loadDashboardStats() {
    fetch(ptbDashboardData.apiUrl + '/statistics', {
        headers: { 'X-WP-Nonce': ptbDashboardData.nonce }
    })
    .then(response => response.json())
    .then(data => {
        // Обновляем статистику
        updateStatistics(data);
        
        // Загружаем последние тесты
        loadRecentTests(data.recent_tests);
    })
    .catch(error => {
        console.error('Ошибка загрузки статистики:', error);
        $('#recent-tests-container').html('<p class="error">Ошибка загрузки данных</p>');
    });
}

/**
 * Обновление статистики
 */
function updateStatistics(data) {
    // Тесты
    $('#total-tests').text(data.tests.total || 0);
    $('#tests-personality').text(data.tests.personality || 0);
    $('#tests-basic').text(data.tests.basic || 0);
    $('#tests-quests').text(data.tests.quests || 0);
    
    // Вопросы
    $('#total-questions').text(data.questions.total || 0);
    $('#questions-personality').text(data.questions.personality || 0);
    $('#questions-basic').text(data.questions.basic || 0);
    $('#questions-quests').text(data.questions.quests || 0);
    
    // Завершённые тесты
    $('#completed-tests').text(data.completed_tests.total || 0);
    $('#completed-personality').text(data.completed_tests.personality || 0);
    $('#completed-basic').text(data.completed_tests.basic || 0);
    $('#completed-quests').text(data.completed_tests.quests || 0);
}
    
    /**
     * Загрузка последних тестов
     */
    function loadRecentTests(recentTests) {
        const container = $('#recent-tests-container');
        
        if (!recentTests || recentTests.length === 0) {
            container.html(`
                <div class="ptb-empty-recent">
                    <p>Нет созданных тестов</p>
                    <a href="${admin_url('admin.php?page=ptb-personality-tests')}" class="button button-primary" style="margin-top: 15px;">
                        Создать первый тест
                    </a>
                </div>
            `);
            return;
        }
        
        let html = `
            <div class="ptb-recent-tests-list">
                ${recentTests.map(test => `
                    <div class="ptb-recent-test-item">
                        <div class="test-info">
                            <h4>${escapeHtml(test.name)}</h4>
                            <p class="test-meta">
                                ID: ${test.id}
                                ${test.created_at ? ` | ${new Date(test.created_at).toLocaleDateString('ru-RU')}` : ''}
                            </p>
                        </div>
                        <div class="test-actions">
                            <a href="${admin_url('admin.php?page=ptb-personality-tests')}" class="button button-secondary">
                                Открыть
                            </a>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        container.html(html);
    }
    
    /**
     * Вспомогательная функция для экранирования HTML
     */
    function escapeHtml(text) {
        if (typeof text !== 'string') return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Вспомогательная функция для получения URL админки
     */
    function admin_url(path) {
        return path;
    }
    
})(jQuery);