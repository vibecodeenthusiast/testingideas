/**
 * Скрипты для настроек
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        console.log('Settings module loaded');
        
        // Добавляем валидацию формы (если нужно)
        $('form.ptb-settings-form').on('submit', function(e) {
            // Здесь можно добавить валидацию перед отправкой
        });
    });
    
})(jQuery);