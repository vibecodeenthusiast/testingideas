/**
 * Скрипты для личностных тестов
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        console.log('Personality Tests module loaded');
    });
    
})(jQuery);