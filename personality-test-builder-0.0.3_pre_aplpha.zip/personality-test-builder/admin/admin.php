<?php
if (!defined('ABSPATH')) exit;

// Подключаем все страницы разделов
require_once __DIR__ . '/pages/dashboard.php';
require_once __DIR__ . '/pages/basic-tests.php';
require_once __DIR__ . '/pages/personality-tests.php';
require_once __DIR__ . '/pages/quests.php';
require_once __DIR__ . '/pages/logic-maps.php';
require_once __DIR__ . '/pages/settings.php';

/**
 * Регистрация меню
 */
function ptb_admin_menu() {
    // Главное меню
    add_menu_page(
        'Personality Tests',
        'Personality Tests',
        'manage_options',
        'personality-tests',
        'ptb_render_dashboard', // Дашборд открывается по умолчанию
        'dashicons-awards',
        30
    );

    // Подменю - Дашборд (первый пункт)
    add_submenu_page(
        'personality-tests',
        'Дашборд',
        'Дашборд',
        'manage_options',
        'personality-tests',
        'ptb_render_dashboard'
    );

    // Подменю - Базовые тесты
    add_submenu_page(
        'personality-tests',
        'Базовые тесты',
        'Базовые тесты',
        'manage_options',
        'ptb-basic-tests',
        'ptb_render_basic_tests'
    );

    // Подменю - Личностные тесты
    add_submenu_page(
        'personality-tests',
        'Личностные тесты',
        'Личностные тесты',
        'manage_options',
        'ptb-personality-tests',
        'ptb_render_personality_tests'
    );

    // Подменю - Квесты и ветвления
    add_submenu_page(
        'personality-tests',
        'Квесты и ветвления',
        'Квесты и ветвления',
        'manage_options',
        'ptb-quests',
        'ptb_render_quests'
    );

    // Подменю - Логические карты
    add_submenu_page(
        'personality-tests',
        'Логические карты',
        'Логические карты',
        'manage_options',
        'ptb-logic-maps',
        'ptb_render_logic_maps'
    );

    // Подменю - Настройки
    add_submenu_page(
        'personality-tests',
        'Настройки',
        'Настройки',
        'manage_options',
        'ptb-settings',
        'ptb_render_settings'
    );
}
add_action('admin_menu', 'ptb_admin_menu');

/**
 * Подключение стилей и скриптов
 */
function ptb_enqueue_admin_assets($hook) {
    // Только для страниц нашего плагина
    if (strpos($hook, 'personality-tests') === false && strpos($hook, 'ptb-') === false) {
        return;
    }

    // Дашборд
    if ($hook === 'toplevel_page_personality-tests') {
        wp_enqueue_style('ptb-admin-dashboard', PTB_PLUGIN_URL . 'admin/assets/css/admin-dashboard.css', [], PTB_VERSION);
        wp_enqueue_script('ptb-admin-dashboard', PTB_PLUGIN_URL . 'admin/assets/js/admin-dashboard.js', ['jquery'], PTB_VERSION, true);
        wp_localize_script('ptb-admin-dashboard', 'ptbDashboardData', [
            'apiUrl' => rest_url('personality-test/v1'),
            'nonce' => wp_create_nonce('wp_rest')
        ]);
    }

    // Базовые тесты
    if ($hook === 'personality-tests_page_ptb-basic-tests') {
        wp_enqueue_style('ptb-basic-tests', PTB_PLUGIN_URL . 'admin/assets/css/basic-tests.css', [], PTB_VERSION);
        wp_enqueue_script('ptb-basic-tests', PTB_PLUGIN_URL . 'admin/assets/js/basic-tests.js', ['jquery'], PTB_VERSION, true);
    }

    // Личностные тесты (основной функционал) - ОБНОВЛЁННЫЕ ПУТИ
    if ($hook === 'personality-tests_page_ptb-personality-tests') {
        // Стили
        wp_enqueue_style('ptb-personality-tests-admin', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/admin.css', [], PTB_VERSION);
        wp_enqueue_style('ptb-personality-tests-questions', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/questions.css', ['ptb-personality-tests-admin'], PTB_VERSION);
        wp_enqueue_style('ptb-personality-tests-categories', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/categories.css', ['ptb-personality-tests-admin'], PTB_VERSION);
        wp_enqueue_style('ptb-personality-tests-results-single', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/results-single.css', ['ptb-personality-tests-admin'], PTB_VERSION);
        wp_enqueue_style('ptb-personality-tests-settings', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/settings.css', ['ptb-personality-tests-admin'], PTB_VERSION);
        
        // Скрипты
        wp_enqueue_script('ptb-personality-tests-main', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/admin-main.js', ['jquery'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-questions-templates', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/questions/templates.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-questions-handlers', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/questions/handlers.js', ['ptb-personality-tests-questions-templates'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-questions-index', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/questions/index.js', ['ptb-personality-tests-questions-handlers'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-categories', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/categories.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-results-single', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/results-single.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-results-dual', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/results-dual.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
        wp_enqueue_script('ptb-personality-tests-settings', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/settings.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
        
        wp_localize_script('ptb-personality-tests-main', 'ptbAdminSettings', [
            'apiUrl' => rest_url('personality-test/v1'),
            'nonce' => wp_create_nonce('wp_rest')
        ]);
    }

    // Квесты и ветвления
    if ($hook === 'personality-tests_page_ptb-quests') {
        wp_enqueue_style('ptb-quests', PTB_PLUGIN_URL . 'admin/assets/css/quests.css', [], PTB_VERSION);
        wp_enqueue_script('ptb-quests', PTB_PLUGIN_URL . 'admin/assets/js/quests.js', ['jquery'], PTB_VERSION, true);
    }

    // Логические карты
    if ($hook === 'personality-tests_page_ptb-logic-maps') {
        wp_enqueue_style('ptb-logic-maps', PTB_PLUGIN_URL . 'admin/assets/css/logic-maps.css', [], PTB_VERSION);
        wp_enqueue_script('ptb-logic-maps', PTB_PLUGIN_URL . 'admin/assets/js/logic-maps.js', ['jquery'], PTB_VERSION, true);
    }

    // Настройки
    if ($hook === 'personality-tests_page_ptb-settings') {
        wp_enqueue_style('ptb-settings', PTB_PLUGIN_URL . 'admin/assets/css/settings.css', [], PTB_VERSION);
        wp_enqueue_script('ptb-settings', PTB_PLUGIN_URL . 'admin/assets/js/settings.js', ['jquery'], PTB_VERSION, true);
    }

    // Обзорная страница (для личностных тестов)
    if ($hook === 'personality-tests_page_ptb-personality-tests') {
        wp_enqueue_style('ptb-overview', PTB_PLUGIN_URL . 'admin/assets/css/personality-tests/overview.css', ['ptb-personality-tests-admin'], PTB_VERSION);
        wp_enqueue_script('ptb-overview', PTB_PLUGIN_URL . 'admin/assets/js/personality-tests/overview.js', ['ptb-personality-tests-main'], PTB_VERSION, true);
    }
}
add_action('admin_enqueue_scripts', 'ptb_enqueue_admin_assets');