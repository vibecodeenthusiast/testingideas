<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг настроек
 */
function ptb_render_settings() {
    ?>
    <div class="wrap ptb-settings">
        <h1>Настройки плагина</h1>
        
        <div class="ptb-section-header">
            <h2>Общие настройки и системная информация</h2>
            <p>Конфигурация плагина и просмотр технической информации</p>
        </div>
        
        <form method="post" action="options.php" class="ptb-settings-form">
            <?php settings_fields('ptb_general_settings'); ?>
            <?php do_settings_sections('ptb_settings_page'); ?>
            
            <div class="ptb-settings-section">
                <h2>Основные настройки</h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Режим отладки</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_debug_mode" value="1" <?php checked(get_option('ptb_debug_mode'), 1); ?>>
                                Включить режим отладки (для разработчиков)
                            </label>
                            <p class="description">Показывать дополнительную информацию для отладки</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Кэширование</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_enable_cache" value="1" <?php checked(get_option('ptb_enable_cache', 1), 1); ?>>
                                Включить кэширование результатов
                            </label>
                            <p class="description">Ускоряет загрузку тестов, но может вызывать задержки при обновлении</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Сохранение результатов</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_save_results" value="1" <?php checked(get_option('ptb_save_results', 1), 1); ?>>
                                Сохранять результаты прохождений тестов
                            </label>
                            <p class="description">Позволяет анализировать статистику и отслеживать тенденции</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Сохранить настройки'); ?>
            </div>
            
            <div class="ptb-settings-section">
                <h2>Системная информация</h2>
                <table class="widefat" style="max-width: 800px;">
                    <tr>
                        <th>Версия плагина</th>
                        <td><?php echo PTB_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th>Версия WordPress</th>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <th>Версия PHP</th>
                        <td><?php echo PHP_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th>База данных</th>
                        <td><?php echo $GLOBALS['wpdb']->db_version(); ?></td>
                    </tr>
                </table>
            </div>
        </form>
    </div>
    <?php
}