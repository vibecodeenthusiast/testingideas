<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг личностных тестов
 */
function ptb_render_personality_tests() {
    ?>     
        <div id="ptb-admin-app"></div>
    </div>
    <?php
}