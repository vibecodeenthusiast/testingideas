<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг дашборда
 */
function ptb_render_dashboard() {
    ?>
    <div class="wrap ptb-dashboard">
        <h1>Personality Test Builder</h1>
        
        <div class="ptb-dashboard-grid">
            <div class="ptb-dashboard-section">
                <h2>Статистика</h2>
                <div class="ptb-stats-grid">
                    <!-- Тесты -->
                    <div class="ptb-stat-card">
                        <div class="stat-main">
                            <div class="stat-label">Всего тестов</div>
                            <div class="stat-number" id="total-tests">0</div>
                        </div>
                        <div class="stat-breakdown">
                            <div class="stat-breakdown-item type-personality">
                                <span class="type-label">Личностные</span>
                                <span class="type-value" id="tests-personality">0</span>
                            </div>
                            <div class="stat-breakdown-item type-basic">
                                <span class="type-label">Базовые</span>
                                <span class="type-value" id="tests-basic">0</span>
                            </div>
                            <div class="stat-breakdown-item type-quests">
                                <span class="type-label">Квесты</span>
                                <span class="type-value" id="tests-quests">0</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Вопросы -->
                    <div class="ptb-stat-card">
                        <div class="stat-main">
                            <div class="stat-label">Всего вопросов</div>
                            <div class="stat-number" id="total-questions">0</div>
                        </div>
                        <div class="stat-breakdown">
                            <div class="stat-breakdown-item type-personality">
                                <span class="type-label">Личностные</span>
                                <span class="type-value" id="questions-personality">0</span>
                            </div>
                            <div class="stat-breakdown-item type-basic">
                                <span class="type-label">Базовые</span>
                                <span class="type-value" id="questions-basic">0</span>
                            </div>
                            <div class="stat-breakdown-item type-quests">
                                <span class="type-label">Квесты</span>
                                <span class="type-value" id="questions-quests">0</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Завершённые тесты -->
                    <div class="ptb-stat-card">
                        <div class="stat-main">
                            <div class="stat-label">Завершённых тестов</div>
                            <div class="stat-sublabel" style="font-size: 12px; color: #6b7280; margin-top: 4px;">за 24 часа</div>
                            <div class="stat-number" id="completed-tests">0</div>
                        </div>
                        <div class="stat-breakdown">
                            <div class="stat-breakdown-item type-personality">
                                <span class="type-label">Личностные</span>
                                <span class="type-value" id="completed-personality">0</span>
                            </div>
                            <div class="stat-breakdown-item type-basic">
                                <span class="type-label">Базовые</span>
                                <span class="type-value" id="completed-basic">0</span>
                            </div>
                            <div class="stat-breakdown-item type-quests">
                                <span class="type-label">Квесты</span>
                                <span class="type-value" id="completed-quests">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ptb-dashboard-section">
    <h2>Быстрые действия</h2>
    <div class="ptb-quick-actions">
        <a href="<?php echo admin_url('admin.php?page=ptb-basic-tests'); ?>" class="ptb-btn ptb-btn-basic">
            <span class="dashicons dashicons-plus"></span>
            Создать Базовый тест
        </a>
        <a href="<?php echo admin_url('admin.php?page=ptb-personality-tests'); ?>" class="ptb-btn ptb-btn-personality">
            <span class="dashicons dashicons-plus"></span>
            Создать Личностный тест
        </a>
        <a href="<?php echo admin_url('admin.php?page=ptb-quests'); ?>" class="ptb-btn ptb-btn-quests">
            <span class="dashicons dashicons-plus"></span>
            Создать Квест или ветвление
        </a>
        <a href="<?php echo admin_url('admin.php?page=ptb-logic-maps'); ?>" class="ptb-btn ptb-btn-logic">
            <span class="dashicons dashicons-plus"></span>
            Создать Логическую карту
        </a>
        <a href="<?php echo admin_url('admin.php?page=ptb-settings'); ?>" class="ptb-btn ptb-btn-secondary">
            <span class="dashicons dashicons-admin-settings"></span>
            Настройки
        </a>
    </div>
</div>

            <div class="ptb-dashboard-section">
                <h2>Последние тесты</h2>
                <div id="recent-tests-container">
                    <div class="ptb-loading">Загрузка...</div>
                </div>
            </div>

            <div class="ptb-dashboard-section">
                <h2>Советы и подсказки</h2>
                <div class="ptb-tips">
                    <div class="ptb-tip">
                        <strong>Личностные тесты</strong>
                        <p>Идеальны для определения типа личности, профориентации, психологических опросников.</p>
                    </div>
                    <div class="ptb-tip">
                        <strong>Базовые тесты</strong>
                        <p>Простые тесты с вопросами и ответами для проверки знаний, опросов, викторин.</p>
                    </div>
                    <div class="ptb-tip">
                        <strong>Квесты и ветвления</strong>
                        <p>Интерактивные сценарии с ветвлениями и условиями для игр, обучающих программ, историй.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}