<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг базовых тестов
 */
function ptb_render_basic_tests() {
    ?>
    <div class="wrap ptb-basic-tests">
        <h1>Базовые тесты</h1>
        
        <div class="ptb-section-header">
            <h2>Тесты с вопросами и ответами</h2>
            <p>Простые тесты для проверки знаний, опросов и викторин</p>
        </div>
        
        <div class="ptb-feature-coming-soon">
            <div class="coming-soon-icon">🚧</div>
            <h2>Функционал в разработке</h2>
            <p>Базовые тесты — это простые тесты с вопросами и ответами, идеально подходящие для:</p>
            <ul>
                <li>Проверки знаний и тестирования</li>
                <li>Опросов и анкет</li>
                <li>Викторин</li>
                <li>Оценки навыков и компетенций</li>
            </ul>
            <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
            
            <div class="ptb-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=personality-tests'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptb-personality-tests'); ?>" class="button button-secondary">
                    Перейти к личностным тестам
                </a>
            </div>
        </div>
    </div>
    <?php
}