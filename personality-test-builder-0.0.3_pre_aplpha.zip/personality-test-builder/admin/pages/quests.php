<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг квестов и ветвлений
 */
function ptb_render_quests() {
    ?>
    <div class="wrap ptb-quests">
        <h1>Квесты и ветвления</h1>
        
        <div class="ptb-section-header">
            <h2>Интерактивные сценарии с ветвлениями</h2>
            <p>Создание квестов, игр и обучающих программ с условиями и разветвлениями</p>
        </div>
        
        <div class="ptb-feature-coming-soon">
            <div class="coming-soon-icon">🎯</div>
            <h2>Функционал в разработке</h2>
            <p>Квесты и ветвления — это интерактивные сценарии с условиями и разветвлениями, идеально подходящие для:</p>
            <ul>
                <li>Интерактивных историй и игр</li>
                <li>Обучающих программ с адаптивным маршрутом</li>
                <li>Бизнес-сценариев и кейсов</li>
                <li>Ролевых игр и симуляций</li>
            </ul>
            <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
            
            <div class="ptb-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=personality-tests'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptb-personality-tests'); ?>" class="button button-secondary">
                    Перейти к личностным тестам
                </a>
            </div>
        </div>
    </div>
    <?php
}