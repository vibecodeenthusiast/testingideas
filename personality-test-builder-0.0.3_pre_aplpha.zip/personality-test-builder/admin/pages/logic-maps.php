<?php
if (!defined('ABSPATH')) exit;

/**
 * Рендеринг логических карт
 */
function ptb_render_logic_maps() {
    ?>
    <div class="wrap ptb-logic-maps">
        <h1>Логические карты</h1>
        
        <div class="ptb-section-header">
            <h2>Визуальные инструменты для создания логических связей</h2>
            <p>Создание диаграмм, деревьев решений и экспертных систем</p>
        </div>
        
        <div class="ptb-feature-coming-soon">
            <div class="coming-soon-icon">🧠</div>
            <h2>Функционал в разработке</h2>
            <p>Логические карты — это визуальные инструменты для создания сложных логических связей и зависимостей, идеально подходящие для:</p>
            <ul>
                <li>Диагностических деревьев и алгоритмов</li>
                <li>Принятия решений на основе множества факторов</li>
                <li>Визуализации бизнес-процессов</li>
                <li>Создания экспертных систем</li>
            </ul>
            <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
            
            <div class="ptb-quick-actions">
                <a href="<?php echo admin_url('admin.php?page=personality-tests'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptb-personality-tests'); ?>" class="button button-secondary">
                    Перейти к личностным тестам
                </a>
            </div>
        </div>
    </div>
    <?php
}