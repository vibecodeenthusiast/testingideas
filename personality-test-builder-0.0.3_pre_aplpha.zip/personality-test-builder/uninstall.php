<?php
/**
 * Очистка данных при удалении плагина
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Проверяем, нужно ли удалять данные
if (get_option('personality_test_builder_remove_data_on_uninstall', false)) {
    global $wpdb;
    
    $prefix = $wpdb->prefix;
    
    // Удаляем таблицы
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_tests");
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_categories");
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_questions");
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_answers");
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_results");
    $wpdb->query("DROP TABLE IF EXISTS {$prefix}ptb_user_answers");
    
    // Удаляем опции
    delete_option('personality_test_builder_db_version');
    delete_option('personality_test_builder_remove_data_on_uninstall');
}