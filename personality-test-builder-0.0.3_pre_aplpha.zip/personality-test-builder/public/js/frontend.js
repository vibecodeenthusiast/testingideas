/**
 * Фронтенд-скрипт для прохождения теста
 */

(function($) {
    'use strict';
    
    // Глобальные переменные
    let currentTest = null;
    let currentQuestionIndex = 0;
    let answers = [];
    let currentSettings = {};
    
    /**
     * Инициализация теста
     */
    function init() {
        const $container = $('.personality-test-container');
        if ($container.length === 0) {
            console.warn('Элемент .personality-test-container не найден');
            return;
        }
        
        const testId = $container.data('test-id');
        if (!testId) {
            console.error('Не указан атрибут data-test-id');
            $container.html('<p class="ptb-error">Ошибка: не указан ID теста</p>');
            return;
        }
        
        // Показываем сообщение о загрузке
        $container.html('<div class="ptb-loading">Загрузка теста...</div>');
        
        // Загружаем данные теста
        fetch(ptbFrontendData.apiUrl + '/tests/' + testId, {
            headers: {
                'X-WP-Nonce': ptbFrontendData.nonce
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Данные теста получены:', data);
            
            if (!data || !data.name) {
                throw new Error('Некорректные данные теста');
            }
            
            currentTest = data;
            
            // Парсим настройки (могут приходить как строка или объект)
            if (typeof currentTest.settings === 'string') {
                try {
                    currentTest.settings = JSON.parse(currentTest.settings);
                    console.log('Настройки распарсены:', currentTest.settings);
                } catch (e) {
                    console.warn('Ошибка парсинга настроек, используются настройки по умолчанию:', e);
                    currentTest.settings = {};
                }
            } else if (!currentTest.settings) {
                currentTest.settings = {};
            }
            
            currentSettings = currentTest.settings;
            
            // Проверяем наличие вопросов
            if (!currentTest.questions || currentTest.questions.length === 0) {
                throw new Error('В тесте нет вопросов');
            }
            
            // Проверяем наличие категорий
            if (!currentTest.categories || currentTest.categories.length === 0) {
                throw new Error('В тесте нет категорий');
            }
            
            // Показываем стартовый экран
            showStartScreen();
        })
        .catch(error => {
            console.error('Ошибка загрузки теста:', error);
            $container.html(`
                <div class="ptb-error-screen">
                    <h2>Ошибка загрузки теста</h2>
                    <p>${error.message || 'Не удалось загрузить тест. Пожалуйста, попробуйте позже.'}</p>
                    <p class="ptb-debug-info">ID теста: ${testId}</p>
                    <button class="ptb-btn ptb-btn-primary" onclick="location.reload()">Попробовать снова</button>
                </div>
            `);
        });
    }
    
    /**
     * Показ стартового экрана
     */
    function showStartScreen() {
        const $container = $('.personality-test-container');
        
        let html = `
            <div class="ptb-start-screen">
                <h2>${escapeHtml(currentTest.name)}</h2>
                ${currentTest.description ? `<p class="ptb-description">${escapeHtml(currentTest.description)}</p>` : ''}
                <p class="ptb-question-count">Вопросов: ${currentTest.questions.length}</p>
        `;
        
        // Показываем прогресс-бар, если включено
        if (currentSettings.showProgress !== false) {
            html += `
                <div class="ptb-progress-container">
                    <div class="ptb-progress-bar">
                        <div class="ptb-progress-fill" style="width: 0%"></div>
                    </div>
                    <div class="ptb-progress-text">0/${currentTest.questions.length}</div>
                </div>
            `;
        }
        
        html += `
                <button class="ptb-btn ptb-btn-primary ptb-start-btn">Начать тест</button>
            </div>
        `;
        
        $container.html(html);
        
        // Обработчик кнопки "Начать тест"
        $container.find('.ptb-start-btn').on('click', () => {
            currentQuestionIndex = 0;
            answers = [];
            showQuestion();
        });
    }
    
    /**
     * Показ вопроса
     */
    function showQuestion() {
        const $container = $('.personality-test-container');
        
        if (!currentTest.questions || currentQuestionIndex >= currentTest.questions.length) {
            calculateResult();
            return;
        }
        
        const question = currentTest.questions[currentQuestionIndex];
        const isLastQuestion = currentQuestionIndex === currentTest.questions.length - 1;
        
        let html = `
            <div class="ptb-question-screen">
                ${currentSettings.showProgress !== false ? `
                    <div class="ptb-progress-info">
                        <span class="ptb-progress-counter">${currentQuestionIndex + 1} из ${currentTest.questions.length}</span>
                    </div>
                ` : ''}
                
                <div class="ptb-question-card">
                    <h3 class="ptb-question-title">${escapeHtml(question.question_text)}</h3>
                    
                    <div class="ptb-answers">
        `;
        
        // Сортируем ответы по sort_order
        const sortedAnswers = [...(question.answers || [])].sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
        
        if (sortedAnswers.length === 0) {
            html += `<p class="ptb-error">Вопрос не имеет вариантов ответов</p>`;
        } else {
            sortedAnswers.forEach(answer => {
                html += `
                    <label class="ptb-answer-item">
                        <input type="radio" name="answer" value="${answer.id}">
                        <div class="ptb-answer-content">
                            <div class="ptb-answer-text">${escapeHtml(answer.answer_text)}</div>
                `;
                
                // Показываем категории и веса ТОЛЬКО если включено в настройках
                if (currentSettings.showAnswerCategories || currentSettings.showAnswerWeights) {
                    if (answer.category_weights) {
                        try {
                            const weights = typeof answer.category_weights === 'string' 
                                ? JSON.parse(answer.category_weights) 
                                : answer.category_weights;
                            
                            if (Array.isArray(weights) && weights.length > 0) {
                                html += `<div class="ptb-answer-categories">`;
                                weights.forEach(weight => {
                                    const category = currentTest.categories?.find(c => c.id == weight.category_id);
                                    if (category) {
                                        const showWeight = currentSettings.showAnswerWeights;
                                        const weightText = showWeight ? (weight.weight > 0 ? '+' + weight.weight : weight.weight) : '';
                                        
                                        html += `
                                            <span class="ptb-category-badge" style="background-color: ${category.color};">
                                                ${category.code} ${weightText}
                                            </span>
                                        `;
                                    }
                                });
                                html += `</div>`;
                            }
                        } catch (e) {
                            console.warn('Ошибка отображения категорий ответа:', e);
                        }
                    }
                }
                
                html += `
                        </div>
                    </label>
                `;
            });
        }
        
        html += `
                    </div>
        `;
        
        // В мгновенном режиме кнопка "Далее" не показывается
        if (currentSettings.answerMode !== 'instant') {
            html += `
                    <div class="ptb-question-actions">
            `;
            
            // Кнопка "Назад" (кроме первого вопроса)
            if (currentQuestionIndex > 0) {
                html += `<button class="ptb-btn ptb-btn-secondary ptb-prev-btn">← Назад</button>`;
            }
            
            // Кнопка "Далее" или "Завершить тест"
            html += `
                        <button class="ptb-btn ptb-btn-primary ptb-next-btn">
                            ${isLastQuestion ? 'Завершить тест →' : 'Далее →'}
                        </button>
                    </div>
            `;
        }
        
        html += `
                </div>
            </div>
        `;
        
        $container.html(html);
        
        // Обработчики кнопок
        $container.find('.ptb-prev-btn').on('click', () => {
            currentQuestionIndex--;
            showQuestion();
        });
        
        // В мгновенном режиме - автоматический переход при выборе ответа
        if (currentSettings.answerMode === 'instant') {
            $container.find('.ptb-answer-item input[type="radio"]').on('change', function() {
                handleAnswerSelected(question, $(this).val());
            });
        } else {
            // В стандартном режиме - переход по кнопке
            $container.find('.ptb-next-btn').on('click', () => {
                const selectedAnswer = $container.find('input[name="answer"]:checked');
                if (selectedAnswer.length === 0) {
                    alert('Пожалуйста, выберите ответ');
                    return;
                }
                
                handleAnswerSelected(question, selectedAnswer.val());
            });
        }
    }
    
    /**
     * Обработка выбранного ответа
     */
    function handleAnswerSelected(question, answerId) {
        // Сохраняем ответ
        answers.push({
            question_id: question.id,
            answer_id: answerId
        });
        
        currentQuestionIndex++;
        
        // Обновляем прогресс
        if (currentSettings.showProgress !== false) {
            const progress = Math.round((currentQuestionIndex / currentTest.questions.length) * 100);
            $('.ptb-progress-fill').css('width', progress + '%');
            $('.ptb-progress-text').text(`${currentQuestionIndex}/${currentTest.questions.length}`);
        }
        
        showQuestion();
    }
    
    /**
     * Расчёт результата
     */
    function calculateResult() {
        // Считаем баллы по категориям
        const categoryScores = {};
        
        console.log('Расчёт результата. Всего ответов:', answers.length);
        
        answers.forEach(answer => {
            // Находим вопрос по ID
            const question = currentTest.questions.find(q => q.id == answer.question_id);
            if (!question) {
                console.warn('Вопрос не найден для ответа:', answer);
                return;
            }
            
            // Находим выбранный ответ по ID
            const selectedAnswer = question.answers.find(a => a.id == answer.answer_id);
            if (!selectedAnswer) {
                console.warn('Ответ не найден:', answer);
                return;
            }
            
            // Получаем веса категорий из исходных данных
            let weightsData = selectedAnswer.category_weights;
            
            // Парсим, если это строка
            if (typeof weightsData === 'string' && weightsData.trim() !== '') {
                try {
                    weightsData = JSON.parse(weightsData);
                } catch (e) {
                    console.error('Ошибка парсинга весов для ответа', answer.answer_id, ':', e);
                    return;
                }
            }
            
            // Обрабатываем веса
            if (Array.isArray(weightsData)) {
                weightsData.forEach(weight => {
                    const categoryId = weight.category_id;
                    const points = weight.weight || 0;
                    
                    if (!categoryScores[categoryId]) {
                        categoryScores[categoryId] = 0;
                    }
                    
                    categoryScores[categoryId] += points;
                });
            }
        });
        
        console.log('Баллы по категориям:', categoryScores);
        
        // Определяем результат в зависимости от правила
        let result = null;
        
        if (currentSettings.resultRule === 'single') {
            // По одной категории
            result = findResultBySingleCategory(categoryScores);
        } else if (currentSettings.resultRule === 'dual') {
            // По двум категориям
            result = findResultByDualCategories(categoryScores);
        } else {
            // По умолчанию - по одной категории
            result = findResultBySingleCategory(categoryScores);
        }
        
        console.log('Найденный результат:', result);
        
        // Показываем результат
        showResult(result, categoryScores);
    }
    
    /**
     * Найти результат по одной категории
     */
    function findResultBySingleCategory(categoryScores) {
        // Находим категорию с максимальным баллом
        let maxScore = -Infinity;
        let maxCategoryId = null;
        
        for (const categoryId in categoryScores) {
            if (categoryScores[categoryId] > maxScore) {
                maxScore = categoryScores[categoryId];
                maxCategoryId = categoryId;
            }
        }
        
        if (!maxCategoryId) return null;
        
        // Находим категорию
        const category = currentTest.categories?.find(c => c.id == maxCategoryId);
        
        if (!category) {
            console.warn('Категория не найдена для ID:', maxCategoryId);
            return null;
        }
        
        console.log('Категория с максимальным баллом:', category.code, '(', maxScore, 'баллов)');
        
        // Находим профиль результата по коду категории
        const result = currentTest.results?.find(r => 
            r.rule_type === 'single' && 
            r.category_combination === category.code
        );
        
        if (!result) {
            console.warn('Профиль результата не найден для категории:', category.code);
        }
        
        return result;
    }
    
    /**
     * Найти результат по двум категориям
     */
    function findResultByDualCategories(categoryScores) {
        // Находим две категории с максимальными баллами
        const sortedCategories = Object.entries(categoryScores)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 2);
        
        if (sortedCategories.length < 2) {
            console.warn('Недостаточно категорий для правила "по двум категориям"');
            return null;
        }
        
        const categoryCodes = sortedCategories.map(([id]) => {
            const category = currentTest.categories?.find(c => c.id == id);
            return category ? category.code : null;
        }).filter(Boolean);
        
        if (categoryCodes.length < 2) {
            console.warn('Не удалось найти 2 категории для правила "по двум категориям"');
            return null;
        }
        
        // Сортируем коды для поиска (чтобы "I,R" и "R,I" считались одинаково)
        const sortedCodes = categoryCodes.sort().join(',');
        
        console.log('Комбинация категорий:', sortedCodes);
        
        // Находим профиль результата
        const result = currentTest.results?.find(r => 
            r.rule_type === 'dual' && 
            r.category_combination === sortedCodes
        );
        
        if (!result) {
            console.warn('Профиль результата не найден для комбинации:', sortedCodes);
        }
        
        return result;
    }
    
    /**
     * Показ результата
     */
    function showResult(result, categoryScores) {
        const $container = $('.personality-test-container');
        
        if (!result) {
            $container.html(`
                <div class="ptb-result-screen">
                    <h2>Результат не найден</h2>
                    <p>К сожалению, не удалось определить ваш результат. Пожалуйста, пройдите тест ещё раз.</p>
                    <div class="ptb-debug-info">
                        <p>Баллы по категориям: ${JSON.stringify(categoryScores)}</p>
                        <p>Правило: ${currentSettings.resultRule || 'single'}</p>
                    </div>
                    <button class="ptb-btn ptb-btn-primary ptb-restart-btn">Начать заново</button>
                </div>
            `);
            
            $container.find('.ptb-restart-btn').on('click', showStartScreen);
            return;
        }
        
        // Находим категорию(и) результата
        const categoryCodes = (result.category_combination || '').split(',').filter(Boolean);
        const categories = categoryCodes.map(code => 
            currentTest.categories?.find(c => c.code === code)
        ).filter(Boolean);
        
        // Парсим рекомендации
        let customRecommendations = [];
        if (result.custom_recommendations) {
            if (typeof result.custom_recommendations === 'string') {
                try {
                    customRecommendations = JSON.parse(result.custom_recommendations);
                    console.log('Рекомендации распарсены:', customRecommendations);
                } catch (e) {
                    console.error('Ошибка парсинга рекомендаций:', e);
                }
            } else {
                customRecommendations = result.custom_recommendations;
            }
        }
        
        let html = `
            <div class="ptb-result-screen">
                <h2>Ваш результат: ${escapeHtml(result.result_name)}</h2>
                
                ${result.result_description ? `
                    <div class="ptb-result-description">
                        ${escapeHtml(result.result_description)}
                    </div>
                ` : ''}
                
                ${categories.length > 0 && currentSettings.showResultCategories !== false ? `
                    <div class="ptb-result-categories">
                        <h3>Ваши ключевые категории:</h3>
                        <div class="ptb-categories-grid">
                            ${categories.map(cat => `
                                <div class="ptb-category-card" style="--category-color: ${cat.color};">
                                    <div class="ptb-category-icon">
                                        <span class="ptb-category-initial">${cat.name.charAt(0)}</span>
                                    </div>
                                    <div class="ptb-category-content">
                                        <div class="ptb-category-name">${cat.name}</div>
                                        <div class="ptb-category-score">
                                            <span class="ptb-score-label">Баллов:</span>
                                            <span class="ptb-score-value">${categoryScores[cat.id] || 0}</span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
        `;
        
        // Отображаем рекомендации, если включено в настройках
        if (currentSettings.showRecommendations !== false && customRecommendations && customRecommendations.length > 0) {
            const filledRecommendations = customRecommendations.filter(rec => 
                rec && rec.content && rec.content.length > 0
            );
            
            if (filledRecommendations.length > 0) {
                html += `
                    <div class="ptb-recommendations">
                        <h3>Рекомендации</h3>
                        ${filledRecommendations.map(rec => `
                            <div class="ptb-recommendation-section">
                                <h4>${escapeHtml(rec.title || 'Рекомендация')}</h4>
                                <ul class="ptb-recommendation-list">
                                    ${rec.content.map(item => `
                                        <li>${escapeHtml(item)}</li>
                                    `).join('')}
                                </ul>
                            </div>
                        `).join('')}
                    </div>
                `;
            }
        }
        
        // Кнопка "Пройти тест ещё раз"
        if (currentSettings.allowRetake !== false) {
            html += `
                <button class="ptb-btn ptb-btn-primary ptb-restart-btn">
                    Пройти тест ещё раз
                </button>
            `;
        }
        
        html += `</div>`;
        
        $container.html(html);
        
        // Обработчик кнопки "Начать заново"
        $container.find('.ptb-restart-btn').on('click', showStartScreen);
    }
    
    /**
     * Вспомогательная функция для экранирования HTML
     */
    function escapeHtml(text) {
        if (typeof text !== 'string') return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Инициализация при загрузке документа
    $(document).ready(function() {
        console.log('Инициализация теста...');
        console.log('ptbFrontendData:', window.ptbFrontendData);
        init();
    });
    
})(jQuery);