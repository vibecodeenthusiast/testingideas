<?php
/**
 * Plugin Name: Personality Test Builder
 * Plugin URI: https://example.com/personality-test-builder
 * Description: Создание личностных тестов с гибкой настройкой вопросов, категорий и результатов (включая RIASEC)
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * Text Domain: personality-test-builder
 * Domain Path: /languages
 *
 * @package Personality_Test_Builder
 */

// Предотвращаем прямой доступ
if (!defined('ABSPATH')) {
    exit;
}

// Константы плагина
define('PTB_VERSION', '1.0.0');
define('PTB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PTB_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PTB_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Подключение классов
require_once PTB_PLUGIN_DIR . 'includes/class-plugin.php';
require_once PTB_PLUGIN_DIR . 'includes/class-database.php';
require_once PTB_PLUGIN_DIR . 'includes/class-rest-api.php';
require_once PTB_PLUGIN_DIR . 'includes/class-shortcode.php';
require_once PTB_PLUGIN_DIR . 'includes/class-ajax.php';
require_once PTB_PLUGIN_DIR . 'admin/admin.php'; // ← Единственное подключение админки

/**
 * Инициализация плагина
 *
 * @return Personality_Test_Builder_Plugin
 */
function run_personality_test_builder() {
    return new Personality_Test_Builder_Plugin();
}

// Запускаем плагин
$personality_test_builder = run_personality_test_builder();