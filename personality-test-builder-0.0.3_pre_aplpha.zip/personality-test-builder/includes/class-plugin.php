<?php
/**
 * Основной класс плагина
 */

if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_Plugin {
    
    private $db;
    private $rest_api;
    private $shortcode;
    private $ajax;
    
    public function __construct() {
        $this->db = new Personality_Test_Builder_Database();
        $this->rest_api = new Personality_Test_Builder_REST_API();
        $this->shortcode = new Personality_Test_Builder_Shortcode(); // ✅ Шорткод подключен
        $this->ajax = new Personality_Test_Builder_AJAX();
        
        // Хуки активации/деактивации
        register_activation_hook(PTB_PLUGIN_DIR . 'personality-test-builder.php', 
            [$this->db, 'activate']);
        
        register_deactivation_hook(PTB_PLUGIN_DIR . 'personality-test-builder.php', 
            [$this->db, 'deactivate']);
    }
    
    public function get_db() {
        return $this->db;
    }
    
    public function get_rest_api() {
        return $this->rest_api;
    }
}