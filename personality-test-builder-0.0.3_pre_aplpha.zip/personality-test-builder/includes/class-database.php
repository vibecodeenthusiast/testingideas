<?php
/**
 * Класс для работы с базой данных
 *
 * @package Personality_Test_Builder
 */
if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_Database {

    /**
     * Префикс таблиц
     */
    private $prefix;

    /**
     * Конструктор
     */
    public function __construct() {
        global $wpdb;
        $this->prefix = $wpdb->prefix;
    }

    /**
     * Активация плагина
     */
    public function activate() {
        $this->create_tables();
        $this->upgrade_database();
    }

    /**
     * Деактивация плагина
     */
    public function deactivate() {
        // Пустой метод для предотвращения ошибок при деактивации
    }

    /**
     * Создание таблиц при активации плагина — ИСПРАВЛЕНО: добавлены поля type и status
     */
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Таблица тестов — ОБНОВЛЕНА с полями type и status
        $sql_tests = "CREATE TABLE {$this->prefix}ptb_tests (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            type VARCHAR(50) DEFAULT 'personality',
            status VARCHAR(20) DEFAULT 'draft',
            settings TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";

        // Таблица категорий
        $sql_categories = "CREATE TABLE {$this->prefix}ptb_categories (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            test_id INT(11) UNSIGNED NOT NULL,
            name VARCHAR(255) NOT NULL,
            code VARCHAR(50) NOT NULL,
            color VARCHAR(7) DEFAULT '#3b82f6',
            description TEXT,
            sort_order INT(11) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY test_id (test_id)
        ) $charset_collate;";

        // Таблица вопросов
        $sql_questions = "CREATE TABLE {$this->prefix}ptb_questions (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            test_id INT(11) UNSIGNED NOT NULL,
            question_text TEXT NOT NULL,
            question_type VARCHAR(50) DEFAULT 'single',
            image_url VARCHAR(255),
            weight INT(11) DEFAULT 1,
            sort_order INT(11) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY test_id (test_id)
        ) $charset_collate;";

        // Таблица ответов
        $sql_answers = "CREATE TABLE {$this->prefix}ptb_answers (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            question_id INT(11) UNSIGNED NOT NULL,
            answer_text TEXT NOT NULL,
            category_id INT(11) UNSIGNED DEFAULT 0,
            points INT(11) DEFAULT 0,
            category_weights TEXT NULL,
            sort_order INT(11) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY question_id (question_id)
        ) $charset_collate;";

        // Таблица результатов
        $sql_results = "CREATE TABLE {$this->prefix}ptb_results (
            id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            test_id INT(11) UNSIGNED NOT NULL,
            result_name VARCHAR(255) NOT NULL,
            result_description TEXT,
            category_combination VARCHAR(255) NOT NULL,
            rule_type VARCHAR(50) DEFAULT 'dual',
            education_recommendations TEXT,
            career_recommendations TEXT,
            soul_areas TEXT,
            strengthen_tips TEXT,
            develop_tips TEXT,
            custom_recommendations TEXT,
            image_url VARCHAR(255),
            sort_order INT(11) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY test_id (test_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_tests);
        dbDelta($sql_categories);
        dbDelta($sql_questions);
        dbDelta($sql_answers);
        dbDelta($sql_results);

        // Устанавливаем версию базы данных
        $current_version = get_option('ptb_db_version', '1.0');
        if (version_compare($current_version, '1.3', '<')) {
            update_option('ptb_db_version', '1.3');
        }
    }

    /**
     * Обновление структуры базы данных (миграции) — ИСПРАВЛЕНО: добавлена миграция 1.3
     */
    public function upgrade_database() {
        global $wpdb;

        // Проверяем версию базы данных
        $current_version = get_option('ptb_db_version', '1.0');

        // Миграция 1.0 → 1.1: Добавление поля category_weights в таблицу ответов
        if (version_compare($current_version, '1.1', '<')) {
            $table_name = $this->prefix . 'ptb_answers';
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'category_weights'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN category_weights TEXT NULL AFTER points");
            }
            update_option('ptb_db_version', '1.1');
        }

        // Миграция 1.1 → 1.2: Добавление поля custom_recommendations в таблицу результатов
        if (version_compare($current_version, '1.2', '<')) {
            $table_name = $this->prefix . 'ptb_results';
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'custom_recommendations'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN custom_recommendations TEXT NULL AFTER develop_tips");
            }
            update_option('ptb_db_version', '1.2');
        }

        // Миграция 1.2 → 1.3: Добавление полей type и status в таблицу тестов
        if (version_compare($current_version, '1.3', '<')) {
            $table_name = $this->prefix . 'ptb_tests';
            
            // Проверяем и добавляем поле type
            $type_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'type'");
            if (empty($type_exists)) {
                $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN type VARCHAR(50) DEFAULT 'personality' AFTER description");
            }
            
            // Проверяем и добавляем поле status
            $status_exists = $wpdb->get_results("SHOW COLUMNS FROM {$table_name} LIKE 'status'");
            if (empty($status_exists)) {
                $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN status VARCHAR(20) DEFAULT 'draft' AFTER type");
            }
            
            update_option('ptb_db_version', '1.3');
        }
    }

    /**
     * Создание теста — ИСПРАВЛЕНО: добавлены поля type и status
     */
    public function create_test($data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_tests';

        $wpdb->insert(
            $table_name,
            [
                'name' => sanitize_text_field($data['name']),
                'description' => sanitize_textarea_field($data['description'] ?? ''),
                'type' => sanitize_text_field($data['type'] ?? 'personality'),
                'status' => sanitize_text_field($data['status'] ?? 'draft'),
                'settings' => isset($data['settings']) ? wp_json_encode($data['settings']) : wp_json_encode([])
            ],
            ['%s', '%s', '%s', '%s', '%s'] // ← ДОБАВЛЕНЫ %s для type и status
        );

        return $wpdb->insert_id;
    }

    /**
     * Получение теста по ID
     */
    public function get_test($test_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_tests';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $test_id
        ), ARRAY_A);
    }

    /**
     * Получение всех тестов
     */
    public function get_tests() {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_tests';

        return $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY id DESC", ARRAY_A);
    }

    /**
     * Обновление теста
     */
    public function update_test($test_id, $data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_tests';

        $update_data = [];
        if (isset($data['name'])) {
            $update_data['name'] = sanitize_text_field($data['name']);
        }
        if (isset($data['description'])) {
            $update_data['description'] = sanitize_textarea_field($data['description']);
        }
        if (isset($data['type'])) {
            $update_data['type'] = sanitize_text_field($data['type']);
        }
        if (isset($data['status'])) {
            $update_data['status'] = sanitize_text_field($data['status']);
        }
        if (isset($data['settings'])) {
            $update_data['settings'] = wp_json_encode($data['settings']);
        }

        $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $test_id]
        );

        return true;
    }

    /**
     * Удаление теста
     */
    public function delete_test($test_id) {
        global $wpdb;

        // Удаляем связанные данные
        $wpdb->delete($this->prefix . 'ptb_categories', ['test_id' => $test_id]);
        $wpdb->delete($this->prefix . 'ptb_questions', ['test_id' => $test_id]);
        $wpdb->delete($this->prefix . 'ptb_results', ['test_id' => $test_id]);

        // Удаляем сам тест
        $wpdb->delete($this->prefix . 'ptb_tests', ['id' => $test_id]);

        return true;
    }

    /**
     * Создание категории
     */
    public function create_category($data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_categories';

        $wpdb->insert(
            $table_name,
            [
                'test_id' => intval($data['test_id']),
                'name' => sanitize_text_field($data['name']),
                'code' => sanitize_text_field($data['code']),
                'color' => sanitize_text_field($data['color'] ?? '#3b82f6'),
                'description' => sanitize_textarea_field($data['description'] ?? ''),
                'sort_order' => intval($data['sort_order'] ?? 0)
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d']
        );

        return $wpdb->insert_id;
    }

    /**
     * Получение категорий по тесту
     */
    public function get_categories_by_test($test_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_categories';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE test_id = %d ORDER BY sort_order ASC",
            $test_id
        ), ARRAY_A);
    }

    /**
     * Обновление категории
     */
    public function update_category($category_id, $data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_categories';

        $update_data = [];
        if (isset($data['name'])) {
            $update_data['name'] = sanitize_text_field($data['name']);
        }
        if (isset($data['code'])) {
            $update_data['code'] = sanitize_text_field($data['code']);
        }
        if (isset($data['color'])) {
            $update_data['color'] = sanitize_text_field($data['color']);
        }
        if (isset($data['description'])) {
            $update_data['description'] = sanitize_textarea_field($data['description']);
        }
        if (isset($data['sort_order'])) {
            $update_data['sort_order'] = intval($data['sort_order']);
        }

        $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $category_id]
        );

        return true;
    }

    /**
     * Удаление категории
     */
    public function delete_category($category_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_categories';

        $wpdb->delete($table_name, ['id' => $category_id]);

        return true;
    }

    /**
     * Создание вопроса
     */
    public function create_question($data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_questions';

        $wpdb->insert(
            $table_name,
            [
                'test_id' => intval($data['test_id']),
                'question_text' => sanitize_textarea_field($data['question_text']),
                'question_type' => sanitize_text_field($data['question_type'] ?? 'single'),
                'image_url' => sanitize_text_field($data['image_url'] ?? ''),
                'weight' => intval($data['weight'] ?? 1),
                'sort_order' => intval($data['sort_order'] ?? 0)
            ],
            ['%d', '%s', '%s', '%s', '%d', '%d']
        );

        return $wpdb->insert_id;
    }

    /**
     * Получение вопросов по тесту
     */
    public function get_questions_by_test($test_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_questions';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE test_id = %d ORDER BY sort_order ASC",
            $test_id
        ), ARRAY_A);
    }

    /**
     * Получение вопроса по ID
     */
    public function get_question($question_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_questions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $question_id
        ), ARRAY_A);
    }

    /**
     * Обновление вопроса
     */
    public function update_question($question_id, $data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_questions';

        $update_data = [];
        if (isset($data['question_text'])) {
            $update_data['question_text'] = sanitize_textarea_field($data['question_text']);
        }
        if (isset($data['question_type'])) {
            $update_data['question_type'] = sanitize_text_field($data['question_type']);
        }
        if (isset($data['image_url'])) {
            $update_data['image_url'] = sanitize_text_field($data['image_url']);
        }
        if (isset($data['weight'])) {
            $update_data['weight'] = intval($data['weight']);
        }
        if (isset($data['sort_order'])) {
            $update_data['sort_order'] = intval($data['sort_order']);
        }

        $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $question_id]
        );

        return true;
    }

    /**
     * Удаление вопроса
     */
    public function delete_question($question_id) {
        global $wpdb;

        // Удаляем связанные ответы
        $wpdb->delete($this->prefix . 'ptb_answers', ['question_id' => $question_id]);

        // Удаляем сам вопрос
        $wpdb->delete($this->prefix . 'ptb_questions', ['id' => $question_id]);

        return true;
    }

    /**
     * Создание ответа
     */
    public function create_answer($data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_answers';

        // Поддержка нового формата с категориями
        $category_weights = isset($data['category_weights']) ? sanitize_text_field($data['category_weights']) : null;

        // Для обратной совместимости: если не переданы веса категорий, используем старый формат
        $category_id = isset($data['category_id']) ? intval($data['category_id']) : 0;
        $points = isset($data['points']) ? intval($data['points']) : 0;

        $wpdb->insert(
            $table_name,
            [
                'question_id' => intval($data['question_id']),
                'answer_text' => sanitize_textarea_field($data['answer_text']),
                'category_id' => $category_id,
                'points' => $points,
                'category_weights' => $category_weights,
                'sort_order' => intval($data['sort_order'] ?? 0)
            ],
            ['%d', '%s', '%d', '%d', '%s', '%d']
        );

        return $wpdb->insert_id;
    }

    /**
     * Получение ответов по вопросу
     */
    public function get_answers_by_question($question_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_answers';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE question_id = %d ORDER BY sort_order ASC",
            $question_id
        ), ARRAY_A);
    }

    /**
     * Получение ответа по ID
     */
    public function get_answer($answer_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_answers';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE id = %d",
            $answer_id
        ), ARRAY_A);
    }

    /**
     * Обновление ответа
     */
    public function update_answer($answer_id, $data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_answers';

        $update_data = [];
        if (isset($data['answer_text'])) {
            $update_data['answer_text'] = sanitize_textarea_field($data['answer_text']);
        }

        // Поддержка нового формата с категориями
        if (isset($data['category_weights'])) {
            $update_data['category_weights'] = sanitize_text_field($data['category_weights']);
            // Обновляем заглушки для обратной совместимости
            $update_data['category_id'] = 0;
            $update_data['points'] = 0;
        } else {
            // Старый формат
            if (isset($data['category_id'])) {
                $update_data['category_id'] = intval($data['category_id']);
            }
            if (isset($data['points'])) {
                $update_data['points'] = intval($data['points']);
            }
            $update_data['category_weights'] = null;
        }

        if (isset($data['sort_order'])) {
            $update_data['sort_order'] = intval($data['sort_order']);
        }

        $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $answer_id]
        );

        return true;
    }

    /**
     * Удаление ответа
     */
    public function delete_answer($answer_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_answers';

        $wpdb->delete($table_name, ['id' => $answer_id]);

        return true;
    }

    /**
     * Создание результата
     */
    public function create_result($data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_results';

        // Поддержка гибких рекомендаций
        $custom_recommendations = isset($data['custom_recommendations']) ? wp_json_encode($data['custom_recommendations']) : null;

        $wpdb->insert(
            $table_name,
            [
                'test_id' => intval($data['test_id']),
                'result_name' => sanitize_text_field($data['result_name']),
                'result_description' => sanitize_textarea_field($data['result_description'] ?? ''),
                'category_combination' => sanitize_text_field($data['category_combination']),
                'rule_type' => sanitize_text_field($data['rule_type'] ?? 'dual'),
                'education_recommendations' => isset($data['education_recommendations']) ? wp_json_encode($data['education_recommendations']) : null,
                'career_recommendations' => isset($data['career_recommendations']) ? wp_json_encode($data['career_recommendations']) : null,
                'soul_areas' => isset($data['soul_areas']) ? wp_json_encode($data['soul_areas']) : null,
                'strengthen_tips' => isset($data['strengthen_tips']) ? wp_json_encode($data['strengthen_tips']) : null,
                'develop_tips' => isset($data['develop_tips']) ? wp_json_encode($data['develop_tips']) : null,
                'custom_recommendations' => $custom_recommendations,
                'image_url' => sanitize_text_field($data['image_url'] ?? ''),
                'sort_order' => intval($data['sort_order'] ?? 0)
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
        );

        return $wpdb->insert_id;
    }

    /**
     * Получение результатов по тесту
     */
    public function get_results_by_test($test_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_results';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE test_id = %d ORDER BY sort_order ASC",
            $test_id
        ), ARRAY_A);
    }

    /**
     * Обновление результата
     */
    public function update_result($result_id, $data) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_results';

        $update_data = [];
        if (isset($data['result_name'])) {
            $update_data['result_name'] = sanitize_text_field($data['result_name']);
        }
        if (isset($data['result_description'])) {
            $update_data['result_description'] = sanitize_textarea_field($data['result_description']);
        }
        if (isset($data['category_combination'])) {
            $update_data['category_combination'] = sanitize_text_field($data['category_combination']);
        }
        if (isset($data['rule_type'])) {
            $update_data['rule_type'] = sanitize_text_field($data['rule_type']);
        }
        if (isset($data['education_recommendations'])) {
            $update_data['education_recommendations'] = wp_json_encode($data['education_recommendations']);
        }
        if (isset($data['career_recommendations'])) {
            $update_data['career_recommendations'] = wp_json_encode($data['career_recommendations']);
        }
        if (isset($data['soul_areas'])) {
            $update_data['soul_areas'] = wp_json_encode($data['soul_areas']);
        }
        if (isset($data['strengthen_tips'])) {
            $update_data['strengthen_tips'] = wp_json_encode($data['strengthen_tips']);
        }
        if (isset($data['develop_tips'])) {
            $update_data['develop_tips'] = wp_json_encode($data['develop_tips']);
        }
        if (isset($data['custom_recommendations'])) {
            $update_data['custom_recommendations'] = wp_json_encode($data['custom_recommendations']);
        }
        if (isset($data['image_url'])) {
            $update_data['image_url'] = sanitize_text_field($data['image_url']);
        }
        if (isset($data['sort_order'])) {
            $update_data['sort_order'] = intval($data['sort_order']);
        }

        $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $result_id]
        );

        return true;
    }

    /**
     * Удаление результата
     */
    public function delete_result($result_id) {
        global $wpdb;
        $table_name = $this->prefix . 'ptb_results';

        $wpdb->delete($table_name, ['id' => $result_id]);

        return true;
    }
}