<?php
/**
 * AJAX обработчики (для совместимости со старыми версиями)
 */

if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_AJAX {
    
    public function __construct() {
        // Можно добавить AJAX обработчики для совместимости
        // Например, для сохранения ответов без REST API
    }
}