<?php
/**
 * Класс для создания админ-меню плагина
 *
 * @package Personality_Test_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_Admin_Menu {

    /**
     * Конструктор
     */
    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Регистрация меню
     */
    public function register_menu() {
        // Главное меню - Дашборд
        add_menu_page(
            'Personality Test Builder',
            'Personality Test Builder',
            'manage_options',
            'personality-test-builder',
            [$this, 'render_dashboard'],
            'dashicons-feedback',
            30
        );

        // Подменю - Дашборд (первый пункт)
        add_submenu_page(
            'personality-test-builder',
            'Дашборд',
            'Дашборд',
            'manage_options',
            'personality-test-builder',
            [$this, 'render_dashboard']
        );

        // Подменю - Базовые тесты
        add_submenu_page(
            'personality-test-builder',
            'Базовые тесты',
            'Базовые тесты',
            'manage_options',
            'ptb-basic-tests',
            [$this, 'render_basic_tests']
        );

        // Подменю - Личностные тесты
        add_submenu_page(
            'personality-test-builder',
            'Личностные тесты',
            'Личностные тесты',
            'manage_options',
            'ptb-personality-tests',
            [$this, 'render_personality_tests']
        );

        // Подменю - Квесты и ветвления
        add_submenu_page(
            'personality-test-builder',
            'Квесты и ветвления',
            'Квесты и ветвления',
            'manage_options',
            'ptb-quests',
            [$this, 'render_quests']
        );

        // Подменю - Логические карты
        add_submenu_page(
            'personality-test-builder',
            'Логические карты',
            'Логические карты',
            'manage_options',
            'ptb-logic-maps',
            [$this, 'render_logic_maps']
        );

        // Подменю - Настройки
        add_submenu_page(
            'personality-test-builder',
            'Настройки',
            'Настройки',
            'manage_options',
            'ptb-settings',
            [$this, 'render_settings']
        );
    }

    /**
     * Рендеринг дашборда
     */
    public function render_dashboard() {
        ?>
        <div class="wrap ptb-dashboard">
            <h1>Personality Test Builder</h1>
            
            <div class="ptb-dashboard-grid">
                <div class="ptb-dashboard-section">
                    <h2>Статистика</h2>
                    <div class="ptb-stats-grid">
                        <div class="ptb-stat-card">
                            <div class="stat-label">Всего тестов</div>
                            <div class="stat-number" id="total-tests">0</div>
                            <div class="stat-subtext">Базовых: <span id="basic-tests">0</span> | Личностных: <span id="personality-tests">0</span></div>
                        </div>
                        <div class="ptb-stat-card">
                            <div class="stat-label">Активных прохождений</div>
                            <div class="stat-number" id="active-sessions">0</div>
                            <div class="stat-subtext">За последние 24 часа</div>
                        </div>
                        <div class="ptb-stat-card">
                            <div class="stat-label">Завершённых тестов</div>
                            <div class="stat-number" id="completed-tests">0</div>
                            <div class="stat-subtext">За всё время</div>
                        </div>
                    </div>
                </div>

                <div class="ptb-dashboard-section">
                    <h2>Быстрые действия</h2>
                    <div class="ptb-quick-actions">
                        <a href="<?php echo admin_url('admin.php?page=ptb-basic-tests'); ?>" class="ptb-btn ptb-btn-primary">
                            Создать базовый тест
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ptb-personality-tests'); ?>" class="ptb-btn ptb-btn-primary">
                            Создать личностный тест
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=ptb-quests'); ?>" class="ptb-btn ptb-btn-secondary">
                            Создать квест
                        </a>
                    </div>
                </div>

                <div class="ptb-dashboard-section">
                    <h2>Последние тесты</h2>
                    <div id="recent-tests-container">
                        <div class="ptb-loading">Загрузка...</div>
                    </div>
                </div>

                <div class="ptb-dashboard-section">
                    <h2>Советы и подсказки</h2>
                    <div class="ptb-tips">
                        <div class="ptb-tip">
                            <strong>Личностные тесты</strong>
                            <p>Идеальны для определения типа личности, профориентации, психологических опросников.</p>
                        </div>
                        <div class="ptb-tip">
                            <strong>Базовые тесты</strong>
                            <p>Простые тесты с вопросами и ответами для проверки знаний, опросов, викторин.</p>
                        </div>
                        <div class="ptb-tip">
                            <strong>Квесты и ветвления</strong>
                            <p>Интерактивные сценарии с ветвлениями и условиями для игр, обучающих программ, историй.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Рендеринг базовых тестов
     */
    public function render_basic_tests() {
        ?>
        <div class="wrap">
            <h1>Базовые тесты</h1>
            <div class="ptb-feature-coming-soon">
                <div class="coming-soon-icon">🚧</div>
                <h2>Функционал в разработке</h2>
                <p>Базовые тесты — это простые тесты с вопросами и ответами, идеально подходящие для:</p>
                <ul>
                    <li>Проверки знаний и тестирования</li>
                    <li>Опросов и анкет</li>
                    <li>Викторин</li>
                    <li>Оценки навыков и компетенций</li>
                </ul>
                <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
                <a href="<?php echo admin_url('admin.php?page=personality-test-builder'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Рендеринг личностных тестов (текущий функционал)
     */
    public function render_personality_tests() {
        // Подключаем текущий интерфейс
        include PTB_PLUGIN_DIR . 'admin/admin.php';
    }

    /**
     * Рендеринг квестов
     */
    public function render_quests() {
        ?>
        <div class="wrap">
            <h1>Квесты и ветвления</h1>
            <div class="ptb-feature-coming-soon">
                <div class="coming-soon-icon">🎯</div>
                <h2>Функционал в разработке</h2>
                <p>Квесты и ветвления — это интерактивные сценарии с условиями и разветвлениями, идеально подходящие для:</p>
                <ul>
                    <li>Интерактивных историй и игр</li>
                    <li>Обучающих программ с адаптивным маршрутом</li>
                    <li>Бизнес-сценариев и кейсов</li>
                    <li>Ролевых игр и симуляций</li>
                </ul>
                <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
                <a href="<?php echo admin_url('admin.php?page=personality-test-builder'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Рендеринг логических карт
     */
    public function render_logic_maps() {
        ?>
        <div class="wrap">
            <h1>Логические карты</h1>
            <div class="ptb-feature-coming-soon">
                <div class="coming-soon-icon">🧠</div>
                <h2>Функционал в разработке</h2>
                <p>Логические карты — это визуальные инструменты для создания сложных логических связей и зависимостей, идеально подходящие для:</p>
                <ul>
                    <li>Диагностических деревьев и алгоритмов</li>
                    <li>Принятия решений на основе множества факторов</li>
                    <li>Визуализации бизнес-процессов</li>
                    <li>Создания экспертных систем</li>
                </ul>
                <p class="coming-soon-note">Доступно в следующих версиях плагина</p>
                <a href="<?php echo admin_url('admin.php?page=personality-test-builder'); ?>" class="button button-primary">
                    Вернуться на дашборд
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Рендеринг настроек
     */
    public function render_settings() {
        ?>
        <div class="wrap">
            <h1>Настройки плагина</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('ptb_general_settings'); ?>
                <?php do_settings_sections('ptb_settings_page'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Режим отладки</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_debug_mode" value="1" <?php checked(get_option('ptb_debug_mode'), 1); ?>>
                                Включить режим отладки (для разработчиков)
                            </label>
                            <p class="description">Показывать дополнительную информацию для отладки</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Кэширование</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_enable_cache" value="1" <?php checked(get_option('ptb_enable_cache', 1), 1); ?>>
                                Включить кэширование результатов
                            </label>
                            <p class="description">Ускоряет загрузку тестов, но может вызывать задержки при обновлении</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Сохранение результатов</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ptb_save_results" value="1" <?php checked(get_option('ptb_save_results', 1), 1); ?>>
                                Сохранять результаты прохождений тестов
                            </label>
                            <p class="description">Позволяет анализировать статистику и отслеживать тенденции</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Сохранить настройки'); ?>
            </form>

            <hr style="margin: 40px 0;">

            <h2>Системная информация</h2>
            <table class="widefat" style="max-width: 800px;">
                <tr>
                    <th>Версия плагина</th>
                    <td><?php echo PTB_VERSION; ?></td>
                </tr>
                <tr>
                    <th>Версия WordPress</th>
                    <td><?php echo get_bloginfo('version'); ?></td>
                </tr>
                <tr>
                    <th>Версия PHP</th>
                    <td><?php echo PHP_VERSION; ?></td>
                </tr>
                <tr>
                    <th>База данных</th>
                    <td><?php echo $GLOBALS['wpdb']->db_version(); ?></td>
                </tr>
            </table>
        </div>
        <?php
    }

    /**
     * Подключение стилей и скриптов
     */
    public function enqueue_assets($hook) {
        // Подключаем стили только на страницах плагина
        if (strpos($hook, 'personality-test-builder') !== false || strpos($hook, 'ptb-') !== false) {
            wp_enqueue_style('ptb-admin-dashboard', PTB_PLUGIN_URL . 'admin/css/admin-dashboard.css', [], PTB_VERSION);
            wp_enqueue_script('ptb-admin-dashboard', PTB_PLUGIN_URL . 'admin/js/admin-dashboard.js', ['jquery'], PTB_VERSION, true);
            
            // Передаём данные в скрипт
            wp_localize_script('ptb-admin-dashboard', 'ptbDashboardData', [
                'apiUrl' => rest_url('personality-test/v1'),
                'nonce' => wp_create_nonce('wp_rest')
            ]);
        }
        
        // Подключаем стили и скрипты для страницы личностных тестов
        if ($hook === 'personality-test-builder_page_ptb-personality-tests') {
            wp_enqueue_style('ptb-admin-css', PTB_PLUGIN_URL . 'admin/css/admin.css', [], PTB_VERSION);
            wp_enqueue_style('ptb-questions-css', PTB_PLUGIN_URL . 'admin/css/questions.css', ['ptb-admin-css'], PTB_VERSION);
            wp_enqueue_style('ptb-categories-css', PTB_PLUGIN_URL . 'admin/css/categories.css', ['ptb-admin-css'], PTB_VERSION);
            wp_enqueue_style('ptb-results-single-css', PTB_PLUGIN_URL . 'admin/css/results-single.css', ['ptb-admin-css'], PTB_VERSION);
            wp_enqueue_style('ptb-settings-css', PTB_PLUGIN_URL . 'admin/css/settings.css', ['ptb-admin-css'], PTB_VERSION);
            
            wp_enqueue_script('ptb-admin-main', PTB_PLUGIN_URL . 'admin/js/admin-main.js', ['jquery'], PTB_VERSION, true);
            wp_enqueue_script('ptb-questions-templates', PTB_PLUGIN_URL . 'admin/js/questions/templates.js', ['ptb-admin-main'], PTB_VERSION, true);
            wp_enqueue_script('ptb-questions-handlers', PTB_PLUGIN_URL . 'admin/js/questions/handlers.js', ['ptb-questions-templates'], PTB_VERSION, true);
            wp_enqueue_script('ptb-questions-index', PTB_PLUGIN_URL . 'admin/js/questions/index.js', ['ptb-questions-handlers'], PTB_VERSION, true);
            wp_enqueue_script('ptb-categories', PTB_PLUGIN_URL . 'admin/js/categories.js', ['ptb-admin-main'], PTB_VERSION, true);
            wp_enqueue_script('ptb-results-single', PTB_PLUGIN_URL . 'admin/js/results-single.js', ['ptb-admin-main'], PTB_VERSION, true);
            wp_enqueue_script('ptb-results-dual', PTB_PLUGIN_URL . 'admin/js/results-dual.js', ['ptb-admin-main'], PTB_VERSION, true);
            wp_enqueue_script('ptb-settings', PTB_PLUGIN_URL . 'admin/js/settings.js', ['ptb-admin-main'], PTB_VERSION, true);
            
            wp_localize_script('ptb-admin-main', 'ptbAdminSettings', [
                'apiUrl' => rest_url('personality-test/v1'),
                'nonce' => wp_create_nonce('wp_rest')
            ]);
        }
    }
}