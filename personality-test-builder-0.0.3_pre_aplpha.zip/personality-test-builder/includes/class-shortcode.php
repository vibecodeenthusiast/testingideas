<?php
/**
 * Класс для обработки шорткодов
 *
 * @package Personality_Test_Builder
 */

if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_Shortcode {

    /**
     * Регистрация шорткода
     */
    public function __construct() {
        add_shortcode('personality_test', [$this, 'render_test']);
    }

    /**
     * Рендер теста по шорткоду
     */
public function render_test($atts) {
    $atts = shortcode_atts(['id' => ''], $atts);
    $test_id = intval($atts['id']);
    
    if (!$test_id) {
        return '<p class="ptb-error">Не указан ID теста</p>';
    }
    
    // Получаем тест
    global $personality_test_builder;
    $test = $personality_test_builder->get_db()->get_test($test_id);
    
    if (!$test) {
        return '<p class="ptb-error">Тест не найден</p>';
    }
    
    // Подключаем стили и скрипты
    wp_enqueue_style('ptb-frontend-css', PTB_PLUGIN_URL . 'public/css/frontend.css', [], PTB_VERSION);
    wp_enqueue_script('ptb-frontend-js', PTB_PLUGIN_URL . 'public/js/frontend.js', ['jquery'], PTB_VERSION, true);
    
    // Передаем данные в скрипт
    wp_localize_script('ptb-frontend-js', 'ptbFrontendData', [
        'apiUrl' => rest_url('personality-test/v1'),
        'nonce' => wp_create_nonce('wp_rest'),
        'testId' => $test_id
    ]);
    
    // Возвращаем контейнер для теста
    return '<div class="personality-test-container" data-test-id="' . esc_attr($test_id) . '">
        <div class="ptb-loading">Загрузка теста...</div>
    </div>';
}

    /**
     * Получение данных теста для фронтенда
     */
    public function get_test_data($test_id) {
        global $personality_test_builder;
        
        $test = $personality_test_builder->get_db()->get_test($test_id);
        
        if (!$test) {
            return null;
        }
        
        // Получаем связанные данные
        $categories = $personality_test_builder->get_db()->get_categories_by_test($test_id) ?: [];
        $questions = $personality_test_builder->get_db()->get_questions_by_test($test_id) ?: [];
        $results = $personality_test_builder->get_db()->get_results_by_test($test_id) ?: [];
        
        // Для каждого вопроса получаем ответы
        foreach ($questions as &$question) {
            $question['answers'] = $personality_test_builder->get_db()->get_answers_by_question($question['id']) ?: [];
        }
        unset($question);
        
        // Декодируем данные результатов
        foreach ($results as &$result) {
            $result['education_recommendations'] = !empty($result['education_recommendations']) 
                ? json_decode($result['education_recommendations'], true) 
                : [];
            $result['career_recommendations'] = !empty($result['career_recommendations']) 
                ? json_decode($result['career_recommendations'], true) 
                : [];
            $result['soul_areas'] = !empty($result['soul_areas']) 
                ? json_decode($result['soul_areas'], true) 
                : [];
            $result['strengthen_tips'] = !empty($result['strengthen_tips']) 
                ? json_decode($result['strengthen_tips'], true) 
                : [];
            $result['develop_tips'] = !empty($result['develop_tips']) 
                ? json_decode($result['develop_tips'], true) 
                : [];
        }
        unset($result);
        
        // Декодируем настройки теста - КРИТИЧЕСКИ ВАЖНО
        $settings = !empty($test['settings']) 
            ? json_decode($test['settings'], true) 
            : [];
        
        // Формируем данные для шорткода
        $test_data = [
            'id' => (int)$test['id'],
            'test_name' => $test['test_name'] ?? '',
            'test_description' => $test['test_description'] ?? '',
            'settings' => $settings, // УЖЕ ДЕКОДИРОВАННЫЙ МАССИВ
            'categories' => $categories,
            'questions' => $questions,
            'results' => $results
        ];
        
        return $test_data;
    }
}