<?php
/**
 * REST API для плагина Personality Test Builder
 *
 * @package Personality_Test_Builder
 */
if (!defined('ABSPATH')) {
    exit;
}

class Personality_Test_Builder_REST_API {

    /**
     * Регистрация маршрутов
     */
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Регистрация всех маршрутов
     */
    public function register_routes() {
        // Тесты
        register_rest_route('personality-test/v1', '/tests', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_tests'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_test'],
                'permission_callback' => [$this, 'check_admin_permissions'],
                'args' => [
                    'name' => [
                        'type' => 'string',
                        'required' => true,
                    ],
                    'description' => [
                        'type' => 'string',
                    ],
                    'type' => [
                        'type' => 'string',
                        'default' => 'personality',
                    ],
                    'status' => [
                        'type' => 'string',
                        'default' => 'draft',
                    ],
                    'settings' => [
                        'type' => 'object',
                        'default' => [],
                    ],
                ],
            ]
        ]);

        register_rest_route('personality-test/v1', '/tests/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_test'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_test'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_test'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        // Вопросы
        register_rest_route('personality-test/v1', '/questions', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_questions'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_question'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        register_rest_route('personality-test/v1', '/questions/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_question'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_question'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_question'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        // Ответы
        register_rest_route('personality-test/v1', '/answers', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_answers'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_answer'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        register_rest_route('personality-test/v1', '/answers/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_answer'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_answer'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_answer'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        // Категории
        register_rest_route('personality-test/v1', '/categories', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_categories'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_category'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        register_rest_route('personality-test/v1', '/categories/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_category'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_category'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_category'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        // Результаты
        register_rest_route('personality-test/v1', '/results', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_results'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_result'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        register_rest_route('personality-test/v1', '/results/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_result'],
                'permission_callback' => '__return_true'
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_result'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_result'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);

        // Статистика
        register_rest_route('personality-test/v1', '/statistics', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_statistics'],
                'permission_callback' => [$this, 'check_admin_permissions']
            ]
        ]);
    }

    /**
     * Проверка прав администратора
     */
    public function check_admin_permissions() {
        return current_user_can('manage_options');
    }

    /**
     * Получение всех тестов — С ПОДДЕРЖКОЙ СТАТИСТИКИ
     */
    public function get_tests($request) {
        global $personality_test_builder, $wpdb;
        $tests = $personality_test_builder->get_db()->get_tests();

        // Если запрошена статистика
        $include_stats = $request->get_param('include_stats');
        
        foreach ($tests as &$test) {
            if (!empty($test['settings'])) {
                $test['settings'] = json_decode($test['settings'], true) ?: [];
            } else {
                $test['settings'] = [];
            }
            
            // Добавляем статистику, если запрошено
            if ($include_stats) {
                $test_id = $test['id'];
                
                // Получаем количество категорий
                $categories_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}ptb_categories WHERE test_id = %d",
                    $test_id
                ));
                
                // Получаем количество вопросов
                $questions_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}ptb_questions WHERE test_id = %d",
                    $test_id
                ));
                
                // Получаем цели из настроек
                $settings = $test['settings'];
                $test['categories_count'] = (int)$categories_count;
                $test['questions_count'] = (int)$questions_count;
                $test['target_categories'] = $settings['target_categories'] ?? 6;
                $test['target_questions'] = $settings['target_questions'] ?? 45;
            }
        }
        unset($test);

        return rest_ensure_response($tests);
    }

    /**
     * Получение теста по ID
     */
    public function get_test($request) {
        global $personality_test_builder;
        $test_id = $request['id'];
        $test = $personality_test_builder->get_db()->get_test($test_id);

        if (!$test) {
            return new WP_Error('not_found', 'Test not found', ['status' => 404]);
        }

        // Декодируем настройки теста
        if (!empty($test['settings'])) {
            $test['settings'] = json_decode($test['settings'], true) ?: [];
        } else {
            $test['settings'] = [];
        }

        // Получаем связанные данные
        $categories = $personality_test_builder->get_db()->get_categories_by_test($test_id);
        $questions = $personality_test_builder->get_db()->get_questions_by_test($test_id);

        // Для каждого вопроса получаем ответы
        foreach ($questions as &$question) {
            $question['answers'] = $personality_test_builder->get_db()->get_answers_by_question($question['id']);
        }

        $results = $personality_test_builder->get_db()->get_results_by_test($test_id);

        // Декодируем данные результатов
        foreach ($results as &$result) {
            if ($result['education_recommendations']) {
                $result['education_recommendations'] = json_decode($result['education_recommendations'], true);
            }
            if ($result['career_recommendations']) {
                $result['career_recommendations'] = json_decode($result['career_recommendations'], true);
            }
            if ($result['soul_areas']) {
                $result['soul_areas'] = json_decode($result['soul_areas'], true);
            }
            if ($result['strengthen_tips']) {
                $result['strengthen_tips'] = json_decode($result['strengthen_tips'], true);
            }
            if ($result['develop_tips']) {
                $result['develop_tips'] = json_decode($result['develop_tips'], true);
            }
            if ($result['custom_recommendations']) {
                $result['custom_recommendations'] = json_decode($result['custom_recommendations'], true);
            }
        }

        $test['categories'] = $categories;
        $test['questions'] = $questions;
        $test['results'] = $results;

        return rest_ensure_response($test);
    }

    /**
     * Создание теста — РАБОЧАЯ ВЕРСИЯ
     */
    public function create_test($request) {
        global $personality_test_builder;
        $data = $request->get_json_params();

        // Валидация обязательного поля
        if (empty($data['name'])) {
            return new WP_Error('invalid_param', 'Test name is required', ['status' => 400]);
        }

        // Явно формируем данные с дефолтными значениями
        $test_data = [
            'name' => sanitize_text_field($data['name']),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'type' => sanitize_text_field($data['type'] ?? 'personality'),
            'status' => sanitize_text_field($data['status'] ?? 'draft'),
            'settings' => is_array($data['settings'] ?? null) ? $data['settings'] : []
        ];

        // Создаём тест
        $test_id = $personality_test_builder->get_db()->create_test($test_data);

        if (!$test_id) {
            // Логируем ошибку для отладки
            error_log('PTB Create Test Error: ' . print_r($wpdb->last_error, true));
            error_log('PTB Test Data: ' . print_r($test_data, true));
            return new WP_Error('create_failed', 'Failed to create test. Check debug.log for details.', ['status' => 500]);
        }

        return rest_ensure_response([
            'id' => $test_id,
            'success' => true
        ]);
    }

    /**
     * Обновление теста
     */
    public function update_test($request) {
        global $personality_test_builder;
        $test_id = $request['id'];
        $data = $request->get_json_params();

        $update_data = [];

        if (isset($data['name'])) {
            $update_data['name'] = sanitize_text_field($data['name']);
        }
        if (isset($data['description'])) {
            $update_data['description'] = sanitize_textarea_field($data['description']);
        }
        if (isset($data['type'])) {
            $update_data['type'] = sanitize_text_field($data['type']);
        }
        if (isset($data['status'])) {
            $update_data['status'] = sanitize_text_field($data['status']);
        }
        if (isset($data['settings'])) {
            if (is_string($data['settings'])) {
                $settings = json_decode($data['settings'], true) ?: [];
            } else {
                $settings = is_array($data['settings']) ? $data['settings'] : [];
            }
            $update_data['settings'] = wp_json_encode($settings);
        }

        $result = $personality_test_builder->get_db()->update_test($test_id, $update_data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update test', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Удаление теста
     */
    public function delete_test($request) {
        global $personality_test_builder;
        $test_id = $request['id'];
        $result = $personality_test_builder->get_db()->delete_test($test_id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete test', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Получение вопросов по тесту
     */
    public function get_questions($request) {
        global $personality_test_builder;
        $test_id = $request->get_param('test_id');

        if (!$test_id) {
            return new WP_Error('invalid_param', 'Test ID is required', ['status' => 400]);
        }

        $questions = $personality_test_builder->get_db()->get_questions_by_test($test_id);

        // Для каждого вопроса получаем ответы
        foreach ($questions as &$question) {
            $question['answers'] = $personality_test_builder->get_db()->get_answers_by_question($question['id']);
        }

        return rest_ensure_response($questions);
    }

    /**
     * Получение вопроса по ID
     */
    public function get_question($request) {
        global $personality_test_builder;
        $question_id = $request['id'];
        $question = $personality_test_builder->get_db()->get_question($question_id);

        if (!$question) {
            return new WP_Error('not_found', 'Question not found', ['status' => 404]);
        }

        // Получаем ответы
        $question['answers'] = $personality_test_builder->get_db()->get_answers_by_question($question_id);

        return rest_ensure_response($question);
    }

    /**
     * Создание вопроса
     */
    public function create_question($request) {
        global $personality_test_builder;
        $data = $request->get_json_params();

        if (empty($data['test_id']) || empty($data['question_text'])) {
            return new WP_Error('invalid_param', 'Test ID and question text are required', ['status' => 400]);
        }

        $question_id = $personality_test_builder->get_db()->create_question($data);

        if (!$question_id) {
            return new WP_Error('create_failed', 'Failed to create question', ['status' => 500]);
        }

        return rest_ensure_response([
            'id' => $question_id,
            'success' => true
        ]);
    }

    /**
     * Обновление вопроса
     */
    public function update_question($request) {
        global $personality_test_builder;
        $question_id = $request['id'];
        $data = $request->get_json_params();

        $result = $personality_test_builder->get_db()->update_question($question_id, $data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update question', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Удаление вопроса
     */
    public function delete_question($request) {
        global $personality_test_builder;
        $question_id = $request['id'];
        $result = $personality_test_builder->get_db()->delete_question($question_id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete question', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Получение ответов по вопросу
     */
    public function get_answers($request) {
        global $personality_test_builder;
        $question_id = $request->get_param('question_id');

        if (!$question_id) {
            return new WP_Error('invalid_param', 'Question ID is required', ['status' => 400]);
        }

        $answers = $personality_test_builder->get_db()->get_answers_by_question($question_id);

        return rest_ensure_response($answers);
    }

    /**
     * Получение ответа по ID
     */
    public function get_answer($request) {
        global $personality_test_builder;
        $answer_id = $request['id'];
        $answer = $personality_test_builder->get_db()->get_answer($answer_id);

        if (!$answer) {
            return new WP_Error('not_found', 'Answer not found', ['status' => 404]);
        }

        return rest_ensure_response($answer);
    }

    /**
     * Создание ответа
     */
    public function create_answer($request) {
        global $personality_test_builder;
        $data = $request->get_json_params();

        if (empty($data['question_id']) || empty($data['answer_text'])) {
            return new WP_Error('invalid_param', 'Question ID and answer text are required', ['status' => 400]);
        }

        // Поддержка нового формата с категориями
        $answer_data = [
            'question_id' => intval($data['question_id']),
            'answer_text' => sanitize_textarea_field($data['answer_text']),
            'sort_order' => intval($data['sort_order'] ?? 0)
        ];

        // Если переданы веса категорий - используем новый формат
        if (isset($data['category_weights'])) {
            $answer_data['category_weights'] = sanitize_text_field($data['category_weights']);
            // Для обратной совместимости сохраняем заглушки
            $answer_data['category_id'] = 0;
            $answer_data['points'] = 0;
        } else {
            // Старый формат
            $answer_data['category_id'] = intval($data['category_id'] ?? 0);
            $answer_data['points'] = intval($data['points'] ?? 0);
            $answer_data['category_weights'] = null;
        }

        $answer_id = $personality_test_builder->get_db()->create_answer($answer_data);

        if (!$answer_id) {
            return new WP_Error('create_failed', 'Failed to create answer', ['status' => 500]);
        }

        return rest_ensure_response([
            'id' => $answer_id,
            'success' => true
        ]);
    }

    /**
     * Обновление ответа
     */
    public function update_answer($request) {
        global $personality_test_builder;
        $answer_id = $request['id'];
        $data = $request->get_json_params();

        $update_data = [];

        if (isset($data['answer_text'])) {
            $update_data['answer_text'] = sanitize_textarea_field($data['answer_text']);
        }

        // Поддержка нового формата с категориями
        if (isset($data['category_weights'])) {
            $update_data['category_weights'] = sanitize_text_field($data['category_weights']);
            // Обновляем заглушки для обратной совместимости
            $update_data['category_id'] = 0;
            $update_data['points'] = 0;
        } else {
            // Старый формат
            if (isset($data['category_id'])) {
                $update_data['category_id'] = intval($data['category_id']);
            }
            if (isset($data['points'])) {
                $update_data['points'] = intval($data['points']);
            }
            $update_data['category_weights'] = null;
        }

        if (isset($data['sort_order'])) {
            $update_data['sort_order'] = intval($data['sort_order']);
        }

        $result = $personality_test_builder->get_db()->update_answer($answer_id, $update_data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update answer', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Удаление ответа
     */
    public function delete_answer($request) {
        global $personality_test_builder;
        $answer_id = $request['id'];
        $result = $personality_test_builder->get_db()->delete_answer($answer_id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete answer', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Получение категорий по тесту
     */
    public function get_categories($request) {
        global $personality_test_builder;
        $test_id = $request->get_param('test_id');

        if (!$test_id) {
            return new WP_Error('invalid_param', 'Test ID is required', ['status' => 400]);
        }

        $categories = $personality_test_builder->get_db()->get_categories_by_test($test_id);

        return rest_ensure_response($categories);
    }

    /**
     * Получение категории по ID
     */
    public function get_category($request) {
        global $personality_test_builder;
        $category_id = $request['id'];
        $category = $personality_test_builder->get_db()->get_category($category_id);

        if (!$category) {
            return new WP_Error('not_found', 'Category not found', ['status' => 404]);
        }

        return rest_ensure_response($category);
    }

    /**
     * Создание категории
     */
    public function create_category($request) {
        global $personality_test_builder;
        $data = $request->get_json_params();

        if (empty($data['test_id']) || empty($data['name']) || empty($data['code'])) {
            return new WP_Error('invalid_param', 'Test ID, category name and code are required', ['status' => 400]);
        }

        $category_id = $personality_test_builder->get_db()->create_category($data);

        if (!$category_id) {
            return new WP_Error('create_failed', 'Failed to create category', ['status' => 500]);
        }

        return rest_ensure_response([
            'id' => $category_id,
            'success' => true
        ]);
    }

    /**
     * Обновление категории
     */
    public function update_category($request) {
        global $personality_test_builder;
        $category_id = $request['id'];
        $data = $request->get_json_params();

        $result = $personality_test_builder->get_db()->update_category($category_id, $data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update category', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Удаление категории
     */
    public function delete_category($request) {
        global $personality_test_builder;
        $category_id = $request['id'];
        $result = $personality_test_builder->get_db()->delete_category($category_id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete category', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Получение результатов по тесту
     */
    public function get_results($request) {
        global $personality_test_builder;
        $test_id = $request->get_param('test_id');

        if (!$test_id) {
            return new WP_Error('invalid_param', 'Test ID is required', ['status' => 400]);
        }

        $results = $personality_test_builder->get_db()->get_results_by_test($test_id);

        // Декодируем данные результатов
        foreach ($results as &$result) {
            if ($result['education_recommendations']) {
                $result['education_recommendations'] = json_decode($result['education_recommendations'], true);
            }
            if ($result['career_recommendations']) {
                $result['career_recommendations'] = json_decode($result['career_recommendations'], true);
            }
            if ($result['soul_areas']) {
                $result['soul_areas'] = json_decode($result['soul_areas'], true);
            }
            if ($result['strengthen_tips']) {
                $result['strengthen_tips'] = json_decode($result['strengthen_tips'], true);
            }
            if ($result['develop_tips']) {
                $result['develop_tips'] = json_decode($result['develop_tips'], true);
            }
            if ($result['custom_recommendations']) {
                $result['custom_recommendations'] = json_decode($result['custom_recommendations'], true);
            }
        }

        return rest_ensure_response($results);
    }

    /**
     * Получение результата по ID
     */
    public function get_result($request) {
        global $personality_test_builder;
        $result_id = $request['id'];
        $result = $personality_test_builder->get_db()->get_result($result_id);

        if (!$result) {
            return new WP_Error('not_found', 'Result not found', ['status' => 404]);
        }

        // Декодируем данные результатов
        if ($result['education_recommendations']) {
            $result['education_recommendations'] = json_decode($result['education_recommendations'], true);
        }
        if ($result['career_recommendations']) {
            $result['career_recommendations'] = json_decode($result['career_recommendations'], true);
        }
        if ($result['soul_areas']) {
            $result['soul_areas'] = json_decode($result['soul_areas'], true);
        }
        if ($result['strengthen_tips']) {
            $result['strengthen_tips'] = json_decode($result['strengthen_tips'], true);
        }
        if ($result['develop_tips']) {
            $result['develop_tips'] = json_decode($result['develop_tips'], true);
        }
        if ($result['custom_recommendations']) {
            $result['custom_recommendations'] = json_decode($result['custom_recommendations'], true);
        }

        return rest_ensure_response($result);
    }

    /**
     * Создание результата
     */
    public function create_result($request) {
        global $personality_test_builder;
        $data = $request->get_json_params();

        if (empty($data['test_id']) || empty($data['result_name']) || empty($data['category_combination'])) {
            return new WP_Error('invalid_param', 'Test ID, result name and category combination are required', ['status' => 400]);
        }

        $result_id = $personality_test_builder->get_db()->create_result($data);

        if (!$result_id) {
            return new WP_Error('create_failed', 'Failed to create result', ['status' => 500]);
        }

        return rest_ensure_response([
            'id' => $result_id,
            'success' => true
        ]);
    }

    /**
     * Обновление результата
     */
    public function update_result($request) {
        global $personality_test_builder;
        $result_id = $request['id'];
        $data = $request->get_json_params();

        $result = $personality_test_builder->get_db()->update_result($result_id, $data);

        if (!$result) {
            return new WP_Error('update_failed', 'Failed to update result', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Удаление результата
     */
    public function delete_result($request) {
        global $personality_test_builder;
        $result_id = $request['id'];
        $result = $personality_test_builder->get_db()->delete_result($result_id);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete result', ['status' => 500]);
        }

        return rest_ensure_response(['success' => true]);
    }

    /**
     * Получение статистики с разбивкой по типам
     */
    public function get_statistics($request) {
        global $wpdb;

        // Количество тестов
        $tests_total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptb_tests");
        $tests_personality = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptb_tests WHERE type = 'personality' OR type IS NULL");

        // Количество вопросов
        $questions_total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptb_questions");

        // Вопросы для личностных тестов (через связь с таблицей тестов)
        $questions_personality = $wpdb->get_var("
            SELECT COUNT(*)
            FROM {$wpdb->prefix}ptb_questions q
            INNER JOIN {$wpdb->prefix}ptb_tests t ON q.test_id = t.id
            WHERE t.type = 'personality' OR t.type IS NULL
        ");

        // Завершённые тесты за 24 часа
        $completed_total = 0;
        $completed_personality = 0;

        if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}ptb_test_results'")) {
            $completed_total = $wpdb->get_var("
                SELECT COUNT(*)
                FROM {$wpdb->prefix}ptb_test_results
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
            ");

            $completed_personality = $wpdb->get_var("
                SELECT COUNT(*)
                FROM {$wpdb->prefix}ptb_test_results r
                INNER JOIN {$wpdb->prefix}ptb_tests t ON r.test_id = t.id
                WHERE r.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                AND (t.type = 'personality' OR t.type IS NULL)
            ");
        }

        // Последние 5 тестов
        $recent_tests = $wpdb->get_results("
            SELECT id, name, created_at
            FROM {$wpdb->prefix}ptb_tests
            ORDER BY id DESC
            LIMIT 5
        ", ARRAY_A);

        return [
            'tests' => [
                'total' => (int)$tests_total,
                'personality' => (int)$tests_personality,
                'basic' => 0,
                'quests' => 0
            ],
            'questions' => [
                'total' => (int)$questions_total,
                'personality' => (int)$questions_personality,
                'basic' => 0,
                'quests' => 0
            ],
            'completed_tests' => [
                'total' => (int)$completed_total,
                'personality' => (int)$completed_personality,
                'basic' => 0,
                'quests' => 0
            ],
            'recent_tests' => $recent_tests
        ];
    }
}